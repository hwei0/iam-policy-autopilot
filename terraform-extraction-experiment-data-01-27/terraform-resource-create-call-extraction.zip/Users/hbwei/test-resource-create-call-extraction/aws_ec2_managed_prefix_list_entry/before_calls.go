package ec2

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	awstypes "github.com/aws/aws-sdk-go-v2/service/ec2/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func managedPrefixListEntryCreateResourceID(prefixListID, cidrBlock string) string {
	parts := []string{prefixListID, cidrBlock}
	id := strings.Join(parts, managedPrefixListEntryIDSeparator)
	return id
}

func (ipProtocolType) String() string {
	return "IPProtocolType"
}

func findManagedPrefixListByID(ctx context.Context, conn *ec2.Client, id string) (*awstypes.ManagedPrefixList, error) {
	input := ec2.DescribeManagedPrefixListsInput{PrefixListIds: []string{id}}
	output, err := findManagedPrefixList(ctx, conn, &input)
	if err != nil {
		return nil, err
	}
	if state := output.State; state == awstypes.PrefixListStateDeleteComplete {
		return nil, &retry.NotFoundError{Message: string(state), LastRequest: &input}
	}
	if aws.ToString(output.PrefixListId) != id {
		return nil, &retry.NotFoundError{LastRequest: &input}
	}
	return output, nil
}

func findManagedPrefixList(ctx context.Context, conn *ec2.Client, input *ec2.DescribeManagedPrefixListsInput) (*awstypes.ManagedPrefixList, error) {
	output, err := findManagedPrefixLists(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findManagedPrefixLists(ctx context.Context, conn *ec2.Client, input *ec2.DescribeManagedPrefixListsInput) ([]awstypes.ManagedPrefixList, error) {
	var output []awstypes.ManagedPrefixList
	pages := ec2.NewDescribeManagedPrefixListsPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if tfawserr.ErrCodeEquals(err, errCodeInvalidPrefixListIDNotFound) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: &input}
		}
		if err != nil {
			return nil, err
		}
		output = append(output, page.PrefixLists...)
	}
	return output, nil
}

func (p *describeVpcEncryptionControlsPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *describeVpcEncryptionControlsPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.DescribeVpcEncryptionControlsOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.DescribeVpcEncryptionControls(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next DescribeVpcEncryptionControls page.


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.GetVpcResourcesBlockingEncryptionEnforcementOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.GetVpcResourcesBlockingEncryptionEnforcement(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next GetVpcResourcesBlockingEncryptionEnforcement page.


