package ec2

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	awstypes "github.com/aws/aws-sdk-go-v2/service/ec2/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func waitManagedPrefixListModified(ctx context.Context, conn *ec2.Client, id string) (*awstypes.ManagedPrefixList, error) {
	stateConf := &retry.StateChangeConf{Pending: enum.Slice(awstypes.PrefixListStateModifyInProgress), Target: enum.Slice(awstypes.PrefixListStateModifyComplete), Timeout: managedPrefixListTimeout, Refresh: statusManagedPrefixListState(ctx, conn, id)}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*awstypes.ManagedPrefixList); ok {
		if output.State == awstypes.PrefixListStateModifyFailed {
			tfresource.SetLastError(err, errors.New(aws.ToString(output.StateMessage)))
		}
		return output, err
	}
	return nil, err
}

func statusManagedPrefixListState(ctx context.Context, conn *ec2.Client, id string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findManagedPrefixListByID(ctx, conn, id)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return nil, "", err
		}
		return output, string(output.State), nil
	}
}

func findManagedPrefixListByID(ctx context.Context, conn *ec2.Client, id string) (*awstypes.ManagedPrefixList, error) {
	input := ec2.DescribeManagedPrefixListsInput{PrefixListIds: []string{id}}
	output, err := findManagedPrefixList(ctx, conn, &input)
	if err != nil {
		return nil, err
	}
	if state := output.State; state == awstypes.PrefixListStateDeleteComplete {
		return nil, &retry.NotFoundError{Message: string(state), LastRequest: &input}
	}
	if aws.ToString(output.PrefixListId) != id {
		return nil, &retry.NotFoundError{LastRequest: &input}
	}
	return output, nil
}

func findManagedPrefixList(ctx context.Context, conn *ec2.Client, input *ec2.DescribeManagedPrefixListsInput) (*awstypes.ManagedPrefixList, error) {
	output, err := findManagedPrefixLists(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findManagedPrefixLists(ctx context.Context, conn *ec2.Client, input *ec2.DescribeManagedPrefixListsInput) ([]awstypes.ManagedPrefixList, error) {
	var output []awstypes.ManagedPrefixList
	pages := ec2.NewDescribeManagedPrefixListsPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if tfawserr.ErrCodeEquals(err, errCodeInvalidPrefixListIDNotFound) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: &input}
		}
		if err != nil {
			return nil, err
		}
		output = append(output, page.PrefixLists...)
	}
	return output, nil
}

func (p *describeVpcEncryptionControlsPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *describeVpcEncryptionControlsPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.DescribeVpcEncryptionControlsOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.DescribeVpcEncryptionControls(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next DescribeVpcEncryptionControls page.


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.GetVpcResourcesBlockingEncryptionEnforcementOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.GetVpcResourcesBlockingEncryptionEnforcement(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next GetVpcResourcesBlockingEncryptionEnforcement page.


func resourceManagedPrefixListEntryRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EC2Client(ctx)
	plID, cidr, err := managedPrefixListEntryParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	entry, err := tfresource.RetryWhenNewResourceNotFound(ctx, managedPrefixListEntryCreateTimeout, func(ctx context.Context) (*awstypes.PrefixListEntry, error) {
		return findManagedPrefixListEntryByIDAndCIDR(ctx, conn, plID, cidr)
	}, d.IsNewResource())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] VPC Managed Prefix List Entry (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading VPC Managed Prefix List Entry (%s): %s", d.Id(), err)
	}
	d.Set("cidr", entry.Cidr)
	d.Set(names.AttrDescription, entry.Description)
	return diags
}

func managedPrefixListEntryParseResourceID(id string) (string, string, error) {
	parts := strings.Split(id, managedPrefixListEntryIDSeparator)
	if len(parts) == 2 && parts[0] != "" && parts[1] != "" {
		return parts[0], parts[1], nil
	}
	return "", "", fmt.Errorf("unexpected format for ID (%[1]s), expected prefix-list-id%[2]scidr-block", id, managedPrefixListEntryIDSeparator)
}

func findManagedPrefixListEntryByIDAndCIDR(ctx context.Context, conn *ec2.Client, id, cidr string) (*awstypes.PrefixListEntry, error) {
	output, err := findManagedPrefixListEntriesByID(ctx, conn, id)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(tfslices.Filter(output, func(v awstypes.PrefixListEntry) bool {
		return aws.ToString(v.Cidr) == cidr
	}))
}

func findManagedPrefixListEntriesByID(ctx context.Context, conn *ec2.Client, id string) ([]awstypes.PrefixListEntry, error) {
	input := ec2.GetManagedPrefixListEntriesInput{PrefixListId: aws.String(id)}
	return findManagedPrefixListEntries(ctx, conn, &input)
}

func (ipProtocolType) String() string {
	return "IPProtocolType"
}

func findManagedPrefixListEntries(ctx context.Context, conn *ec2.Client, input *ec2.GetManagedPrefixListEntriesInput) ([]awstypes.PrefixListEntry, error) {
	var output []awstypes.PrefixListEntry
	pages := ec2.NewGetManagedPrefixListEntriesPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if tfawserr.ErrCodeEquals(err, errCodeInvalidPrefixListIDNotFound) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: &input}
		}
		if err != nil {
			return nil, err
		}
		output = append(output, page.Entries...)
	}
	return output, nil
}

