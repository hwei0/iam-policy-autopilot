package ec2

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	awstypes "github.com/aws/aws-sdk-go-v2/service/ec2/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceManagedPrefixListEntryCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EC2Client(ctx)
	cidr := d.Get("cidr").(string)
	plID := d.Get("prefix_list_id").(string)
	id := managedPrefixListEntryCreateResourceID(plID, cidr)
	addPrefixListEntry := awstypes.AddPrefixListEntry{Cidr: aws.String(cidr)}
	if v, ok := d.GetOk(names.AttrDescription); ok {
		addPrefixListEntry.Description = aws.String(v.(string))
	}
	_, err := tfresource.RetryWhenAWSErrCodeEquals(ctx, d.Timeout(schema.TimeoutCreate), func(ctx context.Context) (any, error) {
		mutexKey := fmt.Sprintf("vpc-managed-prefix-list-%s", plID)
		conns.GlobalMutexKV.Lock(mutexKey)
		defer conns.GlobalMutexKV.Unlock(mutexKey)
		pl, err := findManagedPrefixListByID(ctx, conn, plID)
		if err != nil {
			return nil, fmt.Errorf("reading VPC Managed Prefix List (%s): %w", plID, err)
		}
		input := &ec2.ModifyManagedPrefixListInput{AddEntries: []awstypes.AddPrefixListEntry{addPrefixListEntry}, CurrentVersion: pl.Version, PrefixListId: aws.String(plID)}
		return conn.ModifyManagedPrefixList(ctx, input)
	}, errCodeIncorrectState, errCodePrefixListVersionMismatch)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating VPC Managed Prefix List Entry (%s): %s", id, err)
	}
	d.SetId(id)
	if _, err := waitManagedPrefixListModified(ctx, conn, plID); err != nil {
		return sdkdiag.AppendErrorf(diags, "waiting for VPC Managed Prefix List Entry (%s) create: %s", d.Id(), err)
	}
	return append(diags, resourceManagedPrefixListEntryRead(ctx, d, meta)...)
}

