package storagegateway

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/storagegateway"
	awstypes "github.com/aws/aws-sdk-go-v2/service/storagegateway/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
)

func resourceCacheCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).StorageGatewayClient(ctx)
	diskID := d.Get("disk_id").(string)
	gatewayARN := d.Get("gateway_arn").(string)
	id := cacheCreateResourceID(gatewayARN, diskID)
	inputAC := &storagegateway.AddCacheInput{DiskIds: []string{diskID}, GatewayARN: aws.String(gatewayARN)}
	_, err := conn.AddCache(ctx, inputAC)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Storage Gateway Cache (%s): %s", id, err)
	}
	d.SetId(id)
	inputLLD := &storagegateway.ListLocalDisksInput{GatewayARN: aws.String(gatewayARN)}
	disk, err := findLocalDisk(ctx, conn, inputLLD, func(v awstypes.Disk) bool {
		return aws.ToString(v.DiskId) == diskID || aws.ToString(v.DiskNode) == diskID || aws.ToString(v.DiskPath) == diskID
	})
	switch {
	case tfresource.NotFound(err):
	case err != nil:
		return sdkdiag.AppendErrorf(diags, "reading Storage Gateway local disk: %s", err)
	default:
		id = cacheCreateResourceID(gatewayARN, aws.ToString(disk.DiskId))
		d.SetId(id)
	}
	return append(diags, resourceCacheRead(ctx, d, meta)...)
}

