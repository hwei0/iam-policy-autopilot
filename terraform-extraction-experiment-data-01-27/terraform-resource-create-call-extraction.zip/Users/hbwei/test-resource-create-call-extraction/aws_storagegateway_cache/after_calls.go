package storagegateway

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/storagegateway"
	awstypes "github.com/aws/aws-sdk-go-v2/service/storagegateway/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
)

func findLocalDisk(ctx context.Context, conn *storagegateway.Client, input *storagegateway.ListLocalDisksInput, filter tfslices.Predicate[awstypes.Disk]) (*awstypes.Disk, error) {
	output, err := findLocalDisks(ctx, conn, input, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findLocalDisks(ctx context.Context, conn *storagegateway.Client, input *storagegateway.ListLocalDisksInput, filter tfslices.Predicate[awstypes.Disk]) ([]awstypes.Disk, error) {
	output, err := conn.ListLocalDisks(ctx, input)
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return tfslices.Filter(output.Disks, filter), nil
}

func cacheCreateResourceID(gatewayARN, diskID string) string {
	parts := []string{gatewayARN, diskID}
	id := strings.Join(parts, cacheResourceIDSeparator)
	return id
}

func resourceCacheRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).StorageGatewayClient(ctx)
	gatewayARN, diskID, err := cacheParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	err = findCacheByTwoPartKey(ctx, conn, gatewayARN, diskID)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Storage Gateway Cache (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Storage Gateway Cache (%s): %s", d.Id(), err)
	}
	d.Set("disk_id", diskID)
	d.Set("gateway_arn", gatewayARN)
	return diags
}

func cacheParseResourceID(id string) (string, string, error) {
	idFormatErr := fmt.Errorf("unexpected format for ID (%[1]s), expected GatewayARN%[2]sDiskID", id, cacheResourceIDSeparator)
	gatewayARNAndDisk, err := arn.Parse(id)
	if err != nil {
		return "", "", idFormatErr
	}
	resourceParts := strings.SplitN(gatewayARNAndDisk.Resource, cacheResourceIDSeparator, 2)
	if len(resourceParts) != 2 {
		return "", "", idFormatErr
	}
	gatewayARN := &arn.ARN{Partition: gatewayARNAndDisk.Partition, Service: gatewayARNAndDisk.Service, Region: gatewayARNAndDisk.Region, AccountID: gatewayARNAndDisk.AccountID, Resource: resourceParts[0]}
	return gatewayARN.String(), resourceParts[1], nil
}

func findCacheByTwoPartKey(ctx context.Context, conn *storagegateway.Client, gatewayARN, diskID string) error {
	input := &storagegateway.DescribeCacheInput{GatewayARN: aws.String(gatewayARN)}
	output, err := findCache(ctx, conn, input)
	if err != nil {
		return err
	}
	_, err = tfresource.AssertSingleValueResult(tfslices.Filter(output.DiskIds, func(v string) bool {
		return v == diskID
	}))
	return err
}

func findCache(ctx context.Context, conn *storagegateway.Client, input *storagegateway.DescribeCacheInput) (*storagegateway.DescribeCacheOutput, error) {
	output, err := conn.DescribeCache(ctx, input)
	if isGatewayNotFoundErr(err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, err
}

func isGatewayNotFoundErr(err error) bool {
	if operationErrorCode(err) == awstypes.ErrorCodeGatewayNotFound {
		return true
	}
	if tfawserr.ErrCodeEquals(err, string(awstypes.ErrorCodeGatewayNotFound)) {
		return true
	}
	if errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "The specified gateway was not found") {
		return true
	}
	return false
}// The API returns multiple responses for a missing gateway.


func operationErrorCode(err error) awstypes.ErrorCode {
	if v, ok := errs.As[*awstypes.InternalServerError](err); ok && v.Error_ != nil {
		return v.Error_.ErrorCode
	}
	if v, ok := errs.As[*awstypes.InvalidGatewayRequestException](err); ok && v.Error_ != nil {
		return v.Error_.ErrorCode
	}
	return ""
}// operationErrorCode returns the operation error code from the specified error:
//   - err represents an InternalServerError or InvalidGatewayRequestException
//   - Error_ is not nil
//
// See https://docs.aws.amazon.com/storagegateway/latest/userguide/AWSStorageGatewayAPI.html#APIErrorResponses for details.


