package iot

import (
	"context"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/iot"
	awstypes "github.com/aws/aws-sdk-go-v2/service/iot/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandThingGroupProperties(tfMap map[string]any) *awstypes.ThingGroupProperties {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.ThingGroupProperties{}
	if v, ok := tfMap["attribute_payload"].([]any); ok && len(v) > 0 && v[0] != nil {
		apiObject.AttributePayload = expandAttributePayload(v[0].(map[string]any))
	}
	if v, ok := tfMap[names.AttrDescription].(string); ok && v != "" {
		apiObject.ThingGroupDescription = aws.String(v)
	}
	return apiObject
}

func expandAttributePayload(tfMap map[string]any) *awstypes.AttributePayload {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.AttributePayload{}
	if v, ok := tfMap[names.AttrAttributes].(map[string]any); ok && len(v) > 0 {
		apiObject.Attributes = flex.ExpandStringValueMap(v)
	}
	return apiObject
}

