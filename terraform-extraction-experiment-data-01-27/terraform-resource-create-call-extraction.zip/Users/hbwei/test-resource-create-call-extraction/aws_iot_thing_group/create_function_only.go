package iot

import (
	"context"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/iot"
	awstypes "github.com/aws/aws-sdk-go-v2/service/iot/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceThingGroupCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IoTClient(ctx)
	name := d.Get(names.AttrName).(string)
	input := &iot.CreateThingGroupInput{Tags: getTagsIn(ctx), ThingGroupName: aws.String(name)}
	if v, ok := d.GetOk("parent_group_name"); ok {
		input.ParentGroupName = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrProperties); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input.ThingGroupProperties = expandThingGroupProperties(v.([]any)[0].(map[string]any))
	}
	output, err := conn.CreateThingGroup(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating IoT Thing Group (%s): %s", name, err)
	}
	d.SetId(aws.ToString(output.ThingGroupName))
	return append(diags, resourceThingGroupRead(ctx, d, meta)...)
}

