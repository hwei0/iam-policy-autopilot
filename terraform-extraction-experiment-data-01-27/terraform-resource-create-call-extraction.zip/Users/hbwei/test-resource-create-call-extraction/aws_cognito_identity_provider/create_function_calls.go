package cognitoidp

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider"
	awstypes "github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceIdentityProviderCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).CognitoIDPClient(ctx)
	providerName := d.Get(names.AttrProviderName).(string)
	userPoolID := d.Get(names.AttrUserPoolID).(string)
	id := identityProviderCreateResourceID(userPoolID, providerName)
	input := &cognitoidentityprovider.CreateIdentityProviderInput{ProviderName: aws.String(providerName), ProviderType: awstypes.IdentityProviderTypeType(d.Get("provider_type").(string)), UserPoolId: aws.String(userPoolID)}
	if v, ok := d.GetOk("attribute_mapping"); ok && len(v.(map[string]any)) > 0 {
		input.AttributeMapping = flex.ExpandStringValueMap(v.(map[string]any))
	}
	if v, ok := d.GetOk("idp_identifiers"); ok && len(v.([]any)) > 0 {
		input.IdpIdentifiers = flex.ExpandStringValueList(v.([]any))
	}
	if v, ok := d.GetOk("provider_details"); ok && len(v.(map[string]any)) > 0 {
		input.ProviderDetails = flex.ExpandStringValueMap(v.(map[string]any))
	}
	_, err := conn.CreateIdentityProvider(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Cognito Identity Provider (%s): %s", id, err)
	}
	d.SetId(id)
	return append(diags, resourceIdentityProviderRead(ctx, d, meta)...)
}

func identityProviderCreateResourceID(userPoolID, providerName string) string {
	parts := []string{userPoolID, providerName}
	id := strings.Join(parts, identityProviderResourceIDSeparator)
	return id
}

func resourceIdentityProviderRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).CognitoIDPClient(ctx)
	userPoolID, providerName, err := identityProviderParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	idp, err := findIdentityProviderByTwoPartKey(ctx, conn, userPoolID, providerName)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Cognito Identity Provider %s not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Cognito Identity Provider (%s): %s", d.Id(), err)
	}
	d.Set("attribute_mapping", idp.AttributeMapping)
	d.Set("idp_identifiers", idp.IdpIdentifiers)
	d.Set("provider_details", idp.ProviderDetails)
	d.Set(names.AttrProviderName, idp.ProviderName)
	d.Set("provider_type", idp.ProviderType)
	d.Set(names.AttrUserPoolID, idp.UserPoolId)
	return diags
}

func identityProviderParseResourceID(id string) (string, string, error) {
	parts := strings.Split(id, identityProviderResourceIDSeparator)
	if len(parts) == 2 && parts[0] != "" && parts[1] != "" {
		return parts[0], parts[1], nil
	}
	return "", "", fmt.Errorf("unexpected format for ID (%[1]s), expected UserPoolID%[2]sProviderName", id, identityProviderResourceIDSeparator)
}

func findIdentityProviderByTwoPartKey(ctx context.Context, conn *cognitoidentityprovider.Client, userPoolID, providerName string) (*awstypes.IdentityProviderType, error) {
	input := &cognitoidentityprovider.DescribeIdentityProviderInput{ProviderName: aws.String(providerName), UserPoolId: aws.String(userPoolID)}
	output, err := conn.DescribeIdentityProvider(ctx, input)
	if errs.IsA[*awstypes.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.IdentityProvider == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output.IdentityProvider, nil
}

