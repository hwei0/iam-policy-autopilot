package wafregional

import (
	"context"
	"fmt"
	"log"
	"slices"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/wafregional"
	awstypes "github.com/aws/aws-sdk-go-v2/service/wafregional/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceRuleGroupCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).WAFRegionalClient(ctx)
	region := meta.(*conns.AWSClient).Region(ctx)
	name := d.Get(names.AttrName).(string)
	outputRaw, err := newRetryer(conn, region).RetryWithToken(ctx, func(token *string) (any, error) {
		input := &wafregional.CreateRuleGroupInput{ChangeToken: token, MetricName: aws.String(d.Get(names.AttrMetricName).(string)), Name: aws.String(name), Tags: getTagsIn(ctx)}
		return conn.CreateRuleGroup(ctx, input)
	})
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating WAF Regional Rule Group (%s): %s", name, err)
	}
	d.SetId(aws.ToString(outputRaw.(*wafregional.CreateRuleGroupOutput).RuleGroup.RuleGroupId))
	if activatedRule := d.Get("activated_rule").(*schema.Set).List(); len(activatedRule) > 0 {
		noActivatedRules := []any{}
		if err := updateRuleGroup(ctx, conn, region, d.Id(), noActivatedRules, activatedRule); err != nil {
			return sdkdiag.AppendFromErr(diags, err)
		}
	}
	return append(diags, resourceRuleGroupRead(ctx, d, meta)...)
}

func (t *retryer) RetryWithToken(ctx context.Context, f withTokenFunc) (any, error) {
	key := "WafRetryer-" + t.region
	conns.GlobalMutexKV.Lock(key)
	defer conns.GlobalMutexKV.Unlock(key)
	const (
		timeout = 15 * time.Minute
	)
	return tfresource.RetryWhenIsA[any, *awstypes.WAFStaleDataException](ctx, timeout, func(ctx context.Context) (any, error) {
		input := &wafregional.GetChangeTokenInput{}
		output, err := t.connection.GetChangeToken(ctx, input)
		if err != nil {
			return nil, fmt.Errorf("acquiring WAF Regional change token: %w", err)
		}
		return f(output.ChangeToken)
	})
}

func newRetryer(conn *wafregional.Client, region string) *retryer {
	return &retryer{connection: conn, region: region}
}

func updateRuleGroup(ctx context.Context, conn *wafregional.Client, region, ruleGroupID string, oldRules, newRules []any) error {
	_, err := newRetryer(conn, region).RetryWithToken(ctx, func(token *string) (any, error) {
		input := &wafregional.UpdateRuleGroupInput{ChangeToken: token, RuleGroupId: aws.String(ruleGroupID), Updates: diffRuleGroupActivatedRules(oldRules, newRules)}
		return conn.UpdateRuleGroup(ctx, input)
	})
	if err != nil {
		return fmt.Errorf("updating WAF Regional Rule Group (%s): %w", ruleGroupID, err)
	}
	return nil
}

func diffRuleGroupActivatedRules(oldRules, newRules []any) []awstypes.RuleGroupUpdate {
	updates := make([]awstypes.RuleGroupUpdate, 0)
	for _, op := range oldRules {
		rule := op.(map[string]any)
		if idx, contains := sliceContainsMap(newRules, rule); contains {
			newRules = slices.Delete(newRules, idx, idx+1)
			continue
		}
		updates = append(updates, awstypes.RuleGroupUpdate{Action: awstypes.ChangeActionDelete, ActivatedRule: expandActivatedRule(rule)})
	}
	for _, np := range newRules {
		rule := np.(map[string]any)
		updates = append(updates, awstypes.RuleGroupUpdate{Action: awstypes.ChangeActionInsert, ActivatedRule: expandActivatedRule(rule)})
	}
	return updates
}

func sliceContainsMap(l []any, m map[string]any) (int, bool) {
	for i, t := range l {
		if reflect.DeepEqual(m, t.(map[string]any)) {
			return i, true
		}
	}
	return -1, false
}

func expandActivatedRule(rule map[string]any) *awstypes.ActivatedRule {
	r := &awstypes.ActivatedRule{Priority: aws.Int32(int32(rule[names.AttrPriority].(int))), RuleId: aws.String(rule["rule_id"].(string)), Type: awstypes.WafRuleType(rule[names.AttrType].(string))}
	if a, ok := rule[names.AttrAction].([]any); ok && len(a) > 0 {
		m := a[0].(map[string]any)
		r.Action = &awstypes.WafAction{Type: awstypes.WafActionType(m[names.AttrType].(string))}
	}
	return r
}

func resourceRuleGroupRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).WAFRegionalClient(ctx)
	ruleGroup, err := findRuleGroupByID(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] WAF Regional Rule Group (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading WAF Regional Rule Group (%s): %s", d.Id(), err)
	}
	var activatedRules []awstypes.ActivatedRule
	input := &wafregional.ListActivatedRulesInRuleGroupInput{RuleGroupId: aws.String(d.Id())}
	err = listActivatedRulesInRuleGroupPages(ctx, conn, input, func(page *wafregional.ListActivatedRulesInRuleGroupOutput, lastPage bool) bool {
		if page == nil {
			return !lastPage
		}
		activatedRules = append(activatedRules, page.ActivatedRules...)
		return !lastPage
	})
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "listing WAF Regional Rule Group (%s) activated rules: %s", d.Id(), err)
	}
	if err := d.Set("activated_rule", flattenActivatedRules(activatedRules)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting activated_rule: %s", err)
	}
	arn := arn.ARN{Partition: meta.(*conns.AWSClient).Partition(ctx), Service: "waf-regional", Region: meta.(*conns.AWSClient).Region(ctx), AccountID: meta.(*conns.AWSClient).AccountID(ctx), Resource: "rulegroup/" + d.Id()}.String()
	d.Set(names.AttrARN, arn)
	d.Set(names.AttrMetricName, ruleGroup.MetricName)
	d.Set(names.AttrName, ruleGroup.Name)
	return diags
}

func findRuleGroupByID(ctx context.Context, conn *wafregional.Client, id string) (*awstypes.RuleGroup, error) {
	input := &wafregional.GetRuleGroupInput{RuleGroupId: aws.String(id)}
	output, err := conn.GetRuleGroup(ctx, input)
	if errs.IsA[*awstypes.WAFNonexistentItemException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.RuleGroup == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output.RuleGroup, nil
}

func listActivatedRulesInRuleGroupPages(ctx context.Context, conn *wafregional.Client, input *wafregional.ListActivatedRulesInRuleGroupInput, fn func(*wafregional.ListActivatedRulesInRuleGroupOutput, bool) bool, optFns ...func(*wafregional.Options)) error {
	for {
		output, err := conn.ListActivatedRulesInRuleGroup(ctx, input, optFns...)
		if err != nil {
			return smarterr.NewError(err)
		}
		lastPage := aws.ToString(output.NextMarker) == ""
		if !fn(output, lastPage) || lastPage {
			break
		}
		input.NextMarker = output.NextMarker
	}
	return nil
}

func flattenActivatedRules(activatedRules []awstypes.ActivatedRule) []any {
	out := make([]any, len(activatedRules))
	for i, ar := range activatedRules {
		rule := map[string]any{names.AttrPriority: aws.ToInt32(ar.Priority), "rule_id": aws.ToString(ar.RuleId), names.AttrType: string(ar.Type)}
		if ar.Action != nil {
			rule[names.AttrAction] = []any{map[string]any{names.AttrType: ar.Action.Type}}
		}
		out[i] = rule
	}
	return out
}

