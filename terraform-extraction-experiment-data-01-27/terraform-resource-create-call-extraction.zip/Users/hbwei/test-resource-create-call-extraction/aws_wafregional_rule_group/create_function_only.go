package wafregional

import (
	"context"
	"fmt"
	"log"
	"slices"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/wafregional"
	awstypes "github.com/aws/aws-sdk-go-v2/service/wafregional/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceRuleGroupCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).WAFRegionalClient(ctx)
	region := meta.(*conns.AWSClient).Region(ctx)
	name := d.Get(names.AttrName).(string)
	outputRaw, err := newRetryer(conn, region).RetryWithToken(ctx, func(token *string) (any, error) {
		input := &wafregional.CreateRuleGroupInput{ChangeToken: token, MetricName: aws.String(d.Get(names.AttrMetricName).(string)), Name: aws.String(name), Tags: getTagsIn(ctx)}
		return conn.CreateRuleGroup(ctx, input)
	})
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating WAF Regional Rule Group (%s): %s", name, err)
	}
	d.SetId(aws.ToString(outputRaw.(*wafregional.CreateRuleGroupOutput).RuleGroup.RuleGroupId))
	if activatedRule := d.Get("activated_rule").(*schema.Set).List(); len(activatedRule) > 0 {
		noActivatedRules := []any{}
		if err := updateRuleGroup(ctx, conn, region, d.Id(), noActivatedRules, activatedRule); err != nil {
			return sdkdiag.AppendFromErr(diags, err)
		}
	}
	return append(diags, resourceRuleGroupRead(ctx, d, meta)...)
}

