package wafregional

import (
	"context"
	"fmt"
	"log"
	"slices"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/wafregional"
	awstypes "github.com/aws/aws-sdk-go-v2/service/wafregional/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func (t *retryer) RetryWithToken(ctx context.Context, f withTokenFunc) (any, error) {
	key := "WafRetryer-" + t.region
	conns.GlobalMutexKV.Lock(key)
	defer conns.GlobalMutexKV.Unlock(key)
	const (
		timeout = 15 * time.Minute
	)
	return tfresource.RetryWhenIsA[any, *awstypes.WAFStaleDataException](ctx, timeout, func(ctx context.Context) (any, error) {
		input := &wafregional.GetChangeTokenInput{}
		output, err := t.connection.GetChangeToken(ctx, input)
		if err != nil {
			return nil, fmt.Errorf("acquiring WAF Regional change token: %w", err)
		}
		return f(output.ChangeToken)
	})
}

func newRetryer(conn *wafregional.Client, region string) *retryer {
	return &retryer{connection: conn, region: region}
}

