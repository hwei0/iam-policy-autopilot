package lambda

import (
	"context"
	"log"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/lambda"
	awstypes "github.com/aws/aws-sdk-go-v2/service/lambda/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceCodeSigningConfigCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).LambdaClient(ctx)
	input := &lambda.CreateCodeSigningConfigInput{AllowedPublishers: expandAllowedPublishers(d.Get("allowed_publishers").([]any)), Description: aws.String(d.Get(names.AttrDescription).(string)), Tags: getTagsIn(ctx)}
	if v, ok := d.GetOk("policies"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		input.CodeSigningPolicies = &awstypes.CodeSigningPolicies{UntrustedArtifactOnDeployment: awstypes.CodeSigningPolicy(tfMap["untrusted_artifact_on_deployment"].(string))}
	}
	output, err := conn.CreateCodeSigningConfig(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Lambda Code Signing Config: %s", err)
	}
	d.SetId(aws.ToString(output.CodeSigningConfig.CodeSigningConfigArn))
	return append(diags, resourceCodeSigningConfigRead(ctx, d, meta)...)
}

