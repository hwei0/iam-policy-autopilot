package directconnect

import (
	"context"
	"fmt"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/directconnect"
	awstypes "github.com/aws/aws-sdk-go-v2/service/directconnect/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceHostedTransitVirtualInterfaceAccepterCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).DirectConnectClient(ctx)
	vifID := d.Get("virtual_interface_id").(string)
	input := &directconnect.ConfirmTransitVirtualInterfaceInput{DirectConnectGatewayId: aws.String(d.Get("dx_gateway_id").(string)), VirtualInterfaceId: aws.String(vifID)}
	_, err := conn.ConfirmTransitVirtualInterface(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "accepting Direct Connect Hosted Transit Virtual Interface (%s): %s", vifID, err)
	}
	d.SetId(vifID)
	arn := arn.ARN{Partition: meta.(*conns.AWSClient).Partition(ctx), Region: meta.(*conns.AWSClient).Region(ctx), Service: "directconnect", AccountID: meta.(*conns.AWSClient).AccountID(ctx), Resource: fmt.Sprintf("dxvif/%s", d.Id())}.String()
	d.Set(names.AttrARN, arn)
	if _, err := waitHostedTransitVirtualInterfaceAccepterAvailable(ctx, conn, d.Id(), d.Timeout(schema.TimeoutCreate)); err != nil {
		return sdkdiag.AppendErrorf(diags, "waiting for Direct Connect Hosted Transit Virtual Interface Accepter (%s) create: %s", d.Id(), err)
	}
	if err := createTags(ctx, conn, arn, getTagsIn(ctx)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting Direct Connect Hosted Transit Virtual Interface (%s) tags: %s", arn, err)
	}
	return append(diags, resourceHostedTransitVirtualInterfaceAccepterUpdate(ctx, d, meta)...)
}

