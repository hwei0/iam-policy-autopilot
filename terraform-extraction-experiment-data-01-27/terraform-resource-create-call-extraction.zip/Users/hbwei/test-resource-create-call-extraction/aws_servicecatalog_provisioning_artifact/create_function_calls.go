package servicecatalog

import (
	"context"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/servicecatalog"
	awstypes "github.com/aws/aws-sdk-go-v2/service/servicecatalog/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceProvisioningArtifactCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ServiceCatalogClient(ctx)
	parameters := make(map[string]any)
	parameters[names.AttrDescription] = d.Get(names.AttrDescription)
	parameters["disable_template_validation"] = d.Get("disable_template_validation")
	parameters[names.AttrName] = d.Get(names.AttrName)
	parameters["template_physical_id"] = d.Get("template_physical_id")
	parameters["template_url"] = d.Get("template_url")
	parameters[names.AttrType] = d.Get(names.AttrType)
	input := &servicecatalog.CreateProvisioningArtifactInput{IdempotencyToken: aws.String(id.UniqueId()), Parameters: expandProvisioningArtifactParameters(parameters), ProductId: aws.String(d.Get("product_id").(string))}
	if v, ok := d.GetOk("accept_language"); ok {
		input.AcceptLanguage = aws.String(v.(string))
	}
	var output *servicecatalog.CreateProvisioningArtifactOutput
	err := tfresource.Retry(ctx, d.Timeout(schema.TimeoutCreate), func(ctx context.Context) *tfresource.RetryError {
		var err error
		output, err = conn.CreateProvisioningArtifact(ctx, input)
		if errs.IsAErrorMessageContains[*awstypes.InvalidParametersException](err, "profile does not exist") {
			return tfresource.RetryableError(err)
		}
		if err != nil {
			return tfresource.NonRetryableError(err)
		}
		return nil
	})
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Service Catalog Provisioning Artifact: %s", err)
	}
	if output == nil || output.ProvisioningArtifactDetail == nil || output.ProvisioningArtifactDetail.Id == nil {
		return sdkdiag.AppendErrorf(diags, "creating Service Catalog Provisioning Artifact: empty response")
	}
	d.SetId(provisioningArtifactID(aws.ToString(output.ProvisioningArtifactDetail.Id), d.Get("product_id").(string)))
	return append(diags, resourceProvisioningArtifactUpdate(ctx, d, meta)...)
}

func expandProvisioningArtifactParameters(tfMap map[string]any) *awstypes.ProvisioningArtifactProperties {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.ProvisioningArtifactProperties{}
	if v, ok := tfMap[names.AttrDescription].(string); ok && v != "" {
		apiObject.Description = aws.String(v)
	}
	if v, ok := tfMap["disable_template_validation"].(bool); ok {
		apiObject.DisableTemplateValidation = v
	}
	info := make(map[string]string)
	if v, ok := tfMap["template_physical_id"].(string); ok && v != "" {
		info["ImportFromPhysicalId"] = v
	}
	if v, ok := tfMap["template_url"].(string); ok && v != "" {
		info["LoadTemplateFromURL"] = v
	}
	apiObject.Info = info
	if v, ok := tfMap[names.AttrName].(string); ok && v != "" {
		apiObject.Name = aws.String(v)
	}
	if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
		apiObject.Type = awstypes.ProvisioningArtifactType(v)
	}
	return apiObject
}

func provisioningArtifactID(artifactID, productID string) string {
	return strings.Join([]string{artifactID, productID}, ":")
}

func resourceProvisioningArtifactUpdate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ServiceCatalogClient(ctx)
	if d.HasChanges("accept_language", "active", names.AttrDescription, "guidance", names.AttrName, "product_id") {
		artifactID, productID, err := provisioningArtifactParseID(d.Id())
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "parsing Service Catalog Provisioning Artifact ID (%s): %s", d.Id(), err)
		}
		input := &servicecatalog.UpdateProvisioningArtifactInput{ProductId: aws.String(productID), ProvisioningArtifactId: aws.String(artifactID), Active: aws.Bool(d.Get("active").(bool))}
		if v, ok := d.GetOk("accept_language"); ok {
			input.AcceptLanguage = aws.String(v.(string))
		}
		if v, ok := d.GetOk(names.AttrDescription); ok {
			input.Description = aws.String(v.(string))
		}
		if v, ok := d.GetOk("guidance"); ok {
			input.Guidance = awstypes.ProvisioningArtifactGuidance(v.(string))
		}
		if v, ok := d.GetOk(names.AttrName); ok {
			input.Name = aws.String(v.(string))
		}
		err = tfresource.Retry(ctx, d.Timeout(schema.TimeoutUpdate), func(ctx context.Context) *tfresource.RetryError {
			_, err := conn.UpdateProvisioningArtifact(ctx, input)
			if errs.IsAErrorMessageContains[*awstypes.InvalidParametersException](err, "profile does not exist") {
				return tfresource.RetryableError(err)
			}
			if err != nil {
				return tfresource.NonRetryableError(err)
			}
			return nil
		})
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "updating Service Catalog Provisioning Artifact (%s): %s", d.Id(), err)
		}
	}
	return append(diags, resourceProvisioningArtifactRead(ctx, d, meta)...)
}

func provisioningArtifactParseID(id string) (string, string, error) {
	parts := strings.SplitN(id, ":", 2)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return "", "", fmt.Errorf("unexpected format of ID (%s), expected artifactID:productID", id)
	}
	return parts[0], parts[1], nil
}

func resourceProvisioningArtifactRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ServiceCatalogClient(ctx)
	artifactID, productID, err := provisioningArtifactParseID(d.Id())
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "parsing Service Catalog Provisioning Artifact ID (%s): %s", d.Id(), err)
	}
	output, err := waitProvisioningArtifactReady(ctx, conn, artifactID, productID, d.Timeout(schema.TimeoutRead))
	if !d.IsNewResource() && errs.IsA[*awstypes.ResourceNotFoundException](err) {
		log.Printf("[WARN] Service Catalog Provisioning Artifact (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "describing Service Catalog Provisioning Artifact (%s): %s", d.Id(), err)
	}
	if output == nil || output.ProvisioningArtifactDetail == nil {
		return sdkdiag.AppendErrorf(diags, "getting Service Catalog Provisioning Artifact (%s): empty response", d.Id())
	}
	if v, ok := output.Info["ImportFromPhysicalId"]; ok {
		d.Set("template_physical_id", v)
	}
	if v, ok := output.Info["LoadTemplateFromURL"]; ok {
		d.Set("template_url", v)
	}
	pad := output.ProvisioningArtifactDetail
	d.Set("active", pad.Active)
	if pad.CreatedTime != nil {
		d.Set(names.AttrCreatedTime, pad.CreatedTime.Format(time.RFC3339))
	}
	d.Set(names.AttrDescription, pad.Description)
	d.Set("guidance", pad.Guidance)
	d.Set(names.AttrName, pad.Name)
	d.Set("product_id", productID)
	d.Set("provisioning_artifact_id", artifactID)
	d.Set(names.AttrType, pad.Type)
	return diags
}

func waitProvisioningArtifactReady(ctx context.Context, conn *servicecatalog.Client, id, productID string, timeout time.Duration) (*servicecatalog.DescribeProvisioningArtifactOutput, error) {
	stateConf := &retry.StateChangeConf{Pending: enum.Slice(awstypes.StatusCreating, statusNotFound, statusUnavailable), Target: enum.Slice(awstypes.StatusAvailable, statusCreated), Refresh: statusProvisioningArtifact(ctx, conn, id, productID), Timeout: timeout, ContinuousTargetOccurence: continuousTargetOccurrence, NotFoundChecks: notFoundChecks, MinTimeout: minTimeout}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*servicecatalog.DescribeProvisioningArtifactOutput); ok {
		return output, err
	}
	return nil, err
}

func statusProvisioningArtifact(ctx context.Context, conn *servicecatalog.Client, id, productID string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		input := &servicecatalog.DescribeProvisioningArtifactInput{ProvisioningArtifactId: aws.String(id), ProductId: aws.String(productID)}
		output, err := conn.DescribeProvisioningArtifact(ctx, input)
		if errs.IsA[*awstypes.ResourceNotFoundException](err) {
			return nil, statusNotFound, err
		}
		if err != nil {
			return nil, string(awstypes.StatusFailed), err
		}
		if output == nil || output.ProvisioningArtifactDetail == nil {
			return nil, statusUnavailable, err
		}
		return output, string(output.Status), err
	}
}

