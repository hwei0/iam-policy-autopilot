package servicecatalog

import (
	"context"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/servicecatalog"
	awstypes "github.com/aws/aws-sdk-go-v2/service/servicecatalog/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceProvisioningArtifactCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ServiceCatalogClient(ctx)
	parameters := make(map[string]any)
	parameters[names.AttrDescription] = d.Get(names.AttrDescription)
	parameters["disable_template_validation"] = d.Get("disable_template_validation")
	parameters[names.AttrName] = d.Get(names.AttrName)
	parameters["template_physical_id"] = d.Get("template_physical_id")
	parameters["template_url"] = d.Get("template_url")
	parameters[names.AttrType] = d.Get(names.AttrType)
	input := &servicecatalog.CreateProvisioningArtifactInput{IdempotencyToken: aws.String(id.UniqueId()), Parameters: expandProvisioningArtifactParameters(parameters), ProductId: aws.String(d.Get("product_id").(string))}
	if v, ok := d.GetOk("accept_language"); ok {
		input.AcceptLanguage = aws.String(v.(string))
	}
	var output *servicecatalog.CreateProvisioningArtifactOutput
	err := tfresource.Retry(ctx, d.Timeout(schema.TimeoutCreate), func(ctx context.Context) *tfresource.RetryError {
		var err error
		output, err = conn.CreateProvisioningArtifact(ctx, input)
		if errs.IsAErrorMessageContains[*awstypes.InvalidParametersException](err, "profile does not exist") {
			return tfresource.RetryableError(err)
		}
		if err != nil {
			return tfresource.NonRetryableError(err)
		}
		return nil
	})
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Service Catalog Provisioning Artifact: %s", err)
	}
	if output == nil || output.ProvisioningArtifactDetail == nil || output.ProvisioningArtifactDetail.Id == nil {
		return sdkdiag.AppendErrorf(diags, "creating Service Catalog Provisioning Artifact: empty response")
	}
	d.SetId(provisioningArtifactID(aws.ToString(output.ProvisioningArtifactDetail.Id), d.Get("product_id").(string)))
	return append(diags, resourceProvisioningArtifactUpdate(ctx, d, meta)...)
}

