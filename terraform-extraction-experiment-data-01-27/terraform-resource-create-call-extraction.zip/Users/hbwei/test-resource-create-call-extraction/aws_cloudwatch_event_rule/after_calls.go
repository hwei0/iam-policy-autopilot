package events

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/create"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandPutRuleInput(d *schema.ResourceData, name string) *eventbridge.PutRuleInput {
	apiObject := &eventbridge.PutRuleInput{Name: aws.String(name)}
	if v, ok := d.GetOk(names.AttrDescription); ok {
		apiObject.Description = aws.String(v.(string))
	}
	if v, ok := d.GetOk("event_bus_name"); ok {
		apiObject.EventBusName = aws.String(v.(string))
	}
	if v, ok := d.GetOk("event_pattern"); ok {
		json, _ := ruleEventPatternJSONDecoder(v.(string))
		apiObject.EventPattern = aws.String(json)
	}
	if v, ok := d.GetOk(names.AttrRoleARN); ok {
		apiObject.RoleArn = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrScheduleExpression); ok {
		apiObject.ScheduleExpression = aws.String(v.(string))
	}
	rawConfig := d.GetRawConfig()
	rawState := rawConfig.GetAttr(names.AttrState)
	if rawState.IsKnown() && !rawState.IsNull() {
		apiObject.State = types.RuleState(rawState.AsString())
	} else {
		rawIsEnabled := rawConfig.GetAttr("is_enabled")
		if rawIsEnabled.IsKnown() && !rawIsEnabled.IsNull() {
			if rawIsEnabled.True() {
				apiObject.State = types.RuleStateEnabled
			} else {
				apiObject.State = types.RuleStateDisabled
			}
		}
	}
	return apiObject
}

func ruleEventPatternJSONDecoder(jsonString any) (string, error) {
	var j any
	if jsonString == nil || jsonString.(string) == "" {
		return "", nil
	}
	s := jsonString.(string)
	err := json.Unmarshal([ // ruleEventPatternJSONDecoder decodes unicode translation of <,>,&
	]byte(s), &j)
	if err != nil {
		return s, err
	}
	b, err := json.Marshal(j)
	if err != nil {
		return "", err
	}
	if bytes.Contains(b, []byte("\\u003c")) || bytes.Contains(b, []byte("\\u003e")) || bytes.Contains(b, []byte("\\u0026")) {
		b = bytes.Replace(b, []byte("\\u003c"), []byte("<"), -1)
		b = bytes.Replace(b, []byte("\\u003e"), []byte(">"), -1)
		b = bytes.Replace(b, []byte("\\u0026"), []byte("&"), -1)
	}
	return string(b[:]), nil
}

func retryPutRule(ctx context.Context, conn *eventbridge.Client, input *eventbridge.PutRuleInput) (string, error) {
	outputRaw, err := tfresource.RetryWhenAWSErrMessageContains(ctx, propagationTimeout, func(ctx context.Context) (any, error) {
		return conn.PutRule(ctx, input)
	}, errCodeValidationException, "cannot be assumed by principal")
	if err != nil {
		return "", err
	}
	return aws.ToString(outputRaw.(*eventbridge.PutRuleOutput).RuleArn), nil
}

func ruleCreateResourceID(eventBusName, ruleName string) string {
	if eventBusName == "" || eventBusName == DefaultEventBusName {
		return ruleName
	}
	parts := []string{eventBusName, ruleName}
	id := strings.Join(parts, ruleResourceIDSeparator)
	return id
}

func findRuleByTwoPartKey(ctx context.Context, conn *eventbridge.Client, eventBusName, ruleName string) (*eventbridge.DescribeRuleOutput, error) {
	input := &eventbridge.DescribeRuleInput{Name: aws.String(ruleName)}
	if eventBusName != "" {
		input.EventBusName = aws.String(eventBusName)
	}
	output, err := conn.DescribeRule(ctx, input)
	if errs.IsA[*types.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func resourceRuleRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EventsClient(ctx)
	eventBusName, ruleName, err := ruleParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	output, err := findRuleByTwoPartKey(ctx, conn, eventBusName, ruleName)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] EventBridge Rule (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading EventBridge Rule (%s): %s", d.Id(), err)
	}
	arn := aws.ToString(output.Arn)
	d.Set(names.AttrARN, arn)
	d.Set(names.AttrDescription, output.Description)
	d.Set("event_bus_name", eventBusName)
	if output.EventPattern != nil {
		pattern, err := ruleEventPatternJSONDecoder(aws.ToString(output.EventPattern))
		if err != nil {
			return sdkdiag.AppendFromErr(diags, err)
		}
		d.Set("event_pattern", pattern)
	}
	d.Set(names.AttrForceDestroy, d.Get(names.AttrForceDestroy).(bool))
	switch output.State {
	case types.RuleStateEnabled, types.RuleStateEnabledWithAllCloudtrailManagementEvents:
		d.Set("is_enabled", true)
	default:
		d.Set("is_enabled", false)
	}
	d.Set(names.AttrName, output.Name)
	d.Set(names.AttrNamePrefix, create.NamePrefixFromName(aws.ToString(output.Name)))
	d.Set(names.AttrRoleARN, output.RoleArn)
	d.Set(names.AttrScheduleExpression, output.ScheduleExpression)
	d.Set(names.AttrState, output.State)
	return diags
}

func ruleParseResourceID(id string) (string, string, error) {
	parts := strings.Split(id, ruleResourceIDSeparator)
	if len(parts) == 1 && parts[0] != "" {
		return DefaultEventBusName, parts[0], nil
	}
	if len(parts) == 2 && parts[0] != "" && parts[1] != "" {
		return parts[0], parts[1], nil
	}
	if len(parts) > 2 {
		i := strings.LastIndex(id, ruleResourceIDSeparator)
		eventBusName := id[:i]
		ruleName := id[i+1:]
		if eventBusARNPattern.MatchString(eventBusName) && ruleName != "" {
			return eventBusName, ruleName, nil
		}
		if partnerEventBusPattern.MatchString(eventBusName) && ruleName != "" {
			return eventBusName, ruleName, nil
		}
	}
	return "", "", fmt.Errorf("unexpected format for ID (%[1]s), expected EVENTBUSNAME%[2]sRULENAME or RULENAME", id, ruleResourceIDSeparator)
}

