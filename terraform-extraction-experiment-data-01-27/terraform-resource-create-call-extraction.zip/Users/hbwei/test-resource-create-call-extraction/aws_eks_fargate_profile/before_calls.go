package eks

import (
	"context"
	"fmt"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/eks"
	"github.com/aws/aws-sdk-go-v2/service/eks/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func FargateProfileCreateResourceID(clusterName, fargateProfileName string) string {
	parts := []string{clusterName, fargateProfileName}
	id := strings.Join(parts, fargateProfileResourceIDSeparator)
	return id
}

func expandFargateProfileSelectors(l []any) []types.FargateProfileSelector {
	if len(l) == 0 {
		return nil
	}
	fargateProfileSelectors := make([]types.FargateProfileSelector, 0, len(l))
	for _, mRaw := range l {
		m, ok := mRaw.(map[string]any)
		if !ok {
			continue
		}
		fargateProfileSelector := types.FargateProfileSelector{}
		if v, ok := m["labels"].(map[string]any); ok && len(v) > 0 {
			fargateProfileSelector.Labels = flex.ExpandStringValueMap(v)
		}
		if v, ok := m[names.AttrNamespace].(string); ok && v != "" {
			fargateProfileSelector.Namespace = aws.String(v)
		}
		fargateProfileSelectors = append(fargateProfileSelectors, fargateProfileSelector)
	}
	return fargateProfileSelectors
}

