package eks

import (
	"context"
	"fmt"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/eks"
	"github.com/aws/aws-sdk-go-v2/service/eks/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceFargateProfileCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EKSClient(ctx)
	clusterName := d.Get(names.AttrClusterName).(string)
	fargateProfileName := d.Get("fargate_profile_name").(string)
	profileID := FargateProfileCreateResourceID(clusterName, fargateProfileName)
	input := &eks.CreateFargateProfileInput{ClientRequestToken: aws.String(id.UniqueId()), ClusterName: aws.String(clusterName), FargateProfileName: aws.String(fargateProfileName), PodExecutionRoleArn: aws.String(d.Get("pod_execution_role_arn").(string)), Selectors: expandFargateProfileSelectors(d.Get("selector").(*schema.Set).List()), Subnets: flex.ExpandStringValueSet(d.Get(names.AttrSubnetIDs).(*schema.Set)), Tags: getTagsIn(ctx)}
	mutexKey := fmt.Sprintf("%s-fargate-profiles", clusterName)
	conns.GlobalMutexKV.Lock(mutexKey)
	defer conns.GlobalMutexKV.Unlock(mutexKey)
	_, err := tfresource.RetryWhenIsAErrorMessageContains[any, *types.InvalidParameterException](ctx, propagationTimeout, func(ctx context.Context) (any, error) {
		return conn.CreateFargateProfile(ctx, input)
	}, "Misconfigured PodExecutionRole Trust Policy")
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating EKS Fargate Profile (%s): %s", profileID, err)
	}
	d.SetId(profileID)
	if _, err := waitFargateProfileCreated(ctx, conn, clusterName, fargateProfileName, d.Timeout(schema.TimeoutCreate)); err != nil {
		return sdkdiag.AppendErrorf(diags, "waiting for EKS Fargate Profile (%s) create: %s", d.Id(), err)
	}
	return append(diags, resourceFargateProfileRead(ctx, d, meta)...)
}

