package eks

import (
	"context"
	"fmt"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/eks"
	"github.com/aws/aws-sdk-go-v2/service/eks/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func waitFargateProfileCreated(ctx context.Context, conn *eks.Client, clusterName, fargateProfileName string, timeout time.Duration) (*types.FargateProfile, error) {
	stateConf := &retry.StateChangeConf{Pending: enum.Slice(types.FargateProfileStatusCreating), Target: enum.Slice(types.FargateProfileStatusActive), Refresh: statusFargateProfile(ctx, conn, clusterName, fargateProfileName), Timeout: timeout}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*types.FargateProfile); ok {
		return output, err
	}
	return nil, err
}

func statusFargateProfile(ctx context.Context, conn *eks.Client, clusterName, fargateProfileName string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findFargateProfileByTwoPartKey(ctx, conn, clusterName, fargateProfileName)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return nil, "", err
		}
		return output, string(output.Status), nil
	}
}

func findFargateProfileByTwoPartKey(ctx context.Context, conn *eks.Client, clusterName, fargateProfileName string) (*types.FargateProfile, error) {
	input := &eks.DescribeFargateProfileInput{ClusterName: aws.String(clusterName), FargateProfileName: aws.String(fargateProfileName)}
	output, err := conn.DescribeFargateProfile(ctx, input)
	if errs.IsA[*types.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.FargateProfile == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output.FargateProfile, nil
}

func resourceFargateProfileRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EKSClient(ctx)
	clusterName, fargateProfileName, err := FargateProfileParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	fargateProfile, err := findFargateProfileByTwoPartKey(ctx, conn, clusterName, fargateProfileName)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] EKS Fargate Profile (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading EKS Fargate Profile (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, fargateProfile.FargateProfileArn)
	d.Set(names.AttrClusterName, fargateProfile.ClusterName)
	d.Set("fargate_profile_name", fargateProfile.FargateProfileName)
	d.Set("pod_execution_role_arn", fargateProfile.PodExecutionRoleArn)
	if err := d.Set("selector", flattenFargateProfileSelectors(fargateProfile.Selectors)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting selector: %s", err)
	}
	d.Set(names.AttrStatus, fargateProfile.Status)
	d.Set(names.AttrSubnetIDs, fargateProfile.Subnets)
	setTagsOut(ctx, fargateProfile.Tags)
	return diags
}

func FargateProfileParseResourceID(id string) (string, string, error) {
	parts := strings.Split(id, fargateProfileResourceIDSeparator)
	if len(parts) == 2 && parts[0] != "" && parts[1] != "" {
		return parts[0], parts[1], nil
	}
	return "", "", fmt.Errorf("unexpected format for ID (%[1]s), expected cluster-name%[2]sfargate-profile-name", id, fargateProfileResourceIDSeparator)
}

func flattenFargateProfileSelectors(fargateProfileSelectors []types.FargateProfileSelector) []map[string]any {
	if len(fargateProfileSelectors) == 0 {
		return []map[string]any{}
	}
	l := make([]map[string]any, 0, len(fargateProfileSelectors))
	for _, fargateProfileSelector := range fargateProfileSelectors {
		m := map[string]any{"labels": fargateProfileSelector.Labels, names.AttrNamespace: aws.ToString(fargateProfileSelector.Namespace)}
		l = append(l, m)
	}
	return l
}

