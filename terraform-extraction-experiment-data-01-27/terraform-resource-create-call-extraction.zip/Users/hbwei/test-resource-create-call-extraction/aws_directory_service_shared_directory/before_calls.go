package ds

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/directoryservice"
	awstypes "github.com/aws/aws-sdk-go-v2/service/directoryservice/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandShareTarget(tfMap map[string]any) *awstypes.ShareTarget {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.ShareTarget{}
	if v, ok := tfMap[names.AttrID].(string); ok && len(v) > 0 {
		apiObject.Id = aws.String(v)
	}
	if v, ok := tfMap[names.AttrType].(string); ok && len(v) > 0 {
		apiObject.Type = awstypes.TargetType(v)
	}
	return apiObject
}

