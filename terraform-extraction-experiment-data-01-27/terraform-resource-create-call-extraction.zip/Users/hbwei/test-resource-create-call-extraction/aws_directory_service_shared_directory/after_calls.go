package ds

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/directoryservice"
	awstypes "github.com/aws/aws-sdk-go-v2/service/directoryservice/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func sharedDirectoryCreateResourceID(ownerDirectoryID, sharedDirectoryID string) string {
	parts := []string{ownerDirectoryID, sharedDirectoryID}
	id := strings.Join(parts, sharedDirectoryResourceIDSeparator)
	return id
}

func resourceSharedDirectoryRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).DSClient(ctx)
	ownerDirID, sharedDirID, err := sharedDirectoryParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	output, err := findSharedDirectoryByTwoPartKey(ctx, conn, ownerDirID, sharedDirID)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Directory Service Shared Directory (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Directory Service Shared Directory (%s): %s", d.Id(), err)
	}
	d.Set("directory_id", output.OwnerDirectoryId)
	d.Set("method", output.ShareMethod)
	d.Set("notes", output.ShareNotes)
	d.Set("shared_directory_id", output.SharedDirectoryId)
	if output.SharedAccountId != nil {
		if err := d.Set(names.AttrTarget, []any{flattenShareTarget(output)}); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting target: %s", err)
		}
	} else {
		d.Set(names.AttrTarget, nil)
	}
	return diags
}

func sharedDirectoryParseResourceID(id string) (string, string, error) {
	parts := strings.SplitN(id, sharedDirectoryResourceIDSeparator, 2)
	if len(parts) == 2 && parts[0] != "" && parts[1] != "" {
		return parts[0], parts[1], nil
	}
	return "", "", fmt.Errorf("unexpected format for ID (%[1]s), expected OWNER_DIRECTORY_ID%[2]sSHARED_DIRECTORY_ID", id, sharedDirectoryResourceIDSeparator)
}

func findSharedDirectoryByTwoPartKey(ctx context.Context, conn *directoryservice.Client, ownerDirectoryID, sharedDirectoryID string) (*awstypes.SharedDirectory, error) {
	input := &directoryservice.DescribeSharedDirectoriesInput{OwnerDirectoryId: aws.String(ownerDirectoryID), SharedDirectoryIds: []string{sharedDirectoryID}}
	output, err := findSharedDirectory(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	if status := output.ShareStatus; status == awstypes.ShareStatusDeleted {
		return nil, &retry.NotFoundError{Message: string(status), LastRequest: input}
	}
	return output, nil
}

func findSharedDirectory(ctx context.Context, conn *directoryservice.Client, input *directoryservice.DescribeSharedDirectoriesInput) (*awstypes.SharedDirectory, error) {
	output, err := findSharedDirectories(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findSharedDirectories(ctx context.Context, conn *directoryservice.Client, input *directoryservice.DescribeSharedDirectoriesInput) ([]awstypes.SharedDirectory, error) {
	var output []awstypes.SharedDirectory
	pages := directoryservice.NewDescribeSharedDirectoriesPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if errs.IsA[*awstypes.EntityDoesNotExistException](err) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
		}
		if err != nil {
			return nil, err
		}
		output = append(output, page.SharedDirectories...)
	}
	return output, nil
}

func flattenShareTarget(apiObject *awstypes.SharedDirectory) map // flattenShareTarget is not a mirror of expandShareTarget because the API data structures are
// different, with no ShareTarget returned.
[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if apiObject.SharedAccountId != nil {
		tfMap[names.AttrID] = aws.ToString(apiObject.SharedAccountId)
	}
	tfMap[names.AttrType] = awstypes.TargetTypeAccount
	return tfMap
}

