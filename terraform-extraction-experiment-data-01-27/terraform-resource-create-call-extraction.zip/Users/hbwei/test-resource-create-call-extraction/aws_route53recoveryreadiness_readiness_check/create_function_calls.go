package route53recoveryreadiness

import (
	"context"
	"fmt"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/route53recoveryreadiness"
	awstypes "github.com/aws/aws-sdk-go-v2/service/route53recoveryreadiness/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceReadinessCheckCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).Route53RecoveryReadinessClient(ctx)
	name := d.Get("readiness_check_name").(string)
	input := &route53recoveryreadiness.CreateReadinessCheckInput{ReadinessCheckName: aws.String(name), ResourceSetName: aws.String(d.Get("resource_set_name").(string))}
	output, err := conn.CreateReadinessCheck(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Route53 Recovery Readiness Readiness Check (%s): %s", name, err)
	}
	d.SetId(aws.ToString(output.ReadinessCheckName))
	if err := createTags(ctx, conn, aws.ToString(output.ReadinessCheckArn), getTagsIn(ctx)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting Route53 Recovery Readiness Readiness Check (%s) tags: %s", d.Id(), err)
	}
	return append(diags, resourceReadinessCheckRead(ctx, d, meta)...)
}

func resourceReadinessCheckRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).Route53RecoveryReadinessClient(ctx)
	output, err := findReadinessCheckByName(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Route53 Recovery Readiness Readiness Check (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Route53 Recovery Readiness Readiness Check (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, output.ReadinessCheckArn)
	d.Set("readiness_check_name", output.ReadinessCheckName)
	d.Set("resource_set_name", output.ResourceSet)
	return diags
}

func findReadinessCheckByName(ctx context.Context, conn *route53recoveryreadiness.Client, name string) (*route53recoveryreadiness.GetReadinessCheckOutput, error) {
	input := &route53recoveryreadiness.GetReadinessCheckInput{ReadinessCheckName: aws.String(name)}
	output, err := conn.GetReadinessCheck(ctx, input)
	if errs.IsA[*awstypes.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

