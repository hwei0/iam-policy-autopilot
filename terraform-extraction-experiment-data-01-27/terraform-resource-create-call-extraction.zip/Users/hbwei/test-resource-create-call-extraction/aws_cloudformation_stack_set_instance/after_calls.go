package cloudformation

import (
	"context"
	"fmt"
	"log"
	"slices"
	"strings"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/cloudformation"
	awstypes "github.com/aws/aws-sdk-go-v2/service/cloudformation/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	sdkid "github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/create"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	inttypes "github.com/hashicorp/terraform-provider-aws/internal/types"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func waitStackSetOperationSucceeded(ctx context.Context, conn *cloudformation.Client, stackSetName, operationID, callAs string, timeout time.Duration) (*awstypes.StackSetOperation, error) {
	const (
		stackSetOperationDelay = 10 * time.Second
	)
	stateConf := &retry.StateChangeConf{Pending: enum.Slice(awstypes.StackSetOperationStatusRunning, awstypes.StackSetOperationStatusQueued), Target: enum.Slice(awstypes.StackSetOperationStatusSucceeded), Refresh: statusStackSetOperation(ctx, conn, stackSetName, operationID, callAs), Timeout: timeout, Delay: stackSetOperationDelay}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*awstypes.StackSetOperation); ok {
		if output.Status == awstypes.StackSetOperationStatusFailed {
			if results, findErr := findStackSetOperationResultsByThreePartKey(ctx, conn, stackSetName, operationID, callAs); findErr == nil {
				tfresource.SetLastError(err, stackSetOperationError(results))
			}
		}
		return output, err
	}
	return nil, err
}

func statusStackSetOperation(ctx context.Context, conn *cloudformation.Client, stackSetName, operationID, callAs string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findStackSetOperationByThreePartKey(ctx, conn, stackSetName, operationID, callAs)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return nil, "", err
		}
		return output, string(output.Status), nil
	}
}

func findStackSetOperationByThreePartKey(ctx context.Context, conn *cloudformation.Client, stackSetName, operationID, callAs string) (*awstypes.StackSetOperation, error) {
	input := &cloudformation.DescribeStackSetOperationInput{OperationId: aws.String(operationID), StackSetName: aws.String(stackSetName)}
	if callAs != "" {
		input.CallAs = awstypes.CallAs(callAs)
	}
	output, err := conn.DescribeStackSetOperation(ctx, input)
	if errs.IsA[*awstypes.OperationNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.StackSetOperation == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output.StackSetOperation, nil
}

func findStackSetOperationResultsByThreePartKey(ctx context.Context, conn *cloudformation.Client, stackSetName, operationID, callAs string) ([]awstypes.StackSetOperationResultSummary, error) {
	input := &cloudformation.ListStackSetOperationResultsInput{OperationId: aws.String(operationID), StackSetName: aws.String(stackSetName)}
	if callAs != "" {
		input.CallAs = awstypes.CallAs(callAs)
	}
	return findStackSetOperationResults(ctx, conn, input)
}

func findStackSetOperationResults(ctx context.Context, conn *cloudformation.Client, input *cloudformation.ListStackSetOperationResultsInput) ([]awstypes.StackSetOperationResultSummary, error) {
	var summaries []awstypes.StackSetOperationResultSummary
	pages := cloudformation.NewListStackSetOperationResultsPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		summaries = append(summaries, page.Summaries...)
	}
	return summaries, nil
}

func stackSetOperationError(apiObjects []awstypes.StackSetOperationResultSummary) error {
	var errs []error
	for _, apiObject := range apiObjects {
		errs = append(errs, fmt.Errorf("Account (%s), Region (%s), %s: %s", aws.ToString(apiObject.Account), aws.ToString(apiObject.Region), string(apiObject.Status), aws.ToString(apiObject.StatusReason)))
	}
	return errors.Join(errs...)
}

func resourceStackSetInstanceRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).CloudFormationClient(ctx)
	parts, err := flex.ExpandResourceId(d.Id(), stackSetInstanceResourceIDPartCount, false)
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	stackSetName, accountOrOrgID, region := parts[0], parts[1], parts[2]
	d.Set(names.AttrRegion, region)
	d.Set("stack_set_instance_region", region)
	d.Set("stack_set_name", stackSetName)
	callAs := d.Get("call_as").(string)
	if inttypes.IsAWSAccountID(accountOrOrgID) {
		stackInstance, err := findStackInstanceByFourPartKey(ctx, conn, stackSetName, accountOrOrgID, region, callAs)
		if !d.IsNewResource() && tfresource.NotFound(err) {
			log.Printf("[WARN] CloudFormation StackSet Instance (%s) not found, removing from state", d.Id())
			d.SetId("")
			return diags
		}
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "reading CloudFormation StackSet Instance (%s): %s", d.Id(), err)
		}
		d.Set(names.AttrAccountID, stackInstance.Account)
		d.Set("organizational_unit_id", stackInstance.OrganizationalUnitId)
		if err := d.Set("parameter_overrides", flattenAllParameters(stackInstance.ParameterOverrides)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting parameters: %s", err)
		}
		d.Set("stack_id", stackInstance.StackId)
		d.Set("stack_instance_summaries", nil)
	} else {
		orgIDs := strings.Split(accountOrOrgID, "/")
		summaries, err := findStackInstanceSummariesByFourPartKey(ctx, conn, stackSetName, region, callAs, orgIDs)
		if !d.IsNewResource() && tfresource.NotFound(err) {
			log.Printf("[WARN] CloudFormation StackSet Instance (%s) not found, removing from state", d.Id())
			d.SetId("")
			return diags
		}
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "finding CloudFormation StackSet Instance (%s): %s", d.Id(), err)
		}
		d.Set("stack_instance_summaries", flattenStackInstanceSummaries(summaries))
	}
	return diags
}

func findStackInstanceByFourPartKey(ctx context.Context, conn *cloudformation.Client, stackSetName, accountID, region, callAs string) (*awstypes.StackInstance, error) {
	input := &cloudformation.DescribeStackInstanceInput{StackInstanceAccount: aws.String(accountID), StackInstanceRegion: aws.String(region), StackSetName: aws.String(stackSetName)}
	if callAs != "" {
		input.CallAs = awstypes.CallAs(callAs)
	}
	output, err := conn.DescribeStackInstance(ctx, input)
	if errs.IsA[*awstypes.StackInstanceNotFoundException](err) || errs.IsA[*awstypes.StackSetNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.StackInstance == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output.StackInstance, nil
}

func flattenAllParameters(cfParams []awstypes.Parameter) map[string]any {
	params := make(map[string]any, len(cfParams))
	for _, p := range cfParams {
		params[aws.ToString(p.ParameterKey)] = aws.ToString(p.ParameterValue)
	}
	return params
}

func findStackInstanceSummariesByFourPartKey(ctx context.Context, conn *cloudformation.Client, stackSetName, region, callAs string, orgIDs []string) ([]awstypes.StackInstanceSummary, error) {
	input := &cloudformation.ListStackInstancesInput{StackInstanceRegion: aws.String(region), StackSetName: aws.String(stackSetName)}
	if callAs != "" {
		input.CallAs = awstypes.CallAs(callAs)
	}
	var output []awstypes.StackInstanceSummary
	pages := cloudformation.NewListStackInstancesPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if errs.IsA[*awstypes.StackSetNotFoundException](err) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
		}
		if err != nil {
			return nil, err
		}
		for _, v := range page.Summaries {
			if slices.Contains(orgIDs, aws.ToString(v.OrganizationalUnitId)) {
				output = append(output, v)
			}
		}
	}
	return output, nil
}

func flattenStackInstanceSummaries(apiObject []awstypes.StackInstanceSummary) []any {
	if len(apiObject) == 0 {
		return nil
	}
	tfList := []any{}
	for _, obj := range apiObject {
		m := map[string]any{names.AttrAccountID: obj.Account, "organizational_unit_id": obj.OrganizationalUnitId, "stack_id": obj.StackId}
		tfList = append(tfList, m)
	}
	return tfList
}

