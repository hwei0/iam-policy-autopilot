package cloudformation

import (
	"context"
	"fmt"
	"log"
	"slices"
	"strings"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/cloudformation"
	awstypes "github.com/aws/aws-sdk-go-v2/service/cloudformation/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	sdkid "github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/create"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	inttypes "github.com/hashicorp/terraform-provider-aws/internal/types"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandDeploymentTargets(tfList []any) *awstypes.DeploymentTargets {
	if len(tfList) == 0 || tfList[0] == nil {
		return nil
	}
	tfMap, ok := tfList[0].(map[string]any)
	if !ok {
		return nil
	}
	dt := &awstypes.DeploymentTargets{}
	if v, ok := tfMap["organizational_unit_ids"].(*schema.Set); ok && v.Len() > 0 {
		dt.OrganizationalUnitIds = flex.ExpandStringValueSet(v)
	}
	if v, ok := tfMap["account_filter_type"].(string); ok && len(v) > 0 {
		dt.AccountFilterType = awstypes.AccountFilterType(v)
	}
	if v, ok := tfMap["accounts"].(*schema.Set); ok && v.Len() > 0 {
		dt.Accounts = flex.ExpandStringValueSet(v)
	}
	if v, ok := tfMap["accounts_url"].(string); ok && len(v) > 0 {
		dt.AccountsUrl = aws.String(v)
	}
	return dt
}

func expandParameters(params map[string]any) []awstypes.Parameter {
	var cfParams []awstypes.Parameter
	for k, v := range params {
		cfParams = append(cfParams, awstypes.Parameter{ParameterKey: aws.String(k), ParameterValue: aws.String(v.(string))})
	}
	return cfParams
}

func expandOperationPreferences(tfMap map[string]any) *awstypes.StackSetOperationPreferences {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.StackSetOperationPreferences{}
	if v, ok := tfMap["failure_tolerance_count"].(int); ok {
		apiObject.FailureToleranceCount = aws.Int32(int32(v))
	}
	if v, ok := tfMap["failure_tolerance_percentage"].(int); ok {
		apiObject.FailureTolerancePercentage = aws.Int32(int32(v))
	}
	if v, ok := tfMap["max_concurrent_count"].(int); ok {
		apiObject.MaxConcurrentCount = aws.Int32(int32(v))
	}
	if v, ok := tfMap["max_concurrent_percentage"].(int); ok {
		apiObject.MaxConcurrentPercentage = aws.Int32(int32(v))
	}
	if v, ok := tfMap["concurrency_mode"].(string); ok && v != "" {
		apiObject.ConcurrencyMode = awstypes.ConcurrencyMode(v)
	}
	if v, ok := tfMap["region_concurrency_type"].(string); ok && v != "" {
		apiObject.RegionConcurrencyType = awstypes.RegionConcurrencyType(v)
	}
	if v, ok := tfMap["region_order"].(*schema.Set); ok && v.Len() > 0 {
		apiObject.RegionOrder = flex.ExpandStringValueSet(v)
	}
	if ftc, ftp := aws.ToInt32(apiObject.FailureToleranceCount), aws.ToInt32(apiObject.FailureTolerancePercentage); ftp == 0 {
		apiObject.FailureTolerancePercentage = nil
	} else if ftc == 0 {
		apiObject.FailureToleranceCount = nil
	}
	if mcc, mcp := aws.ToInt32(apiObject.MaxConcurrentCount), aws.ToInt32(apiObject.MaxConcurrentPercentage); mcp == 0 {
		apiObject.MaxConcurrentPercentage = nil
	} else if mcc == 0 {
		apiObject.MaxConcurrentCount = nil
	}
	return apiObject
}

