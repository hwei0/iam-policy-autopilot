package cognitoidentity

import (
	"context"
	"fmt"
	"log"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentity"
	awstypes "github.com/aws/aws-sdk-go-v2/service/cognitoidentity/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/create"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourcePoolRolesAttachmentCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).CognitoIdentityClient(ctx)
	if errors := validRoles(d.Get("roles").(map[string]any)); len(errors) > 0 {
		return sdkdiag.AppendErrorf(diags, "validating Roles: %v", errors)
	}
	params := &cognitoidentity.SetIdentityPoolRolesInput{IdentityPoolId: aws.String(d.Get("identity_pool_id").(string)), Roles: expandIdentityPoolRoles(d.Get("roles").(map[string]any))}
	if v, ok := d.GetOk("role_mapping"); ok {
		errors := validateRoleMappings(v.(*schema.Set).List())
		if len(errors) > 0 {
			return sdkdiag.AppendErrorf(diags, "validating ambiguous role resolution: %v", errors)
		}
		params.RoleMappings = expandIdentityPoolRoleMappingsAttachment(v.(*schema.Set).List())
	}
	log.Printf("[DEBUG] Creating Cognito Identity Pool Roles Association: %#v", params)
	_, err := conn.SetIdentityPoolRoles(ctx, params)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Cognito Identity Pool Roles Association: %s", err)
	}
	d.SetId(d.Get("identity_pool_id").(string))
	return append(diags, resourcePoolRolesAttachmentRead(ctx, d, meta)...)
}

func validRoles(v map // Validates that either authenticated or unauthenticated is defined
[string]any) (errors []error) {
	k := "roles"
	_, hasAuthenticated := v["authenticated"].(string)
	_, hasUnauthenticated := v["unauthenticated"].(string)
	if !hasAuthenticated && !hasUnauthenticated {
		errors = append(errors, fmt.Errorf("%q: Either \"authenticated\" or \"unauthenticated\" must be defined", k))
	}
	return
}

func expandIdentityPoolRoles(config map[string]any) map[string]string {
	m := map[string]string{}
	for k, v := range config {
		s := v.(string)
		m[k] = s
	}
	return m
}

func validateRoleMappings(roleMappings [ // Validating that each role_mapping ambiguous_role_resolution
// is defined when "type" equals Token or Rules.
]any) []error {
	errors := make([]error, 0)
	for _, r := range roleMappings {
		rm := r.(map[string]any)
		if err := validRoleMappingsAmbiguousRoleResolutionAgainstType(rm); len(err) > 0 {
			errors = append(errors, fmt.Errorf("Role Mapping %q: %v", rm["identity_provider"].(string), err))
		}
		if err := validRoleMappingsRulesConfiguration(rm); len(err) > 0 {
			errors = append(errors, fmt.Errorf("Role Mapping %q: %v", rm["identity_provider"].(string), err))
		}
	}
	return errors
}

func validRoleMappingsAmbiguousRoleResolutionAgainstType(v map[string]any) (errors []error) {
	t := v[names.AttrType].(string)
	isRequired := t == string(awstypes.RoleMappingTypeToken) || t == string(awstypes.RoleMappingTypeRules)
	if value, ok := v["ambiguous_role_resolution"]; (!ok || value == "") && isRequired {
		errors = append(errors, fmt.Errorf(`Ambiguous Role Resolution must be defined when "type" equals "Token" or "Rules"`))
	}
	return
}

func validRoleMappingsRulesConfiguration(v map[string]any) (errors []error) {
	t := v[names.AttrType].(string)
	valLength := 0
	if value, ok := v["mapping_rule"]; ok {
		valLength = len(value.([]any))
	}
	if (valLength == 0) && t == string(awstypes.RoleMappingTypeRules) {
		errors = append(errors, fmt.Errorf("mapping_rule is required for Rules"))
	}
	if (valLength > 0) && t == string(awstypes.RoleMappingTypeToken) {
		errors = append(errors, fmt.Errorf("mapping_rule must not be set for Token based role mapping"))
	}
	return
}

func expandIdentityPoolRoleMappingsAttachment(rms []any) map[string]awstypes.RoleMapping {
	values := make(map[string]awstypes.RoleMapping)
	if len(rms) == 0 {
		return values
	}
	for _, v := range rms {
		rm := v.(map[string]any)
		key := rm["identity_provider"].(string)
		roleMapping := awstypes.RoleMapping{Type: awstypes.RoleMappingType(rm[names.AttrType].(string))}
		if sv, ok := rm["ambiguous_role_resolution"].(string); ok {
			roleMapping.AmbiguousRoleResolution = awstypes.AmbiguousRoleResolutionType(sv)
		}
		if mr, ok := rm["mapping_rule"].([]any); ok && len(mr) > 0 {
			rct := &awstypes.RulesConfigurationType{}
			mappingRules := make([]awstypes.MappingRule, 0)
			for _, r := range mr {
				rule := r.(map[string]any)
				mr := awstypes.MappingRule{Claim: aws.String(rule["claim"].(string)), MatchType: awstypes.MappingRuleMatchType(rule["match_type"].(string)), RoleARN: aws.String(rule[names.AttrRoleARN].(string)), Value: aws.String(rule[names.AttrValue].(string))}
				mappingRules = append(mappingRules, mr)
			}
			rct.Rules = mappingRules
			roleMapping.RulesConfiguration = rct
		}
		values[key] = roleMapping
	}
	return values
}

func resourcePoolRolesAttachmentRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).CognitoIdentityClient(ctx)
	log.Printf("[DEBUG] Reading Cognito Identity Pool Roles Association: %s", d.Id())
	input := cognitoidentity.GetIdentityPoolRolesInput{IdentityPoolId: aws.String(d.Id())}
	ip, err := conn.GetIdentityPoolRoles(ctx, &input)
	if !d.IsNewResource() && errs.IsA[*awstypes.ResourceNotFoundException](err) {
		create.LogNotFoundRemoveState(names.CognitoIdentity, create.ErrActionReading, ResNamePoolRolesAttachment, d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return create.AppendDiagError(diags, names.CognitoIdentity, create.ErrActionReading, ResNamePoolRolesAttachment, d.Id(), err)
	}
	d.Set("identity_pool_id", ip.IdentityPoolId)
	if err := d.Set("roles", ip.Roles); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting roles error: %#v", err)
	}
	if err := d.Set("role_mapping", flattenIdentityPoolRoleMappingsAttachment(ip.RoleMappings)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting role mappings error: %#v", err)
	}
	return diags
}

func flattenIdentityPoolRoleMappingsAttachment(rms map[string]awstypes.RoleMapping) []map[string]any {
	roleMappings := make([]map[string]any, 0)
	if rms == nil {
		return roleMappings
	}
	for k, v := range rms {
		m := make(map[string]any)
		if v.Type != "" {
			m[names.AttrType] = string(v.Type)
		}
		if v.AmbiguousRoleResolution != "" {
			m["ambiguous_role_resolution"] = string(v.AmbiguousRoleResolution)
		}
		if v.RulesConfiguration != nil && v.RulesConfiguration.Rules != nil {
			m["mapping_rule"] = flattenIdentityPoolRolesAttachmentMappingRules(v.RulesConfiguration.Rules)
		}
		m["identity_provider"] = k
		roleMappings = append(roleMappings, m)
	}
	return roleMappings
}

func flattenIdentityPoolRolesAttachmentMappingRules(d []awstypes.MappingRule) []any {
	rules := make([]any, 0)
	for _, rule := range d {
		r := make(map[string]any)
		r["claim"] = aws.ToString(rule.Claim)
		r["match_type"] = string(rule.MatchType)
		r[names.AttrRoleARN] = aws.ToString(rule.RoleARN)
		r[names.AttrValue] = aws.ToString(rule.Value)
		rules = append(rules, r)
	}
	return rules
}

