package cognitoidentity

import (
	"context"
	"fmt"
	"log"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentity"
	awstypes "github.com/aws/aws-sdk-go-v2/service/cognitoidentity/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/create"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourcePoolRolesAttachmentRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).CognitoIdentityClient(ctx)
	log.Printf("[DEBUG] Reading Cognito Identity Pool Roles Association: %s", d.Id())
	input := cognitoidentity.GetIdentityPoolRolesInput{IdentityPoolId: aws.String(d.Id())}
	ip, err := conn.GetIdentityPoolRoles(ctx, &input)
	if !d.IsNewResource() && errs.IsA[*awstypes.ResourceNotFoundException](err) {
		create.LogNotFoundRemoveState(names.CognitoIdentity, create.ErrActionReading, ResNamePoolRolesAttachment, d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return create.AppendDiagError(diags, names.CognitoIdentity, create.ErrActionReading, ResNamePoolRolesAttachment, d.Id(), err)
	}
	d.Set("identity_pool_id", ip.IdentityPoolId)
	if err := d.Set("roles", ip.Roles); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting roles error: %#v", err)
	}
	if err := d.Set("role_mapping", flattenIdentityPoolRoleMappingsAttachment(ip.RoleMappings)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting role mappings error: %#v", err)
	}
	return diags
}

func flattenIdentityPoolRoleMappingsAttachment(rms map[string]awstypes.RoleMapping) []map[string]any {
	roleMappings := make([]map[string]any, 0)
	if rms == nil {
		return roleMappings
	}
	for k, v := range rms {
		m := make(map[string]any)
		if v.Type != "" {
			m[names.AttrType] = string(v.Type)
		}
		if v.AmbiguousRoleResolution != "" {
			m["ambiguous_role_resolution"] = string(v.AmbiguousRoleResolution)
		}
		if v.RulesConfiguration != nil && v.RulesConfiguration.Rules != nil {
			m["mapping_rule"] = flattenIdentityPoolRolesAttachmentMappingRules(v.RulesConfiguration.Rules)
		}
		m["identity_provider"] = k
		roleMappings = append(roleMappings, m)
	}
	return roleMappings
}

func flattenIdentityPoolRolesAttachmentMappingRules(d []awstypes.MappingRule) []any {
	rules := make([]any, 0)
	for _, rule := range d {
		r := make(map[string]any)
		r["claim"] = aws.ToString(rule.Claim)
		r["match_type"] = string(rule.MatchType)
		r[names.AttrRoleARN] = aws.ToString(rule.RoleARN)
		r[names.AttrValue] = aws.ToString(rule.Value)
		rules = append(rules, r)
	}
	return rules
}

