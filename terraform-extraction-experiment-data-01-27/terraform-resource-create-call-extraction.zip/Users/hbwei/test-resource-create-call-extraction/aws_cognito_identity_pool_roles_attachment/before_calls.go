package cognitoidentity

import (
	"context"
	"fmt"
	"log"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentity"
	awstypes "github.com/aws/aws-sdk-go-v2/service/cognitoidentity/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/create"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func validRoles(v map // Validates that either authenticated or unauthenticated is defined
[string]any) (errors []error) {
	k := "roles"
	_, hasAuthenticated := v["authenticated"].(string)
	_, hasUnauthenticated := v["unauthenticated"].(string)
	if !hasAuthenticated && !hasUnauthenticated {
		errors = append(errors, fmt.Errorf("%q: Either \"authenticated\" or \"unauthenticated\" must be defined", k))
	}
	return
}

func expandIdentityPoolRoles(config map[string]any) map[string]string {
	m := map[string]string{}
	for k, v := range config {
		s := v.(string)
		m[k] = s
	}
	return m
}

func validateRoleMappings(roleMappings [ // Validating that each role_mapping ambiguous_role_resolution
// is defined when "type" equals Token or Rules.
]any) []error {
	errors := make([]error, 0)
	for _, r := range roleMappings {
		rm := r.(map[string]any)
		if err := validRoleMappingsAmbiguousRoleResolutionAgainstType(rm); len(err) > 0 {
			errors = append(errors, fmt.Errorf("Role Mapping %q: %v", rm["identity_provider"].(string), err))
		}
		if err := validRoleMappingsRulesConfiguration(rm); len(err) > 0 {
			errors = append(errors, fmt.Errorf("Role Mapping %q: %v", rm["identity_provider"].(string), err))
		}
	}
	return errors
}

func validRoleMappingsAmbiguousRoleResolutionAgainstType(v map[string]any) (errors []error) {
	t := v[names.AttrType].(string)
	isRequired := t == string(awstypes.RoleMappingTypeToken) || t == string(awstypes.RoleMappingTypeRules)
	if value, ok := v["ambiguous_role_resolution"]; (!ok || value == "") && isRequired {
		errors = append(errors, fmt.Errorf(`Ambiguous Role Resolution must be defined when "type" equals "Token" or "Rules"`))
	}
	return
}

func validRoleMappingsRulesConfiguration(v map[string]any) (errors []error) {
	t := v[names.AttrType].(string)
	valLength := 0
	if value, ok := v["mapping_rule"]; ok {
		valLength = len(value.([]any))
	}
	if (valLength == 0) && t == string(awstypes.RoleMappingTypeRules) {
		errors = append(errors, fmt.Errorf("mapping_rule is required for Rules"))
	}
	if (valLength > 0) && t == string(awstypes.RoleMappingTypeToken) {
		errors = append(errors, fmt.Errorf("mapping_rule must not be set for Token based role mapping"))
	}
	return
}

func expandIdentityPoolRoleMappingsAttachment(rms []any) map[string]awstypes.RoleMapping {
	values := make(map[string]awstypes.RoleMapping)
	if len(rms) == 0 {
		return values
	}
	for _, v := range rms {
		rm := v.(map[string]any)
		key := rm["identity_provider"].(string)
		roleMapping := awstypes.RoleMapping{Type: awstypes.RoleMappingType(rm[names.AttrType].(string))}
		if sv, ok := rm["ambiguous_role_resolution"].(string); ok {
			roleMapping.AmbiguousRoleResolution = awstypes.AmbiguousRoleResolutionType(sv)
		}
		if mr, ok := rm["mapping_rule"].([]any); ok && len(mr) > 0 {
			rct := &awstypes.RulesConfigurationType{}
			mappingRules := make([]awstypes.MappingRule, 0)
			for _, r := range mr {
				rule := r.(map[string]any)
				mr := awstypes.MappingRule{Claim: aws.String(rule["claim"].(string)), MatchType: awstypes.MappingRuleMatchType(rule["match_type"].(string)), RoleARN: aws.String(rule[names.AttrRoleARN].(string)), Value: aws.String(rule[names.AttrValue].(string))}
				mappingRules = append(mappingRules, mr)
			}
			rct.Rules = mappingRules
			roleMapping.RulesConfiguration = rct
		}
		values[key] = roleMapping
	}
	return values
}

