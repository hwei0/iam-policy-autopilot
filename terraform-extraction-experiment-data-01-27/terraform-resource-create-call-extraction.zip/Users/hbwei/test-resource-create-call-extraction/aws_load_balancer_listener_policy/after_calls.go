package elb

import (
	"context"
	"fmt"
	"log"
	"strconv"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/elasticloadbalancing"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceListenerPolicyRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ELBClient(ctx)
	lbName, lbPort, err := listenerPolicyParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	policyNames, err := findLoadBalancerListenerPolicyByTwoPartKey(ctx, conn, lbName, lbPort)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] ELB Classic Listener Policy (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading ELB Classic Listener Policy (%s): %s", d.Id(), err)
	}
	d.Set("load_balancer_name", lbName)
	d.Set("load_balancer_port", lbPort)
	d.Set("policy_names", policyNames)
	return diags
}

func listenerPolicyParseResourceID(id string) (string, int, error) {
	parts := strings.Split(id, listenerPolicyResourceIDSeparator)
	if len(parts) == 2 && parts[0] != "" && parts[1] != "" {
		v, err := strconv.Atoi(parts[1])
		if err != nil {
			return "", 0, err
		}
		return parts[0], v, nil
	}
	return "", 0, fmt.Errorf("unexpected format for ID (%[1]s), expected LBNAME%[2]sLBPORT", id, listenerPolicyResourceIDSeparator)
}

func findLoadBalancerListenerPolicyByTwoPartKey(ctx context.Context, conn *elasticloadbalancing.Client, lbName string, lbPort int) ([]string, error) {
	lb, err := findLoadBalancerByName(ctx, conn, lbName)
	if err != nil {
		return nil, err
	}
	var policyNames []string
	for _, v := range lb.ListenerDescriptions {
		if v.Listener.LoadBalancerPort != int32(lbPort) {
			continue
		}
		policyNames = append(policyNames, v.PolicyNames...)
	}
	return policyNames, nil
}

func findLoadBalancerByName(ctx context.Context, conn *elasticloadbalancing.Client, name string) (*awstypes.LoadBalancerDescription, error) {
	input := &elasticloadbalancing.DescribeLoadBalancersInput{LoadBalancerNames: []string{name}}
	output, err := conn.DescribeLoadBalancers(ctx, input)
	if errs.IsA[*awstypes.AccessPointNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output.LoadBalancerDescriptions)
}

