package storagegateway

import (
	"context"
	"fmt"
	"log"
	"net"
	"net/http"
	"slices"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/storagegateway"
	awstypes "github.com/aws/aws-sdk-go-v2/service/storagegateway/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/customdiff"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/sdkv2/types/nullable"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceGatewayCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).StorageGatewayClient(ctx)
	region := meta.(*conns.AWSClient).Region(ctx)
	activationKey := d.Get("activation_key").(string)
	if v, ok := d.GetOk("gateway_ip_address"); ok {
		gatewayIPAddress := v.(string)
		client := &http.Client{CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		}, Timeout: time.Second * 10}
		requestURL := fmt.Sprintf("http://%[1]s/?activationRegion=%[2]s", gatewayIPAddress, region)
		if v, ok := d.GetOk("gateway_vpc_endpoint"); ok {
			requestURL = fmt.Sprintf("%[1]s&vpcEndpoint=%[2]s", requestURL, v.(string))
		}
		request, err := http.NewRequest(http.MethodGet, requestURL, nil)
		if err != nil {
			return sdkdiag.AppendFromErr(diags, err)
		}
		var response *http.Response
		err = tfresource.Retry(ctx, d.Timeout(schema.TimeoutCreate), func(ctx context.Context) *tfresource.RetryError {
			response, err = client.Do(request)
			if err != nil {
				errReturn := fmt.Errorf("making HTTP request: %w", err)
				if errs.IsA[net.Error](err) {
					return tfresource.RetryableError(errReturn)
				}
				return tfresource.NonRetryableError(errReturn)
			}
			if slices.Contains([]int{http.StatusGatewayTimeout}, response.StatusCode) {
				errReturn := fmt.Errorf("status code in HTTP response: %d", response.StatusCode)
				return tfresource.RetryableError(errReturn)
			}
			return nil
		})
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "retrieving activation key from IP Address (%s): %s", gatewayIPAddress, err)
		}
		if response.StatusCode != http.StatusFound {
			return sdkdiag.AppendErrorf(diags, "expected HTTP status code 302, received: %d", response.StatusCode)
		}
		redirectURL, err := response.Location()
		if err != nil {
			return sdkdiag.AppendFromErr(diags, err)
		}
		activationKey = redirectURL.Query().Get("activationKey")
		if activationKey == "" {
			return sdkdiag.AppendErrorf(diags, "empty activationKey received from IP Address: %s", gatewayIPAddress)
		}
	}
	name := d.Get("gateway_name").(string)
	input := storagegateway.ActivateGatewayInput{ActivationKey: aws.String(activationKey), GatewayRegion: aws.String(region), GatewayName: aws.String(name), GatewayTimezone: aws.String(d.Get("gateway_timezone").(string)), GatewayType: aws.String(d.Get("gateway_type").(string)), Tags: getTagsIn(ctx)}
	if v, ok := d.GetOk("medium_changer_type"); ok {
		input.MediumChangerType = aws.String(v.(string))
	}
	if v, ok := d.GetOk("tape_drive_type"); ok {
		input.TapeDriveType = aws.String(v.(string))
	}
	output, err := conn.ActivateGateway(ctx, &input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "activating Storage Gateway Gateway (%s): %s", name, err)
	}
	d.SetId(aws.ToString(output.GatewayARN))
	if _, err := waitGatewayConnected(ctx, conn, d.Id(), d.Timeout(schema.TimeoutCreate)); err != nil {
		return sdkdiag.AppendErrorf(diags, "waiting for Storage Gateway Gateway (%s) connect: %s", d.Id(), err)
	}
	if v, ok := d.GetOk(names.AttrCloudWatchLogGroupARN); ok && v.(string) != "" {
		input := storagegateway.UpdateGatewayInformationInput{CloudWatchLogGroupARN: aws.String(v.(string)), GatewayARN: aws.String(d.Id())}
		_, err := conn.UpdateGatewayInformation(ctx, &input)
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "updating Storage Gateway Gateway (%s) CloudWatch log group: %s", d.Id(), err)
		}
	}
	if v, ok := d.GetOk("maintenance_start_time"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input := expandUpdateMaintenanceStartTimeInput(v.([]any)[0].(map[string]any))
		input.GatewayARN = aws.String(d.Id())
		_, err := conn.UpdateMaintenanceStartTime(ctx, input)
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "updating Storage Gateway Gateway (%s) maintenance start time: %s", d.Id(), err)
		}
	}
	if v, ok := d.GetOk("smb_active_directory_settings"); ok && len(v.([]any)) > 0 {
		input := expandJoinDomainInput(v.([]any), d.Id())
		_, err := conn.JoinDomain(ctx, input)
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "joining Storage Gateway Gateway (%s) to Active Directory domain (%s): %s", d.Id(), aws.ToString(input.DomainName), err)
		}
		if _, err = waitGatewayJoinDomainJoined(ctx, conn, d.Id()); err != nil {
			return sdkdiag.AppendErrorf(diags, "waiting for Storage Gateway Gateway (%s) domain join: %s", d.Id(), err)
		}
	}
	if v, ok := d.GetOk("smb_guest_password"); ok && v.(string) != "" {
		input := storagegateway.SetSMBGuestPasswordInput{GatewayARN: aws.String(d.Id()), Password: aws.String(v.(string))}
		_, err := conn.SetSMBGuestPassword(ctx, &input)
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "setting Storage Gateway Gateway (%s) SMB guest password: %s", d.Id(), err)
		}
	}
	if v, ok := d.GetOk("smb_security_strategy"); ok {
		input := storagegateway.UpdateSMBSecurityStrategyInput{GatewayARN: aws.String(d.Id()), SMBSecurityStrategy: awstypes.SMBSecurityStrategy(v.(string))}
		_, err := conn.UpdateSMBSecurityStrategy(ctx, &input)
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "setting Storage Gateway Gateway (%s) SMB security strategy: %s", d.Id(), err)
		}
	}
	if v, ok := d.GetOk("smb_file_share_visibility"); ok {
		input := storagegateway.UpdateSMBFileShareVisibilityInput{FileSharesVisible: aws.Bool(v.(bool)), GatewayARN: aws.String(d.Id())}
		_, err := conn.UpdateSMBFileShareVisibility(ctx, &input)
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "updating Storage Gateway Gateway (%s) SMB file share visibility: %s", d.Id(), err)
		}
	}
	switch d.Get("gateway_type").(string) {
	case gatewayTypeCached, gatewayTypeStored, gatewayTypeVTL, gatewayTypeVTLSnow:
		input := storagegateway.UpdateBandwidthRateLimitInput{GatewayARN: aws.String(d.Id())}
		if v, ok := d.GetOk("average_download_rate_limit_in_bits_per_sec"); ok {
			input.AverageDownloadRateLimitInBitsPerSec = aws.Int64(int64(v.(int)))
		}
		if v, ok := d.GetOk("average_upload_rate_limit_in_bits_per_sec"); ok {
			input.AverageUploadRateLimitInBitsPerSec = aws.Int64(int64(v.(int)))
		}
		if input.AverageDownloadRateLimitInBitsPerSec != nil || input.AverageUploadRateLimitInBitsPerSec != nil {
			_, err := conn.UpdateBandwidthRateLimit(ctx, &input)
			if err != nil {
				return sdkdiag.AppendErrorf(diags, "updating Storage Gateway Gateway (%s) bandwidth rate limits: %s", d.Id(), err)
			}
		}
	}
	return append(diags, resourceGatewayRead(ctx, d, meta)...)
}

func waitGatewayConnected(ctx context.Context, conn *storagegateway.Client, gatewayARN string, timeout time.Duration) (*storagegateway.DescribeGatewayInformationOutput, error) {
	stateConf := &retry.StateChangeConf{Pending: []string{gatewayStatusNotConnected}, Target: []string{gatewayStatusConnected}, Refresh: statusGatewayConnected(ctx, conn, gatewayARN), Timeout: timeout, MinTimeout: 10 * time.Second, ContinuousTargetOccurence: 6}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*storagegateway.DescribeGatewayInformationOutput); ok {
		return output, err
	}
	return nil, err
}

func statusGatewayConnected(ctx context.Context, conn *storagegateway.Client, gatewayARN string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findGatewayByARN(ctx, conn, gatewayARN)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if isGatewayNotConnectedErr(err) {
			return output, gatewayStatusNotConnected, nil
		}
		if err != nil {
			return output, "", err
		}
		return output, gatewayStatusConnected, nil
	}
}

func findGatewayByARN(ctx context.Context, conn *storagegateway.Client, arn string) (*storagegateway.DescribeGatewayInformationOutput, error) {
	input := storagegateway.DescribeGatewayInformationInput{GatewayARN: aws.String(arn)}
	return findGateway(ctx, conn, &input)
}

func findGateway(ctx context.Context, conn *storagegateway.Client, input *storagegateway.DescribeGatewayInformationInput) (*storagegateway.DescribeGatewayInformationOutput, error) {
	output, err := conn.DescribeGatewayInformation(ctx, input)
	if isGatewayNotFoundErr(err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func isGatewayNotFoundErr(err error) bool {
	if operationErrorCode(err) == awstypes.ErrorCodeGatewayNotFound {
		return true
	}
	if tfawserr.ErrCodeEquals(err, string(awstypes.ErrorCodeGatewayNotFound)) {
		return true
	}
	if errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "The specified gateway was not found") {
		return true
	}
	return false
}// The API returns multiple responses for a missing gateway.


func operationErrorCode(err error) awstypes.ErrorCode {
	if v, ok := errs.As[*awstypes.InternalServerError](err); ok && v.Error_ != nil {
		return v.Error_.ErrorCode
	}
	if v, ok := errs.As[*awstypes.InvalidGatewayRequestException](err); ok && v.Error_ != nil {
		return v.Error_.ErrorCode
	}
	return ""
}// operationErrorCode returns the operation error code from the specified error:
//   - err represents an InternalServerError or InvalidGatewayRequestException
//   - Error_ is not nil
//
// See https://docs.aws.amazon.com/storagegateway/latest/userguide/AWSStorageGatewayAPI.html#APIErrorResponses for details.


func isGatewayNotConnectedErr(err error) bool {
	if operationErrorCode(err) == awstypes.ErrorCodeGatewayNotConnected {
		return true
	}
	if tfawserr.ErrCodeEquals(err, string(awstypes.ErrorCodeGatewayNotConnected)) {
		return true
	}
	if errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "The specified gateway is not connected") {
		return true
	}
	return false
}// The API returns multiple responses for a disconnected gateway.


func expandUpdateMaintenanceStartTimeInput(tfMap map[string]any) *storagegateway.UpdateMaintenanceStartTimeInput {
	if tfMap == nil {
		return nil
	}
	apiObject := &storagegateway.UpdateMaintenanceStartTimeInput{}
	if v, null, _ := nullable.Int(tfMap["day_of_month"].(string)).ValueInt32(); !null && v > 0 {
		apiObject.DayOfMonth = aws.Int32(v)
	}
	if v, null, _ := nullable.Int(tfMap["day_of_week"].(string)).ValueInt32(); !null {
		apiObject.DayOfWeek = aws.Int32(v)
	}
	if v, ok := tfMap["hour_of_day"].(int); ok {
		apiObject.HourOfDay = aws.Int32(int32(v))
	}
	if v, ok := tfMap["minute_of_hour"].(int); ok {
		apiObject.MinuteOfHour = aws.Int32(int32(v))
	}
	return apiObject
}

func expandJoinDomainInput(tfList []any, gatewayARN string) *storagegateway.JoinDomainInput {
	if tfList == nil || tfList[0] == nil {
		return nil
	}
	tfMap, ok := tfList[0].(map[string]any)
	if !ok {
		return nil
	}
	apiObject := &storagegateway.JoinDomainInput{DomainName: aws.String(tfMap[names.AttrDomainName].(string)), GatewayARN: aws.String(gatewayARN), Password: aws.String(tfMap[names.AttrPassword].(string)), TimeoutInSeconds: aws.Int32(int32(tfMap["timeout_in_seconds"].(int))), UserName: aws.String(tfMap[names.AttrUsername].(string))}
	if v, ok := tfMap["domain_controllers"].(*schema.Set); ok && v.Len() > 0 {
		apiObject.DomainControllers = flex.ExpandStringValueSet(v)
	}
	if v, ok := tfMap["organizational_unit"].(string); ok && v != "" {
		apiObject.OrganizationalUnit = aws.String(v)
	}
	return apiObject
}

func waitGatewayJoinDomainJoined(ctx context.Context, conn *storagegateway.Client, gatewayARN string) (*storagegateway.DescribeSMBSettingsOutput, error) {
	const (
		timeout = 5 * time.Minute
	)
	stateConf := &retry.StateChangeConf{Pending: enum.Slice(awstypes.ActiveDirectoryStatusJoining), Target: enum.Slice(awstypes.ActiveDirectoryStatusJoined), Refresh: statusGatewayJoinDomain(ctx, conn, gatewayARN), Timeout: timeout}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*storagegateway.DescribeSMBSettingsOutput); ok {
		return output, err
	}
	return nil, err
}

func statusGatewayJoinDomain(ctx context.Context, conn *storagegateway.Client, gatewayARN string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findSMBSettingsByARN(ctx, conn, gatewayARN)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return output, "", err
		}
		return output, string(output.ActiveDirectoryStatus), nil
	}
}

func findSMBSettingsByARN(ctx context.Context, conn *storagegateway.Client, arn string) (*storagegateway.DescribeSMBSettingsOutput, error) {
	input := storagegateway.DescribeSMBSettingsInput{GatewayARN: aws.String(arn)}
	return findSMBSettings(ctx, conn, &input)
}

func findSMBSettings(ctx context.Context, conn *storagegateway.Client, input *storagegateway.DescribeSMBSettingsInput) (*storagegateway.DescribeSMBSettingsOutput, error) {
	output, err := conn.DescribeSMBSettings(ctx, input)
	if isGatewayNotFoundErr(err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func resourceGatewayRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).StorageGatewayClient(ctx)
	outputDGI, err := findGatewayByARN(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Storage Gateway Gateway (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if isGatewayNotConnectedErr(err) {
		if gatewayInfo, err := findGatewayInfoByARN(ctx, conn, d.Id()); err == nil {
			d.Set(names.AttrARN, gatewayInfo.GatewayARN)
			d.Set("ec2_instance_id", gatewayInfo.Ec2InstanceId)
			d.Set("gateway_name", gatewayInfo.GatewayName)
			d.Set("gateway_type", gatewayInfo.GatewayType)
			d.Set("host_environment", gatewayInfo.HostEnvironment)
			return diags
		}
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Storage Gateway Gateway (%s): %s", d.Id(), err)
	}
	outputDSS, err := findSMBSettingsByARN(ctx, conn, d.Id())
	switch {
	case errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "This operation is not valid for the specified gateway"):
	case err != nil:
		return sdkdiag.AppendErrorf(diags, "reading Storage Gateway Gateway (%s) SMB settings: %s", d.Id(), err)
	}
	d.Set("activation_key", d.Get("activation_key").(string))
	d.Set(names.AttrARN, outputDGI.GatewayARN)
	d.Set(names.AttrCloudWatchLogGroupARN, outputDGI.CloudWatchLogGroupARN)
	d.Set("ec2_instance_id", outputDGI.Ec2InstanceId)
	d.Set(names.AttrEndpointType, outputDGI.EndpointType)
	d.Set("gateway_id", outputDGI.GatewayId)
	d.Set("gateway_ip_address", d.Get("gateway_ip_address").(string))
	d.Set("gateway_name", outputDGI.GatewayName)
	if err := d.Set("gateway_network_interface", flattenNetworkInterfaces(outputDGI.GatewayNetworkInterfaces)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting gateway_network_interface: %s", err)
	}
	d.Set("gateway_timezone", outputDGI.GatewayTimezone)
	d.Set("gateway_type", outputDGI.GatewayType)
	d.Set("gateway_vpc_endpoint", outputDGI.VPCEndpoint)
	d.Set("host_environment", outputDGI.HostEnvironment)
	d.Set("medium_changer_type", d.Get("medium_changer_type").(string))
	if outputDSS == nil || aws.ToString(outputDSS.DomainName) == "" {
		if err := d.Set("smb_active_directory_settings", []any{}); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting smb_active_directory_settings: %s", err)
		}
	} else {
		tfMap := map[string]any{"active_directory_status": outputDSS.ActiveDirectoryStatus, names.AttrDomainName: aws.ToString(outputDSS.DomainName)}
		if v, ok := d.GetOk("smb_active_directory_settings"); ok && len(v.([]any)) > 0 {
			configM := v.([]any)[0].(map[string]any)
			tfMap[names.AttrPassword] = configM[names.AttrPassword]
			tfMap["timeout_in_seconds"] = configM["timeout_in_seconds"]
			tfMap[names.AttrUsername] = configM[names.AttrUsername]
			if v, ok := configM["domain_controllers"]; ok {
				tfMap["domain_controllers"] = v
			}
			if v, ok := configM["organizational_unit"]; ok {
				tfMap["organizational_unit"] = v
			}
		}
		if err := d.Set("smb_active_directory_settings", []map[string]any{tfMap}); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting smb_active_directory_settings: %s", err)
		}
	}
	if outputDSS == nil || !aws.ToBool(outputDSS.SMBGuestPasswordSet) {
		d.Set("smb_guest_password", "")
	}
	if outputDSS != nil {
		d.Set("smb_file_share_visibility", outputDSS.FileSharesVisible)
		d.Set("smb_security_strategy", outputDSS.SMBSecurityStrategy)
	}
	d.Set("tape_drive_type", d.Get("tape_drive_type").(string))
	setTagsOut(ctx, outputDGI.Tags)
	switch aws.ToString(outputDGI.GatewayType) {
	case gatewayTypeCached, gatewayTypeStored, gatewayTypeVTL, gatewayTypeVTLSnow:
		outputDBRL, err := findBandwidthRateLimitByARN(ctx, conn, d.Id())
		switch {
		case errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "not supported"):
		case errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "not valid"):
		case err != nil:
			return sdkdiag.AppendErrorf(diags, "reading Storage Gateway Gateway (%s) bandwidth rate limits: %s", d.Id(), err)
		default:
			d.Set("average_download_rate_limit_in_bits_per_sec", outputDBRL.AverageDownloadRateLimitInBitsPerSec)
			d.Set("average_upload_rate_limit_in_bits_per_sec", outputDBRL.AverageUploadRateLimitInBitsPerSec)
		}
	}
	outputDMST, err := findMaintenanceStartTimeByARN(ctx, conn, d.Id())
	switch {
	case errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "The specified operation is not supported"):
		fallthrough
	case errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "This operation is not valid for the specified gateway"):
		d.Set("maintenance_start_time", nil)
	case err != nil:
		return sdkdiag.AppendErrorf(diags, "reading Storage Gateway Gateway (%s) maintenance start time: %s", d.Id(), err)
	default:
		if err := d.Set("maintenance_start_time", []map[string]any{flattenDescribeMaintenanceStartTimeOutput(outputDMST)}); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting maintenance_start_time: %s", err)
		}
	}
	return diags
}

func findGatewayInfoByARN(ctx context.Context, conn *storagegateway.Client, arn string) (*awstypes.GatewayInfo, error) {
	var input storagegateway.ListGatewaysInput
	return findGatewayInfo(ctx, conn, &input, func(v *awstypes.GatewayInfo) bool {
		return aws.ToString(v.GatewayARN) == arn
	})
}

func findGatewayInfo(ctx context.Context, conn *storagegateway.Client, input *storagegateway.ListGatewaysInput, filter tfslices.Predicate[*awstypes.GatewayInfo]) (*awstypes.GatewayInfo, error) {
	output, err := findGateways(ctx, conn, input, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findGateways(ctx context.Context, conn *storagegateway.Client, input *storagegateway.ListGatewaysInput, filter tfslices.Predicate[*awstypes.GatewayInfo]) ([]awstypes.GatewayInfo, error) {
	var output []awstypes.GatewayInfo
	pages := storagegateway.NewListGatewaysPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Gateways {
			if filter(&v) {
				output = append(output, v)
			}
		}
	}
	return output, nil
}

func flattenNetworkInterfaces(apiObjects []awstypes.NetworkInterface) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfMap := map[string]any{"ipv4_address": aws.ToString(apiObject.Ipv4Address)}
		tfList = append(tfList, tfMap)
	}
	return tfList
}

func findBandwidthRateLimitByARN(ctx context.Context, conn *storagegateway.Client, arn string) (*storagegateway.DescribeBandwidthRateLimitOutput, error) {
	input := storagegateway.DescribeBandwidthRateLimitInput{GatewayARN: aws.String(arn)}
	return findBandwidthRateLimit(ctx, conn, &input)
}

func findBandwidthRateLimit(ctx context.Context, conn *storagegateway.Client, input *storagegateway.DescribeBandwidthRateLimitInput) (*storagegateway.DescribeBandwidthRateLimitOutput, error) {
	output, err := conn.DescribeBandwidthRateLimit(ctx, input)
	if isGatewayNotFoundErr(err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func findMaintenanceStartTimeByARN(ctx context.Context, conn *storagegateway.Client, arn string) (*storagegateway.DescribeMaintenanceStartTimeOutput, error) {
	input := storagegateway.DescribeMaintenanceStartTimeInput{GatewayARN: aws.String(arn)}
	return findMaintenanceStartTime(ctx, conn, &input)
}

func findMaintenanceStartTime(ctx context.Context, conn *storagegateway.Client, input *storagegateway.DescribeMaintenanceStartTimeInput) (*storagegateway.DescribeMaintenanceStartTimeOutput, error) {
	output, err := conn.DescribeMaintenanceStartTime(ctx, input)
	if isGatewayNotFoundErr(err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func flattenDescribeMaintenanceStartTimeOutput(apiObject *storagegateway.DescribeMaintenanceStartTimeOutput) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.DayOfMonth; v != nil {
		tfMap["day_of_month"] = flex.Int32ToStringValue(v)
	}
	if v := apiObject.DayOfWeek; v != nil {
		tfMap["day_of_week"] = flex.Int32ToStringValue(v)
	}
	if v := apiObject.HourOfDay; v != nil {
		tfMap["hour_of_day"] = aws.ToInt32(v)
	}
	if v := apiObject.MinuteOfHour; v != nil {
		tfMap["minute_of_hour"] = aws.ToInt32(v)
	}
	return tfMap
}

