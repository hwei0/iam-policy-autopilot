package storagegateway

import (
	"context"
	"fmt"
	"log"
	"net"
	"net/http"
	"slices"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/storagegateway"
	awstypes "github.com/aws/aws-sdk-go-v2/service/storagegateway/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/customdiff"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/sdkv2/types/nullable"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func waitGatewayConnected(ctx context.Context, conn *storagegateway.Client, gatewayARN string, timeout time.Duration) (*storagegateway.DescribeGatewayInformationOutput, error) {
	stateConf := &retry.StateChangeConf{Pending: []string{gatewayStatusNotConnected}, Target: []string{gatewayStatusConnected}, Refresh: statusGatewayConnected(ctx, conn, gatewayARN), Timeout: timeout, MinTimeout: 10 * time.Second, ContinuousTargetOccurence: 6}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*storagegateway.DescribeGatewayInformationOutput); ok {
		return output, err
	}
	return nil, err
}

func statusGatewayConnected(ctx context.Context, conn *storagegateway.Client, gatewayARN string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findGatewayByARN(ctx, conn, gatewayARN)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if isGatewayNotConnectedErr(err) {
			return output, gatewayStatusNotConnected, nil
		}
		if err != nil {
			return output, "", err
		}
		return output, gatewayStatusConnected, nil
	}
}

func findGatewayByARN(ctx context.Context, conn *storagegateway.Client, arn string) (*storagegateway.DescribeGatewayInformationOutput, error) {
	input := storagegateway.DescribeGatewayInformationInput{GatewayARN: aws.String(arn)}
	return findGateway(ctx, conn, &input)
}

func findGateway(ctx context.Context, conn *storagegateway.Client, input *storagegateway.DescribeGatewayInformationInput) (*storagegateway.DescribeGatewayInformationOutput, error) {
	output, err := conn.DescribeGatewayInformation(ctx, input)
	if isGatewayNotFoundErr(err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func isGatewayNotFoundErr(err error) bool {
	if operationErrorCode(err) == awstypes.ErrorCodeGatewayNotFound {
		return true
	}
	if tfawserr.ErrCodeEquals(err, string(awstypes.ErrorCodeGatewayNotFound)) {
		return true
	}
	if errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "The specified gateway was not found") {
		return true
	}
	return false
}// The API returns multiple responses for a missing gateway.


func operationErrorCode(err error) awstypes.ErrorCode {
	if v, ok := errs.As[*awstypes.InternalServerError](err); ok && v.Error_ != nil {
		return v.Error_.ErrorCode
	}
	if v, ok := errs.As[*awstypes.InvalidGatewayRequestException](err); ok && v.Error_ != nil {
		return v.Error_.ErrorCode
	}
	return ""
}// operationErrorCode returns the operation error code from the specified error:
//   - err represents an InternalServerError or InvalidGatewayRequestException
//   - Error_ is not nil
//
// See https://docs.aws.amazon.com/storagegateway/latest/userguide/AWSStorageGatewayAPI.html#APIErrorResponses for details.


func isGatewayNotConnectedErr(err error) bool {
	if operationErrorCode(err) == awstypes.ErrorCodeGatewayNotConnected {
		return true
	}
	if tfawserr.ErrCodeEquals(err, string(awstypes.ErrorCodeGatewayNotConnected)) {
		return true
	}
	if errs.IsAErrorMessageContains[*awstypes.InvalidGatewayRequestException](err, "The specified gateway is not connected") {
		return true
	}
	return false
}// The API returns multiple responses for a disconnected gateway.


func expandUpdateMaintenanceStartTimeInput(tfMap map[string]any) *storagegateway.UpdateMaintenanceStartTimeInput {
	if tfMap == nil {
		return nil
	}
	apiObject := &storagegateway.UpdateMaintenanceStartTimeInput{}
	if v, null, _ := nullable.Int(tfMap["day_of_month"].(string)).ValueInt32(); !null && v > 0 {
		apiObject.DayOfMonth = aws.Int32(v)
	}
	if v, null, _ := nullable.Int(tfMap["day_of_week"].(string)).ValueInt32(); !null {
		apiObject.DayOfWeek = aws.Int32(v)
	}
	if v, ok := tfMap["hour_of_day"].(int); ok {
		apiObject.HourOfDay = aws.Int32(int32(v))
	}
	if v, ok := tfMap["minute_of_hour"].(int); ok {
		apiObject.MinuteOfHour = aws.Int32(int32(v))
	}
	return apiObject
}

func expandJoinDomainInput(tfList []any, gatewayARN string) *storagegateway.JoinDomainInput {
	if tfList == nil || tfList[0] == nil {
		return nil
	}
	tfMap, ok := tfList[0].(map[string]any)
	if !ok {
		return nil
	}
	apiObject := &storagegateway.JoinDomainInput{DomainName: aws.String(tfMap[names.AttrDomainName].(string)), GatewayARN: aws.String(gatewayARN), Password: aws.String(tfMap[names.AttrPassword].(string)), TimeoutInSeconds: aws.Int32(int32(tfMap["timeout_in_seconds"].(int))), UserName: aws.String(tfMap[names.AttrUsername].(string))}
	if v, ok := tfMap["domain_controllers"].(*schema.Set); ok && v.Len() > 0 {
		apiObject.DomainControllers = flex.ExpandStringValueSet(v)
	}
	if v, ok := tfMap["organizational_unit"].(string); ok && v != "" {
		apiObject.OrganizationalUnit = aws.String(v)
	}
	return apiObject
}

func waitGatewayJoinDomainJoined(ctx context.Context, conn *storagegateway.Client, gatewayARN string) (*storagegateway.DescribeSMBSettingsOutput, error) {
	const (
		timeout = 5 * time.Minute
	)
	stateConf := &retry.StateChangeConf{Pending: enum.Slice(awstypes.ActiveDirectoryStatusJoining), Target: enum.Slice(awstypes.ActiveDirectoryStatusJoined), Refresh: statusGatewayJoinDomain(ctx, conn, gatewayARN), Timeout: timeout}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*storagegateway.DescribeSMBSettingsOutput); ok {
		return output, err
	}
	return nil, err
}

func statusGatewayJoinDomain(ctx context.Context, conn *storagegateway.Client, gatewayARN string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findSMBSettingsByARN(ctx, conn, gatewayARN)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return output, "", err
		}
		return output, string(output.ActiveDirectoryStatus), nil
	}
}

func findSMBSettingsByARN(ctx context.Context, conn *storagegateway.Client, arn string) (*storagegateway.DescribeSMBSettingsOutput, error) {
	input := storagegateway.DescribeSMBSettingsInput{GatewayARN: aws.String(arn)}
	return findSMBSettings(ctx, conn, &input)
}

func findSMBSettings(ctx context.Context, conn *storagegateway.Client, input *storagegateway.DescribeSMBSettingsInput) (*storagegateway.DescribeSMBSettingsOutput, error) {
	output, err := conn.DescribeSMBSettings(ctx, input)
	if isGatewayNotFoundErr(err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

