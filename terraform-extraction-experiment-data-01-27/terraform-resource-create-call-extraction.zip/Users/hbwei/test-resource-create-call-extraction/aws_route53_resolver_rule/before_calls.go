package route53resolver

import (
	"context"
	"errors"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/route53resolver"
	awstypes "github.com/aws/aws-sdk-go-v2/service/route53resolver/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandRuleTargetIPs(vTargetIps *schema.Set) []awstypes.TargetAddress {
	targetAddresses := []awstypes.TargetAddress{}
	for _, vTargetIp := range vTargetIps.List() {
		targetAddress := awstypes.TargetAddress{}
		mTargetIp := vTargetIp.(map[string]any)
		if vIp, ok := mTargetIp["ip"].(string); ok && vIp != "" {
			targetAddress.Ip = aws.String(vIp)
		}
		if vIpv6, ok := mTargetIp["ipv6"].(string); ok && vIpv6 != "" {
			targetAddress.Ipv6 = aws.String(vIpv6)
		}
		if vPort, ok := mTargetIp[names.AttrPort].(int); ok {
			targetAddress.Port = aws.Int32(int32(vPort))
		}
		if vProtocol, ok := mTargetIp[names.AttrProtocol].(string); ok && vProtocol != "" {
			targetAddress.Protocol = awstypes.Protocol(vProtocol)
		}
		targetAddresses = append(targetAddresses, targetAddress)
	}
	return targetAddresses
}

