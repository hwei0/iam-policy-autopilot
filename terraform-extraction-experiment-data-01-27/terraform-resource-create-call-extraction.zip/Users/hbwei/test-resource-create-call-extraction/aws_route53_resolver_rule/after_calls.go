package route53resolver

import (
	"context"
	"errors"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/route53resolver"
	awstypes "github.com/aws/aws-sdk-go-v2/service/route53resolver/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func waitRuleCreated(ctx context.Context, conn *route53resolver.Client, id string, timeout time.Duration) (*awstypes.ResolverRule, error) {
	stateConf := &retry.StateChangeConf{Target: enum.Slice(awstypes.ResolverRuleStatusComplete), Refresh: statusRule(ctx, conn, id), Timeout: timeout}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*awstypes.ResolverRule); ok {
		if output.Status == awstypes.ResolverRuleStatusFailed {
			tfresource.SetLastError(err, errors.New(aws.ToString(output.StatusMessage)))
		}
		return output, err
	}
	return nil, err
}

func statusRule(ctx context.Context, conn *route53resolver.Client, id string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findResolverRuleByID(ctx, conn, id)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return nil, "", err
		}
		return output, string(output.Status), nil
	}
}

func findResolverRuleByID(ctx context.Context, conn *route53resolver.Client, id string) (*awstypes.ResolverRule, error) {
	input := &route53resolver.GetResolverRuleInput{ResolverRuleId: aws.String(id)}
	output, err := conn.GetResolverRule(ctx, input)
	if errs.IsA[*awstypes.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.ResolverRule == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output.ResolverRule, nil
}

func resourceRuleRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).Route53ResolverClient(ctx)
	rule, err := findResolverRuleByID(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Route53 Resolver Rule (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Route53 Resolver Rule (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, rule.Arn)
	d.Set(names.AttrDomainName, trimTrailingPeriod(aws.ToString(rule.DomainName)))
	d.Set(names.AttrName, rule.Name)
	d.Set(names.AttrOwnerID, rule.OwnerId)
	d.Set("resolver_endpoint_id", rule.ResolverEndpointId)
	d.Set("rule_type", rule.RuleType)
	d.Set("share_status", rule.ShareStatus)
	if err := d.Set("target_ip", flattenRuleTargetIPs(rule.TargetIps)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting target_ip: %s", err)
	}
	return diags
}

func trimTrailingPeriod(v any) string {
	var str string
	switch value := v.( // trimTrailingPeriod is used to remove the trailing period
	// of "name" or "domain name" attributes often returned from
	// the Route53 API or provided as user input.
	// The single dot (".") domain name is returned as-is.
	type) {
	case *string:
		str = aws.ToString(value)
	case string:
		str = value
	default:
		return ""
	}
	if str == "." {
		return str
	}
	return strings.TrimSuffix(str, ".")
}

func flattenRuleTargetIPs(targetAddresses []awstypes.TargetAddress) []any {
	if targetAddresses == nil {
		return []any{}
	}
	vTargetIps := []any{}
	for _, targetAddress := range targetAddresses {
		mTargetIp := map[string]any{"ip": aws.ToString(targetAddress.Ip), "ipv6": aws.ToString(targetAddress.Ipv6), names.AttrPort: int(aws.ToInt32(targetAddress.Port)), names.AttrProtocol: targetAddress.Protocol}
		vTargetIps = append(vTargetIps, mTargetIp)
	}
	return vTargetIps
}

