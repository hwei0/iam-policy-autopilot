package datasync

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/datasync"
	awstypes "github.com/aws/aws-sdk-go-v2/service/datasync/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/provider/sdkv2/importer"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandProtocol(l []any) *awstypes.FsxProtocol {
	if len(l) == 0 || l[0] == nil {
		return nil
	}
	m := l[0].(map[string]any)
	protocol := &awstypes.FsxProtocol{}
	if v, ok := m["nfs"].([]any); ok {
		protocol.NFS = expandNFS(v)
	}
	if v, ok := m["smb"].([]any); ok {
		protocol.SMB = expandSMB(v)
	}
	return protocol
}

func expandNFS(l []any) *awstypes.FsxProtocolNfs {
	if len(l) == 0 || l[0] == nil {
		return nil
	}
	m := l[0].(map[string]any)
	protocol := &awstypes.FsxProtocolNfs{MountOptions: expandNFSMountOptions(m["mount_options"].([]any))}
	return protocol
}

func expandNFSMountOptions(l []any) *awstypes.NfsMountOptions {
	if len(l) == 0 || l[0] == nil {
		return nil
	}
	m := l[0].(map[string]any)
	nfsMountOptions := &awstypes.NfsMountOptions{Version: awstypes.NfsVersion(m[names.AttrVersion].(string))}
	return nfsMountOptions
}

func expandSMB(l []any) *awstypes.FsxProtocolSmb {
	if len(l) == 0 || l[0] == nil {
		return nil
	}
	m := l[0].(map[string]any)
	protocol := &awstypes.FsxProtocolSmb{MountOptions: expandSMBMountOptions(m["mount_options"].([]any))}
	if v, ok := m[names.AttrDomain].(string); ok && v != "" {
		protocol.Domain = aws.String(v)
	}
	if v, ok := m[names.AttrPassword].(string); ok && v != "" {
		protocol.Password = aws.String(v)
	}
	if v, ok := m["user"].(string); ok && v != "" {
		protocol.User = aws.String(v)
	}
	return protocol
}

func expandSMBMountOptions(l []any) *awstypes.SmbMountOptions {
	if len(l) == 0 || l[0] == nil {
		return nil
	}
	m := l[0].(map[string]any)
	smbMountOptions := &awstypes.SmbMountOptions{Version: awstypes.SmbVersion(m[names.AttrVersion].(string))}
	return smbMountOptions
}

