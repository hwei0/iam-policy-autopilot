package datasync

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/datasync"
	awstypes "github.com/aws/aws-sdk-go-v2/service/datasync/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/provider/sdkv2/importer"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceLocationFSxONTAPFileSystemRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).DataSyncClient(ctx)
	output, err := findLocationFSxONTAPByARN(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] DataSync Location FSx for NetApp ONTAP File System (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading DataSync Location FSx for NetApp ONTAP File System (%s): %s", d.Id(), err)
	}
	uri := aws.ToString(output.LocationUri)
	subdirectory, err := subdirectoryFromLocationURI(uri)
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	d.Set(names.AttrARN, output.LocationArn)
	d.Set(names.AttrCreationTime, output.CreationTime.Format(time.RFC3339))
	d.Set("fsx_filesystem_arn", output.FsxFilesystemArn)
	if output.Protocol != nil && output.Protocol.SMB != nil && aws.ToString(output.Protocol.SMB.Password) == "" {
		if smbPassword := d.Get("protocol.0.smb.0.password").(string); smbPassword != "" {
			output.Protocol.SMB.Password = aws.String(smbPassword)
		}
	}
	if err := d.Set(names.AttrProtocol, flattenProtocol(output.Protocol)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting protocol: %s", err)
	}
	d.Set("security_group_arns", output.SecurityGroupArns)
	d.Set("storage_virtual_machine_arn", output.StorageVirtualMachineArn)
	d.Set("subdirectory", subdirectory)
	d.Set(names.AttrURI, uri)
	return diags
}

func findLocationFSxONTAPByARN(ctx context.Context, conn *datasync.Client, arn string) (*datasync.DescribeLocationFsxOntapOutput, error) {
	input := &datasync.DescribeLocationFsxOntapInput{LocationArn: aws.String(arn)}
	output, err := conn.DescribeLocationFsxOntap(ctx, input)
	if errs.IsAErrorMessageContains[*awstypes.InvalidRequestException](err, "not found") {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func subdirectoryFromLocationURI(uri string) (string, error) {
	submatches := locationURIPattern.FindStringSubmatch(uri)
	if len(submatches) != 3 {
		return "", fmt.Errorf("location URI (%s) does not match pattern %q", uri, locationURIPattern)
	}
	globalIDAndSubdir := submatches[2]
	parsedARN, err := arn.Parse(globalIDAndSubdir)
	if err == nil {
		submatches = s3OutpostsAccessPointARNResourcePattern.FindStringSubmatch(parsedARN.Resource)
		if len(submatches) != 3 {
			return "", fmt.Errorf("location URI S3 on Outposts access point ARN resource (%s) does not match pattern %q", parsedARN.Resource, s3OutpostsAccessPointARNResourcePattern)
		}
		return submatches[2], nil
	}
	submatches = locationURIGlobalIDAndSubdirPattern.FindStringSubmatch(globalIDAndSubdir)
	if len(submatches) != 3 {
		return "", fmt.Errorf("location URI global ID and subdirectory (%s) does not match pattern %q", globalIDAndSubdir, locationURIGlobalIDAndSubdirPattern)
	}
	return submatches[2], nil
}// subdirectoryFromLocationURI extracts the subdirectory from a location URI.
// https://docs.aws.amazon.com/datasync/latest/userguide/API_LocationListEntry.html#DataSync-Type-LocationListEntry-LocationUri


func flattenProtocol(protocol *awstypes.FsxProtocol) []any {
	if protocol == nil {
		return []any{}
	}
	m := map[string]any{}
	if protocol.NFS != nil {
		m["nfs"] = flattenNFS(protocol.NFS)
	}
	if protocol.SMB != nil {
		m["smb"] = flattenSMB(protocol.SMB)
	}
	return []any{m}
}

func flattenNFS(nfs *awstypes.FsxProtocolNfs) [ // todo: go another level down?
]any {
	if nfs == nil {
		return []any{}
	}
	m := map[string]any{"mount_options": flattenNFSMountOptions(nfs.MountOptions)}
	return []any{m}
}

func flattenNFSMountOptions(mountOptions *awstypes.NfsMountOptions) []any {
	if mountOptions == nil {
		return []any{}
	}
	m := map[string]any{names.AttrVersion: string(mountOptions.Version)}
	return []any{m}
}

func flattenSMB(smb *awstypes.FsxProtocolSmb) []any {
	if smb == nil {
		return []any{}
	}
	m := map[string]any{"mount_options": flattenSMBMountOptions(smb.MountOptions)}
	if v := smb.Domain; v != nil {
		m[names.AttrDomain] = aws.ToString(v)
	}
	if v := smb.Password; v != nil {
		m[names.AttrPassword] = aws.ToString(v)
	}
	if v := smb.User; v != nil {
		m["user"] = aws.ToString(v)
	}
	return []any{m}
}

func flattenSMBMountOptions(mountOptions *awstypes.SmbMountOptions) []any {
	if mountOptions == nil {
		return []any{}
	}
	m := map[string]any{names.AttrVersion: string(mountOptions.Version)}
	return []any{m}
}

