package elasticache

import (
	"context"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/elasticache"
	awstypes "github.com/aws/aws-sdk-go-v2/service/elasticache/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/retry"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceSubnetGroupRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ElastiCacheClient(ctx)
	group, err := findCacheSubnetGroupByName(ctx, conn, d.Id())
	if !d.IsNewResource() && retry.NotFound(err) {
		log.Printf("[WARN] ElastiCache Subnet Group (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading ElastiCache Subnet Group (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, group.ARN)
	d.Set(names.AttrDescription, group.CacheSubnetGroupDescription)
	d.Set(names.AttrName, group.CacheSubnetGroupName)
	d.Set(names.AttrSubnetIDs, tfslices.ApplyToAll(group.Subnets, func(v awstypes.Subnet) string {
		return aws.ToString(v.SubnetIdentifier)
	}))
	d.Set(names.AttrVPCID, group.VpcId)
	return diags
}

func findCacheSubnetGroupByName(ctx context.Context, conn *elasticache.Client, name string) (*awstypes.CacheSubnetGroup, error) {
	input := &elasticache.DescribeCacheSubnetGroupsInput{CacheSubnetGroupName: aws.String(name)}
	return findCacheSubnetGroup(ctx, conn, input, tfslices.PredicateTrue[*awstypes.CacheSubnetGroup]())
}

func findCacheSubnetGroup(ctx context.Context, conn *elasticache.Client, input *elasticache.DescribeCacheSubnetGroupsInput, filter tfslices.Predicate[*awstypes.CacheSubnetGroup]) (*awstypes.CacheSubnetGroup, error) {
	output, err := findCacheSubnetGroups(ctx, conn, input, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findCacheSubnetGroups(ctx context.Context, conn *elasticache.Client, input *elasticache.DescribeCacheSubnetGroupsInput, filter tfslices.Predicate[*awstypes.CacheSubnetGroup]) ([]awstypes.CacheSubnetGroup, error) {
	var output []awstypes.CacheSubnetGroup
	pages := elasticache.NewDescribeCacheSubnetGroupsPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if errs.IsA[*awstypes.CacheSubnetGroupNotFoundFault](err) {
			return nil, &retry.NotFoundError{LastError: err}
		}
		if err != nil {
			return nil, err
		}
		for _, v := range page.CacheSubnetGroups {
			if filter(&v) {
				output = append(output, v)
			}
		}
	}
	return output, nil
}

