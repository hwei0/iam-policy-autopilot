package iam

import (
	"context"
	"fmt"
	"log"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/iam"
	awstypes "github.com/aws/aws-sdk-go-v2/service/iam/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	inttypes "github.com/hashicorp/terraform-provider-aws/internal/types"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceVirtualMFADeviceRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IAMClient(ctx)
	vMFA, err := findVirtualMFADeviceBySerialNumber(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] IAM Virtual MFA Device (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading IAM Virtual MFA Device (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, vMFA.SerialNumber)
	path, name, err := parseVirtualMFADeviceARN(aws.ToString(vMFA.SerialNumber))
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading IAM Virtual MFA Device (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrPath, path)
	d.Set("virtual_mfa_device_name", name)
	if v := vMFA.EnableDate; v != nil {
		d.Set("enable_date", aws.ToTime(v).Format(time.RFC3339))
	}
	if u := vMFA.User; u != nil {
		d.Set(names.AttrUserName, u.UserName)
	}
	tags, err := virtualMFADeviceTags(ctx, conn, d.Id())
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "listing IAM Virtual MFA Device (%s) tags: %s", d.Id(), err)
	}
	setTagsOut(ctx, tags)
	return diags
}

func findVirtualMFADeviceBySerialNumber(ctx context.Context, conn *iam.Client, serialNumber string) (*awstypes.VirtualMFADevice, error) {
	var input iam.ListVirtualMFADevicesInput
	return findVirtualMFADevice(ctx, conn, &input, func(v *awstypes.VirtualMFADevice) bool {
		return aws.ToString(v.SerialNumber) == serialNumber
	})
}

func findVirtualMFADevice(ctx context.Context, conn *iam.Client, input *iam.ListVirtualMFADevicesInput, filter tfslices.Predicate[*awstypes.VirtualMFADevice]) (*awstypes.VirtualMFADevice, error) {
	output, err := findVirtualMFADevices(ctx, conn, input, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findVirtualMFADevices(ctx context.Context, conn *iam.Client, input *iam.ListVirtualMFADevicesInput, filter tfslices.Predicate[*awstypes.VirtualMFADevice]) ([]awstypes.VirtualMFADevice, error) {
	var output []awstypes.VirtualMFADevice
	pages := iam.NewListVirtualMFADevicesPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.VirtualMFADevices {
			if p := &v; !inttypes.IsZero(p) && filter(p) {
				output = append(output, v)
			}
		}
	}
	return output, nil
}

func parseVirtualMFADeviceARN(s string) (path, name string, err error) {
	arn, err := arn.Parse(s)
	if err != nil {
		return "", "", err
	}
	re := regexache.MustCompile(`^mfa(/|/[\x{0021}-\x{007E}]+/)([0-9A-Za-z_+=,.@-]+)$`)
	matches := re.FindStringSubmatch(arn.Resource)
	if len(matches) != 3 {
		return "", "", fmt.Errorf("IAM Virtual MFA Device ARN: invalid resource section (%s)", arn.Resource)
	}
	return matches[1], matches[2], nil
}

func (rolePolicyImportID) Parse(id string) (string, map[string]string, error) {
	roleName, policyName, err := rolePolicyParseID(id)
	if err != nil {
		return "", nil, err
	}
	result := map[string]string{names.AttrRole: roleName, names.AttrName: policyName}
	return id, result, nil
}

func rolePolicyParseID(id string) (roleName, policyName string, err error) {
	parts := strings.SplitN(id, ":", 2)
	if len(parts) != 2 {
		err = fmt.Errorf("role_policy id must be of the form <role name>:<policy name>")
		return
	}
	roleName = parts[0]
	policyName = parts[1]
	return
}

func (rolePolicyAttachmentImportID) Parse(id string) (string, map[string]string, error) {
	parts := strings.SplitN(id, "/", 2)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return "", nil, fmt.Errorf("unexpected format for Import ID (%q), expected <role-name>/<policy_arn>", id)
	}
	result := map[string]string{names.AttrRole: parts[0], "policy_arn": parts[1]}
	return id, result, nil
}

func virtualMFADeviceTags(ctx context.Context, conn *iam.Client, identifier string, optFns ...func(*iam.Options)) ([]awstypes.Tag, error) {
	input := iam.ListMFADeviceTagsInput{SerialNumber: aws.String(identifier)}
	var output []awstypes.Tag
	pages := iam.NewListMFADeviceTagsPaginator(conn, &input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx, optFns...)
		if err != nil {
			return nil, err
		}
		output = append(output, page.Tags...)
	}
	return output, nil
}

