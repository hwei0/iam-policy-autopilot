package iam

import (
	"context"
	"fmt"
	"log"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/iam"
	awstypes "github.com/aws/aws-sdk-go-v2/service/iam/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	inttypes "github.com/hashicorp/terraform-provider-aws/internal/types"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceVirtualMFADeviceCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IAMClient(ctx)
	name := d.Get("virtual_mfa_device_name").(string)
	input := iam.CreateVirtualMFADeviceInput{Path: aws.String(d.Get(names.AttrPath).(string)), Tags: getTagsIn(ctx), VirtualMFADeviceName: aws.String(name)}
	output, err := conn.CreateVirtualMFADevice(ctx, &input)
	partition := meta.(*conns.AWSClient).Partition(ctx)
	if input.Tags != nil && errs.IsUnsupportedOperationInPartitionError(partition, err) {
		input.Tags = nil
		output, err = conn.CreateVirtualMFADevice(ctx, &input)
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating IAM Virtual MFA Device (%s): %s", name, err)
	}
	vMFA := output.VirtualMFADevice
	d.SetId(aws.ToString(vMFA.SerialNumber))
	d.Set("base_32_string_seed", string(vMFA.Base32StringSeed))
	d.Set("qr_code_png", string(vMFA.QRCodePNG))
	if tags := getTagsIn(ctx); input.Tags == nil && len(tags) > 0 {
		err := virtualMFADeviceCreateTags(ctx, conn, d.Id(), tags)
		if v, ok := d.GetOk(names.AttrTags); (!ok || len(v.(map[string]any)) == 0) && errs.IsUnsupportedOperationInPartitionError(partition, err) {
			return append(diags, resourceVirtualMFADeviceRead(ctx, d, meta)...)
		}
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "setting IAM Virtual MFA Device (%s) tags: %s", d.Id(), err)
		}
	}
	return append(diags, resourceVirtualMFADeviceRead(ctx, d, meta)...)
}

