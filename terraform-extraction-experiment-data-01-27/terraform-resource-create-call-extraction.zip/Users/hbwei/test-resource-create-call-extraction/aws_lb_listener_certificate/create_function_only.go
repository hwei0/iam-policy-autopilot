package elbv2

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2"
	awstypes "github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceListenerCertificateCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ELBV2Client(ctx)
	listenerARN := d.Get("listener_arn").(string)
	certificateARN := d.Get(names.AttrCertificateARN).(string)
	id := listenerCertificateCreateResourceID(listenerARN, certificateARN)
	input := &elasticloadbalancingv2.AddListenerCertificatesInput{Certificates: []awstypes.Certificate{{CertificateArn: aws.String(certificateARN)}}, ListenerArn: aws.String(listenerARN)}
	_, err := tfresource.RetryWhenIsA[any, *awstypes.CertificateNotFoundException](ctx, iamPropagationTimeout, func(ctx context.Context) (any, error) {
		return conn.AddListenerCertificates(ctx, input)
	})
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating ELBv2 Listener Certificate (%s): %s", id, err)
	}
	d.SetId(id)
	return append(diags, resourceListenerCertificateRead(ctx, d, meta)...)
}

