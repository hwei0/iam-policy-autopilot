package elbv2

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2"
	awstypes "github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceListenerCertificateRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).ELBV2Client(ctx)
	listenerARN, certificateARN, err := listenerCertificateParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	_, err = tfresource.RetryWhenNewResourceNotFound(ctx, elbv2PropagationTimeout, func(ctx context.Context) (any, error) {
		return findListenerCertificateByTwoPartKey(ctx, conn, listenerARN, certificateARN)
	}, d.IsNewResource())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] ELBv2 Listener Certificate (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading ELBv2 Listener Certificate (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrCertificateARN, certificateARN)
	d.Set("listener_arn", listenerARN)
	return diags
}

func listenerCertificateParseResourceID(id string) (string, string, error) {
	parts := strings.SplitN(id, listenerCertificateResourceIDSeparator, 2)
	if len(parts) == 2 && parts[0] != "" && parts[1] != "" {
		return parts[0], parts[1], nil
	}
	return "", "", fmt.Errorf("unexpected format for ID (%[1]s), expected LISTENER_ARN%[2]sCERTIFICATE_ARN", id, listenerCertificateResourceIDSeparator)
}

func findListenerCertificateByTwoPartKey(ctx context.Context, conn *elasticloadbalancingv2.Client, listenerARN, certificateARN string) (*awstypes.Certificate, error) {
	input := &elasticloadbalancingv2.DescribeListenerCertificatesInput{ListenerArn: aws.String(listenerARN), PageSize: aws.Int32(400)}
	return findListenerCertificate(ctx, conn, input, func(v *awstypes.Certificate) bool {
		return !aws.ToBool(v.IsDefault) && aws.ToString(v.CertificateArn) == certificateARN
	})
}

func findListenerCertificate(ctx context.Context, conn *elasticloadbalancingv2.Client, input *elasticloadbalancingv2.DescribeListenerCertificatesInput, filter tfslices.Predicate[*awstypes.Certificate]) (*awstypes.Certificate, error) {
	output, err := findListenerCertificates(ctx, conn, input, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findListenerCertificates(ctx context.Context, conn *elasticloadbalancingv2.Client, input *elasticloadbalancingv2.DescribeListenerCertificatesInput, filter tfslices.Predicate[*awstypes.Certificate]) ([]awstypes.Certificate, error) {
	var output []awstypes.Certificate
	err := describeListenerCertificatesPages(ctx, conn, input, func(page *elasticloadbalancingv2.DescribeListenerCertificatesOutput, lastPage bool) bool {
		if page == nil {
			return !lastPage
		}
		for _, v := range page.Certificates {
			if filter(&v) {
				output = append(output, v)
			}
		}
		return !lastPage
	})
	if errs.IsA[*awstypes.ListenerNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	return output, nil
}

func describeListenerCertificatesPages(ctx context.Context, conn *elasticloadbalancingv2.Client, input *elasticloadbalancingv2.DescribeListenerCertificatesInput, fn func(*elasticloadbalancingv2.DescribeListenerCertificatesOutput, bool) bool, optFns ...func(*elasticloadbalancingv2.Options)) error {
	for {
		output, err := conn.DescribeListenerCertificates(ctx, input, optFns...)
		if err != nil {
			return smarterr.NewError(err)
		}
		lastPage := aws.ToString(output.NextMarker) == ""
		if !fn(output, lastPage) || lastPage {
			break
		}
		input.Marker = output.NextMarker
	}
	return nil
}

