package identitystore

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/identitystore"
	"github.com/aws/aws-sdk-go-v2/service/identitystore/document"
	"github.com/aws/aws-sdk-go-v2/service/identitystore/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandAddresses(tfList []any) []types.Address {
	apiObjects := make([]types.Address, 0, len(tfList))
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObject := expandAddress(tfMap)
		if apiObject == nil {
			continue
		}
		apiObjects = append(apiObjects, *apiObject)
	}
	return apiObjects
}

func expandAddress(tfMap map[string]any) *types.Address {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.Address{}
	if v, ok := tfMap["country"].(string); ok && v != "" {
		apiObject.Country = aws.String(v)
	}
	if v, ok := tfMap["formatted"].(string); ok && v != "" {
		apiObject.Formatted = aws.String(v)
	}
	if v, ok := tfMap["locality"].(string); ok && v != "" {
		apiObject.Locality = aws.String(v)
	}
	if v, ok := tfMap["postal_code"].(string); ok && v != "" {
		apiObject.PostalCode = aws.String(v)
	}
	apiObject.Primary = tfMap["primary"].(bool)
	if v, ok := tfMap[names.AttrRegion].(string); ok && v != "" {
		apiObject.Region = aws.String(v)
	}
	if v, ok := tfMap["street_address"].(string); ok && v != "" {
		apiObject.StreetAddress = aws.String(v)
	}
	if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
		apiObject.Type = aws.String(v)
	}
	return apiObject
}

func expandEmails(tfList []any) []types.Email {
	apiObjects := make([]types.Email, 0, len(tfList))
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObject := expandEmail(tfMap)
		if apiObject == nil {
			continue
		}
		apiObjects = append(apiObjects, *apiObject)
	}
	return apiObjects
}

func expandEmail(tfMap map[string]any) *types.Email {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.Email{}
	apiObject.Primary = tfMap["primary"].(bool)
	if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
		apiObject.Type = aws.String(v)
	}
	if v, ok := tfMap[names.AttrValue].(string); ok && v != "" {
		apiObject.Value = aws.String(v)
	}
	return apiObject
}

func expandName(tfMap map[string]any) *types.Name {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.Name{}
	if v, ok := tfMap["family_name"].(string); ok && v != "" {
		apiObject.FamilyName = aws.String(v)
	}
	if v, ok := tfMap["formatted"].(string); ok && v != "" {
		apiObject.Formatted = aws.String(v)
	}
	if v, ok := tfMap["given_name"].(string); ok && v != "" {
		apiObject.GivenName = aws.String(v)
	}
	if v, ok := tfMap["honorific_prefix"].(string); ok && v != "" {
		apiObject.HonorificPrefix = aws.String(v)
	}
	if v, ok := tfMap["honorific_suffix"].(string); ok && v != "" {
		apiObject.HonorificSuffix = aws.String(v)
	}
	if v, ok := tfMap["middle_name"].(string); ok && v != "" {
		apiObject.MiddleName = aws.String(v)
	}
	return apiObject
}

func expandPhoneNumbers(tfList []any) []types.PhoneNumber {
	apiObjects := make([]types.PhoneNumber, 0, len(tfList))
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObject := expandPhoneNumber(tfMap)
		if apiObject == nil {
			continue
		}
		apiObjects = append(apiObjects, *apiObject)
	}
	return apiObjects
}

func expandPhoneNumber(tfMap map[string]any) *types.PhoneNumber {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.PhoneNumber{}
	apiObject.Primary = tfMap["primary"].(bool)
	if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
		apiObject.Type = aws.String(v)
	}
	if v, ok := tfMap[names.AttrValue].(string); ok && v != "" {
		apiObject.Value = aws.String(v)
	}
	return apiObject
}

