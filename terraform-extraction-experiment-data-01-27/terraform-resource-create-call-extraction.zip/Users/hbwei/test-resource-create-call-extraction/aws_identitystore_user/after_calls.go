package identitystore

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/identitystore"
	"github.com/aws/aws-sdk-go-v2/service/identitystore/document"
	"github.com/aws/aws-sdk-go-v2/service/identitystore/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func userCreateResourceID(identityStoreID, userID string) string {
	parts := []string{identityStoreID, userID}
	id := strings.Join(parts, userResourceIDSeparator)
	return id
}

func resourceUserRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IdentityStoreClient(ctx)
	identityStoreID, userID, err := userParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	out, err := findUserByTwoPartKey(ctx, conn, identityStoreID, userID)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] IdentityStore User (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading IdentityStore User (%s): %s", d.Id(), err)
	}
	if err := d.Set("addresses", flattenAddresses(out.Addresses)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting addresses: %s", err)
	}
	d.Set(names.AttrDisplayName, out.DisplayName)
	if err := d.Set("emails", flattenEmails(out.Emails)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting emails: %s", err)
	}
	if err := d.Set("external_ids", flattenExternalIDs(out.ExternalIds)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting external_ids: %s", err)
	}
	d.Set("identity_store_id", out.IdentityStoreId)
	d.Set("locale", out.Locale)
	if err := d.Set(names.AttrName, []any{flattenName(out.Name)}); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting name: %s", err)
	}
	d.Set("nickname", out.NickName)
	if err := d.Set("phone_numbers", flattenPhoneNumbers(out.PhoneNumbers)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting phone_numbers: %s", err)
	}
	d.Set("preferred_language", out.PreferredLanguage)
	d.Set("profile_url", out.ProfileUrl)
	d.Set("timezone", out.Timezone)
	d.Set("title", out.Title)
	d.Set("user_id", out.UserId)
	d.Set(names.AttrUserName, out.UserName)
	d.Set("user_type", out.UserType)
	return diags
}

func userParseResourceID(id string) (string, string, error) {
	parts := strings.Split(id, userResourceIDSeparator)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return "", "", fmt.Errorf("unexpected format of ID (%[1]s), expected identity-store-id%[2]sgroup-id", id, groupResourceIDSeparator)
	}
	return parts[0], parts[1], nil
}

func findUserByTwoPartKey(ctx context.Context, conn *identitystore.Client, identityStoreID, userID string) (*identitystore.DescribeUserOutput, error) {
	input := identitystore.DescribeUserInput{IdentityStoreId: aws.String(identityStoreID), UserId: aws.String(userID)}
	return findUser(ctx, conn, &input)
}

func findUser(ctx context.Context, conn *identitystore.Client, input *identitystore.DescribeUserInput) (*identitystore.DescribeUserOutput, error) {
	output, err := conn.DescribeUser(ctx, input)
	if errs.IsA[*types.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func flattenAddresses(apiObjects []types.Address) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenAddress(&apiObject))
	}
	return tfList
}

func flattenAddress(apiObject *types.Address) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.Country; v != nil {
		tfMap["country"] = aws.ToString(v)
	}
	if v := apiObject.Formatted; v != nil {
		tfMap["formatted"] = aws.ToString(v)
	}
	if v := apiObject.Locality; v != nil {
		tfMap["locality"] = aws.ToString(v)
	}
	if v := apiObject.PostalCode; v != nil {
		tfMap["postal_code"] = aws.ToString(v)
	}
	tfMap["primary"] = apiObject.Primary
	if v := apiObject.Region; v != nil {
		tfMap[names.AttrRegion] = aws.ToString(v)
	}
	if v := apiObject.StreetAddress; v != nil {
		tfMap["street_address"] = aws.ToString(v)
	}
	if v := apiObject.Type; v != nil {
		tfMap[names.AttrType] = aws.ToString(v)
	}
	return tfMap
}

func flattenEmails(apiObjects []types.Email) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenEmail(&apiObject))
	}
	return tfList
}

func flattenEmail(apiObject *types.Email) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	tfMap["primary"] = apiObject.Primary
	if v := apiObject.Type; v != nil {
		tfMap[names.AttrType] = aws.ToString(v)
	}
	if v := apiObject.Value; v != nil {
		tfMap[names.AttrValue] = aws.ToString(v)
	}
	return tfMap
}

func flattenExternalIDs(apiObjects []types.ExternalId) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenExternalID(&apiObject))
	}
	return tfList
}

func flattenExternalID(apiObject *types.ExternalId) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.Id; v != nil {
		tfMap[names.AttrID] = aws.ToString(v)
	}
	if v := apiObject.Issuer; v != nil {
		tfMap[names.AttrIssuer] = aws.ToString(v)
	}
	return tfMap
}

func flattenName(apiObject *types.Name) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.FamilyName; v != nil {
		tfMap["family_name"] = aws.ToString(v)
	}
	if v := apiObject.Formatted; v != nil {
		tfMap["formatted"] = aws.ToString(v)
	}
	if v := apiObject.GivenName; v != nil {
		tfMap["given_name"] = aws.ToString(v)
	}
	if v := apiObject.HonorificPrefix; v != nil {
		tfMap["honorific_prefix"] = aws.ToString(v)
	}
	if v := apiObject.HonorificSuffix; v != nil {
		tfMap["honorific_suffix"] = aws.ToString(v)
	}
	if v := apiObject.MiddleName; v != nil {
		tfMap["middle_name"] = aws.ToString(v)
	}
	return tfMap
}

func flattenPhoneNumbers(apiObjects []types.PhoneNumber) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenPhoneNumber(&apiObject))
	}
	return tfList
}

func flattenPhoneNumber(apiObject *types.PhoneNumber) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	tfMap["primary"] = apiObject.Primary
	if v := apiObject.Type; v != nil {
		tfMap[names.AttrType] = aws.ToString(v)
	}
	if v := apiObject.Value; v != nil {
		tfMap[names.AttrValue] = aws.ToString(v)
	}
	return tfMap
}

