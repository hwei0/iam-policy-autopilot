package identitystore

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/identitystore"
	"github.com/aws/aws-sdk-go-v2/service/identitystore/document"
	"github.com/aws/aws-sdk-go-v2/service/identitystore/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceUserCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IdentityStoreClient(ctx)
	identityStoreID := d.Get("identity_store_id").(string)
	username := d.Get(names.AttrUserName).(string)
	input := &identitystore.CreateUserInput{DisplayName: aws.String(d.Get(names.AttrDisplayName).(string)), IdentityStoreId: aws.String(identityStoreID), UserName: aws.String(username)}
	if v, ok := d.GetOk("addresses"); ok && len(v.([]any)) > 0 {
		input.Addresses = expandAddresses(v.([]any))
	}
	if v, ok := d.GetOk("emails"); ok && len(v.([]any)) > 0 {
		input.Emails = expandEmails(v.([]any))
	}
	if v, ok := d.GetOk("locale"); ok {
		input.Locale = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrName); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input.Name = expandName(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("phone_numbers"); ok && len(v.([]any)) > 0 {
		input.PhoneNumbers = expandPhoneNumbers(v.([]any))
	}
	if v, ok := d.GetOk("nickname"); ok {
		input.NickName = aws.String(v.(string))
	}
	if v, ok := d.GetOk("preferred_language"); ok {
		input.PreferredLanguage = aws.String(v.(string))
	}
	if v, ok := d.GetOk("profile_url"); ok {
		input.ProfileUrl = aws.String(v.(string))
	}
	if v, ok := d.GetOk("timezone"); ok {
		input.Timezone = aws.String(v.(string))
	}
	if v, ok := d.GetOk("title"); ok {
		input.Title = aws.String(v.(string))
	}
	if v, ok := d.GetOk("user_type"); ok {
		input.UserType = aws.String(v.(string))
	}
	output, err := conn.CreateUser(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating IdentityStore User (%s): %s", username, err)
	}
	d.SetId(userCreateResourceID(identityStoreID, aws.ToString(output.UserId)))
	return append(diags, resourceUserRead(ctx, d, meta)...)
}

func expandAddresses(tfList []any) []types.Address {
	apiObjects := make([]types.Address, 0, len(tfList))
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObject := expandAddress(tfMap)
		if apiObject == nil {
			continue
		}
		apiObjects = append(apiObjects, *apiObject)
	}
	return apiObjects
}

func expandAddress(tfMap map[string]any) *types.Address {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.Address{}
	if v, ok := tfMap["country"].(string); ok && v != "" {
		apiObject.Country = aws.String(v)
	}
	if v, ok := tfMap["formatted"].(string); ok && v != "" {
		apiObject.Formatted = aws.String(v)
	}
	if v, ok := tfMap["locality"].(string); ok && v != "" {
		apiObject.Locality = aws.String(v)
	}
	if v, ok := tfMap["postal_code"].(string); ok && v != "" {
		apiObject.PostalCode = aws.String(v)
	}
	apiObject.Primary = tfMap["primary"].(bool)
	if v, ok := tfMap[names.AttrRegion].(string); ok && v != "" {
		apiObject.Region = aws.String(v)
	}
	if v, ok := tfMap["street_address"].(string); ok && v != "" {
		apiObject.StreetAddress = aws.String(v)
	}
	if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
		apiObject.Type = aws.String(v)
	}
	return apiObject
}

func expandEmails(tfList []any) []types.Email {
	apiObjects := make([]types.Email, 0, len(tfList))
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObject := expandEmail(tfMap)
		if apiObject == nil {
			continue
		}
		apiObjects = append(apiObjects, *apiObject)
	}
	return apiObjects
}

func expandEmail(tfMap map[string]any) *types.Email {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.Email{}
	apiObject.Primary = tfMap["primary"].(bool)
	if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
		apiObject.Type = aws.String(v)
	}
	if v, ok := tfMap[names.AttrValue].(string); ok && v != "" {
		apiObject.Value = aws.String(v)
	}
	return apiObject
}

func expandName(tfMap map[string]any) *types.Name {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.Name{}
	if v, ok := tfMap["family_name"].(string); ok && v != "" {
		apiObject.FamilyName = aws.String(v)
	}
	if v, ok := tfMap["formatted"].(string); ok && v != "" {
		apiObject.Formatted = aws.String(v)
	}
	if v, ok := tfMap["given_name"].(string); ok && v != "" {
		apiObject.GivenName = aws.String(v)
	}
	if v, ok := tfMap["honorific_prefix"].(string); ok && v != "" {
		apiObject.HonorificPrefix = aws.String(v)
	}
	if v, ok := tfMap["honorific_suffix"].(string); ok && v != "" {
		apiObject.HonorificSuffix = aws.String(v)
	}
	if v, ok := tfMap["middle_name"].(string); ok && v != "" {
		apiObject.MiddleName = aws.String(v)
	}
	return apiObject
}

func expandPhoneNumbers(tfList []any) []types.PhoneNumber {
	apiObjects := make([]types.PhoneNumber, 0, len(tfList))
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObject := expandPhoneNumber(tfMap)
		if apiObject == nil {
			continue
		}
		apiObjects = append(apiObjects, *apiObject)
	}
	return apiObjects
}

func expandPhoneNumber(tfMap map[string]any) *types.PhoneNumber {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.PhoneNumber{}
	apiObject.Primary = tfMap["primary"].(bool)
	if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
		apiObject.Type = aws.String(v)
	}
	if v, ok := tfMap[names.AttrValue].(string); ok && v != "" {
		apiObject.Value = aws.String(v)
	}
	return apiObject
}

func userCreateResourceID(identityStoreID, userID string) string {
	parts := []string{identityStoreID, userID}
	id := strings.Join(parts, userResourceIDSeparator)
	return id
}

func resourceUserRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IdentityStoreClient(ctx)
	identityStoreID, userID, err := userParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	out, err := findUserByTwoPartKey(ctx, conn, identityStoreID, userID)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] IdentityStore User (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading IdentityStore User (%s): %s", d.Id(), err)
	}
	if err := d.Set("addresses", flattenAddresses(out.Addresses)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting addresses: %s", err)
	}
	d.Set(names.AttrDisplayName, out.DisplayName)
	if err := d.Set("emails", flattenEmails(out.Emails)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting emails: %s", err)
	}
	if err := d.Set("external_ids", flattenExternalIDs(out.ExternalIds)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting external_ids: %s", err)
	}
	d.Set("identity_store_id", out.IdentityStoreId)
	d.Set("locale", out.Locale)
	if err := d.Set(names.AttrName, []any{flattenName(out.Name)}); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting name: %s", err)
	}
	d.Set("nickname", out.NickName)
	if err := d.Set("phone_numbers", flattenPhoneNumbers(out.PhoneNumbers)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting phone_numbers: %s", err)
	}
	d.Set("preferred_language", out.PreferredLanguage)
	d.Set("profile_url", out.ProfileUrl)
	d.Set("timezone", out.Timezone)
	d.Set("title", out.Title)
	d.Set("user_id", out.UserId)
	d.Set(names.AttrUserName, out.UserName)
	d.Set("user_type", out.UserType)
	return diags
}

func userParseResourceID(id string) (string, string, error) {
	parts := strings.Split(id, userResourceIDSeparator)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return "", "", fmt.Errorf("unexpected format of ID (%[1]s), expected identity-store-id%[2]sgroup-id", id, groupResourceIDSeparator)
	}
	return parts[0], parts[1], nil
}

func findUserByTwoPartKey(ctx context.Context, conn *identitystore.Client, identityStoreID, userID string) (*identitystore.DescribeUserOutput, error) {
	input := identitystore.DescribeUserInput{IdentityStoreId: aws.String(identityStoreID), UserId: aws.String(userID)}
	return findUser(ctx, conn, &input)
}

func findUser(ctx context.Context, conn *identitystore.Client, input *identitystore.DescribeUserInput) (*identitystore.DescribeUserOutput, error) {
	output, err := conn.DescribeUser(ctx, input)
	if errs.IsA[*types.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func flattenAddresses(apiObjects []types.Address) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenAddress(&apiObject))
	}
	return tfList
}

func flattenAddress(apiObject *types.Address) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.Country; v != nil {
		tfMap["country"] = aws.ToString(v)
	}
	if v := apiObject.Formatted; v != nil {
		tfMap["formatted"] = aws.ToString(v)
	}
	if v := apiObject.Locality; v != nil {
		tfMap["locality"] = aws.ToString(v)
	}
	if v := apiObject.PostalCode; v != nil {
		tfMap["postal_code"] = aws.ToString(v)
	}
	tfMap["primary"] = apiObject.Primary
	if v := apiObject.Region; v != nil {
		tfMap[names.AttrRegion] = aws.ToString(v)
	}
	if v := apiObject.StreetAddress; v != nil {
		tfMap["street_address"] = aws.ToString(v)
	}
	if v := apiObject.Type; v != nil {
		tfMap[names.AttrType] = aws.ToString(v)
	}
	return tfMap
}

func flattenEmails(apiObjects []types.Email) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenEmail(&apiObject))
	}
	return tfList
}

func flattenEmail(apiObject *types.Email) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	tfMap["primary"] = apiObject.Primary
	if v := apiObject.Type; v != nil {
		tfMap[names.AttrType] = aws.ToString(v)
	}
	if v := apiObject.Value; v != nil {
		tfMap[names.AttrValue] = aws.ToString(v)
	}
	return tfMap
}

func flattenExternalIDs(apiObjects []types.ExternalId) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenExternalID(&apiObject))
	}
	return tfList
}

func flattenExternalID(apiObject *types.ExternalId) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.Id; v != nil {
		tfMap[names.AttrID] = aws.ToString(v)
	}
	if v := apiObject.Issuer; v != nil {
		tfMap[names.AttrIssuer] = aws.ToString(v)
	}
	return tfMap
}

func flattenName(apiObject *types.Name) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.FamilyName; v != nil {
		tfMap["family_name"] = aws.ToString(v)
	}
	if v := apiObject.Formatted; v != nil {
		tfMap["formatted"] = aws.ToString(v)
	}
	if v := apiObject.GivenName; v != nil {
		tfMap["given_name"] = aws.ToString(v)
	}
	if v := apiObject.HonorificPrefix; v != nil {
		tfMap["honorific_prefix"] = aws.ToString(v)
	}
	if v := apiObject.HonorificSuffix; v != nil {
		tfMap["honorific_suffix"] = aws.ToString(v)
	}
	if v := apiObject.MiddleName; v != nil {
		tfMap["middle_name"] = aws.ToString(v)
	}
	return tfMap
}

func flattenPhoneNumbers(apiObjects []types.PhoneNumber) []any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenPhoneNumber(&apiObject))
	}
	return tfList
}

func flattenPhoneNumber(apiObject *types.PhoneNumber) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	tfMap["primary"] = apiObject.Primary
	if v := apiObject.Type; v != nil {
		tfMap[names.AttrType] = aws.ToString(v)
	}
	if v := apiObject.Value; v != nil {
		tfMap[names.AttrValue] = aws.ToString(v)
	}
	return tfMap
}

