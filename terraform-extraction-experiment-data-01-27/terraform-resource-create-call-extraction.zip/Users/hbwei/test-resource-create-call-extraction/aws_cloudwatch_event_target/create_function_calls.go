package events

import (
	"context"
	"errors"
	"fmt"
	"log"
	"math"
	"strings"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	inttypes "github.com/hashicorp/terraform-provider-aws/internal/types"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceTargetCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EventsClient(ctx)
	ruleName := d.Get(names.AttrRule).(string)
	var targetID string
	if v, ok := d.GetOk("target_id"); ok {
		targetID = v.(string)
	} else {
		targetID = id.UniqueId()
		d.Set("target_id", targetID)
	}
	var eventBusName string
	if v, ok := d.GetOk("event_bus_name"); ok {
		eventBusName = v.(string)
	}
	id := targetCreateResourceID(eventBusName, ruleName, targetID)
	input := expandPutTargetsInput(ctx, d)
	output, err := conn.PutTargets(ctx, input)
	if err == nil && output != nil {
		err = putTargetsError(output.FailedEntries)
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating EventBridge Target (%s): %s", id, err)
	}
	d.SetId(id)
	return append(diags, resourceTargetRead(ctx, d, meta)...)
}

func targetCreateResourceID(eventBusName, ruleName, targetID string) string {
	var parts []string
	if eventBusName == "" || eventBusName == DefaultEventBusName {
		parts = []string{ruleName, targetID}
	} else {
		parts = []string{eventBusName, ruleName, targetID}
	}
	id := strings.Join(parts, targetResourceIDSeparator)
	return id
}

func expandPutTargetsInput(ctx context.Context, d *schema.ResourceData) *eventbridge.PutTargetsInput {
	target := types.Target{Arn: aws.String(d.Get(names.AttrARN).(string)), Id: aws.String(d.Get("target_id").(string))}
	if v, ok := d.GetOk("input"); ok {
		target.Input = aws.String(v.(string))
	}
	if v, ok := d.GetOk("input_path"); ok {
		target.InputPath = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrRoleARN); ok {
		target.RoleArn = aws.String(v.(string))
	}
	if v, ok := d.GetOk("run_command_targets"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.RunCommandParameters = expandTargetRunParameters(v.([]any))
	}
	if v, ok := d.GetOk("ecs_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.EcsParameters = expandTargetECSParameters(ctx, v.([]any))
	}
	if v, ok := d.GetOk("redshift_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.RedshiftDataParameters = expandTargetRedshiftParameters(v.([]any))
	}
	if v, ok := d.GetOk("http_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.HttpParameters = expandTargetHTTPParameters(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("batch_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.BatchParameters = expandTargetBatchParameters(v.([]any))
	}
	if v, ok := d.GetOk("kinesis_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.KinesisParameters = expandTargetKinesisParameters(v.([]any))
	}
	if v, ok := d.GetOk("sqs_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.SqsParameters = expandTargetSQSParameters(v.([]any))
	}
	if v, ok := d.GetOk("sagemaker_pipeline_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.SageMakerPipelineParameters = expandTargetSageMakerPipelineParameters(v.([]any))
	}
	if v, ok := d.GetOk("input_transformer"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.InputTransformer = expandTransformerParameters(v.([]any))
	}
	if v, ok := d.GetOk("retry_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.RetryPolicy = expandRetryPolicyParameters(v.([]any))
	}
	if v, ok := d.GetOk("dead_letter_config"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.DeadLetterConfig = expandDeadLetterParametersConfig(v.([]any))
	}
	if v, ok := d.GetOk("appsync_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.AppSyncParameters = expandAppSyncParameters(v.([]any))
	}
	input := &eventbridge.PutTargetsInput{Rule: aws.String(d.Get(names.AttrRule).(string)), Targets: []types.Target{target}}
	if v, ok := d.GetOk("event_bus_name"); ok {
		input.EventBusName = aws.String(v.(string))
	}
	return input
}

func expandTargetRunParameters(config []any) *types.RunCommandParameters {
	commands := make([]types.RunCommandTarget, 0)
	for _, c := range config {
		param := c.(map[string]any)
		command := types.RunCommandTarget{Key: aws.String(param[names.AttrKey].(string)), Values: flex.ExpandStringValueList(param[names.AttrValues].([]any))}
		commands = append(commands, command)
	}
	command := &types.RunCommandParameters{RunCommandTargets: commands}
	return command
}

func expandTargetECSParameters(ctx context.Context, tfList []any) *types.EcsParameters {
	ecsParameters := &types.EcsParameters{}
	for _, c := range tfList {
		tfMap := c.(map[string]any)
		tags := tftags.New(ctx, tfMap[names.AttrTags].(map[string]any))
		if v, ok := tfMap[names.AttrCapacityProviderStrategy].(*schema.Set); ok && v.Len() > 0 {
			ecsParameters.CapacityProviderStrategy = expandTargetCapacityProviderStrategy(v.List())
		}
		if v, ok := tfMap["group"].(string); ok && v != "" {
			ecsParameters.Group = aws.String(v)
		}
		if v, ok := tfMap["launch_type"].(string); ok && v != "" {
			ecsParameters.LaunchType = types.LaunchType(v)
		}
		if v, ok := tfMap[names.AttrNetworkConfiguration]; ok {
			ecsParameters.NetworkConfiguration = expandTargetECSParametersNetworkConfiguration(v.([]any))
		}
		if v, ok := tfMap["platform_version"].(string); ok && v != "" {
			ecsParameters.PlatformVersion = aws.String(v)
		}
		if v, ok := tfMap["placement_constraint"].(*schema.Set); ok && v.Len() > 0 {
			ecsParameters.PlacementConstraints = expandTargetPlacementConstraints(v.List())
		}
		if v, ok := tfMap["ordered_placement_strategy"]; ok {
			ecsParameters.PlacementStrategy = expandTargetPlacementStrategies(v.([]any))
		}
		if v, ok := tfMap[names.AttrPropagateTags].(string); ok && v != "" {
			ecsParameters.PropagateTags = types.PropagateTags(v)
		}
		if len(tags) > 0 {
			ecsParameters.Tags = svcTags(tags.IgnoreAWS())
		}
		ecsParameters.EnableExecuteCommand = tfMap["enable_execute_command"].(bool)
		ecsParameters.EnableECSManagedTags = tfMap["enable_ecs_managed_tags"].(bool)
		ecsParameters.TaskCount = aws.Int32(int32(tfMap["task_count"].(int)))
		ecsParameters.TaskDefinitionArn = aws.String(tfMap["task_definition_arn"].(string))
	}
	return ecsParameters
}

func expandTargetCapacityProviderStrategy(tfList []any) []types.CapacityProviderStrategyItem {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.CapacityProviderStrategyItem
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		cp := tfMapRaw.(map[string]any)
		apiObject := types.CapacityProviderStrategyItem{}
		if val, ok := cp["base"]; ok {
			apiObject.Base = int32(val.(int))
		}
		if val, ok := cp[names.AttrWeight]; ok {
			apiObject.Weight = int32(val.(int))
		}
		if val, ok := cp["capacity_provider"]; ok {
			apiObject.CapacityProvider = aws.String(val.(string))
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTargetECSParametersNetworkConfiguration(nc []any) *types.NetworkConfiguration {
	if len(nc) == 0 {
		return nil
	}
	awsVpcConfig := &types.AwsVpcConfiguration{}
	raw := nc[0].(map[string]any)
	if val, ok := raw[names.AttrSecurityGroups]; ok {
		awsVpcConfig.SecurityGroups = flex.ExpandStringValueSet(val.(*schema.Set))
	}
	awsVpcConfig.Subnets = flex.ExpandStringValueSet(raw[names.AttrSubnets].(*schema.Set))
	if val, ok := raw["assign_public_ip"].(bool); ok {
		awsVpcConfig.AssignPublicIp = types.AssignPublicIpDisabled
		if val {
			awsVpcConfig.AssignPublicIp = types.AssignPublicIpEnabled
		}
	}
	return &types.NetworkConfiguration{AwsvpcConfiguration: awsVpcConfig}
}

func expandTargetPlacementConstraints(tfList []any) []types.PlacementConstraint {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.PlacementConstraint
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		tfMap := tfMapRaw.(map[string]any)
		apiObject := types.PlacementConstraint{}
		if v, ok := tfMap[names.AttrExpression].(string); ok && v != "" {
			apiObject.Expression = aws.String(v)
		}
		if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
			apiObject.Type = types.PlacementConstraintType(v)
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTargetPlacementStrategies(tfList []any) []types.PlacementStrategy {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.PlacementStrategy
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		tfMap := tfMapRaw.(map[string]any)
		apiObject := types.PlacementStrategy{}
		if v, ok := tfMap[names.AttrField].(string); ok && v != "" {
			apiObject.Field = aws.String(v)
		}
		if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
			apiObject.Type = types.PlacementStrategyType(v)
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTargetRedshiftParameters(config []any) *types.RedshiftDataParameters {
	redshiftParameters := &types.RedshiftDataParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		redshiftParameters.Database = aws.String(param[names.AttrDatabase].(string))
		redshiftParameters.Sql = aws.String(param["sql"].(string))
		if val, ok := param["with_event"].(bool); ok {
			redshiftParameters.WithEvent = val
		}
		if val, ok := param["statement_name"].(string); ok && val != "" {
			redshiftParameters.StatementName = aws.String(val)
		}
		if val, ok := param["secrets_manager_arn"].(string); ok && val != "" {
			redshiftParameters.SecretManagerArn = aws.String(val)
		}
		if val, ok := param["db_user"].(string); ok && val != "" {
			redshiftParameters.DbUser = aws.String(val)
		}
	}
	return redshiftParameters
}

func expandTargetHTTPParameters(tfMap map[string]any) *types.HttpParameters {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.HttpParameters{}
	if v, ok := tfMap["header_parameters"].(map[string]any); ok && len(v) > 0 {
		apiObject.HeaderParameters = flex.ExpandStringValueMap(v)
	}
	if v, ok := tfMap["path_parameter_values"].([]any); ok && len(v) > 0 {
		apiObject.PathParameterValues = flex.ExpandStringValueList(v)
	}
	if v, ok := tfMap["query_string_parameters"].(map[string]any); ok && len(v) > 0 {
		apiObject.QueryStringParameters = flex.ExpandStringValueMap(v)
	}
	return apiObject
}

func expandTargetBatchParameters(config []any) *types.BatchParameters {
	batchParameters := &types.BatchParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		batchParameters.JobDefinition = aws.String(param["job_definition"].(string))
		batchParameters.JobName = aws.String(param["job_name"].(string))
		if v, ok := param["array_size"].(int); ok && v > 1 && v <= 10000 {
			arrayProperties := &types.BatchArrayProperties{}
			arrayProperties.Size = int32(v)
			batchParameters.ArrayProperties = arrayProperties
		}
		if v, ok := param["job_attempts"].(int); ok && v > 0 && v <= 10 {
			retryStrategy := &types.BatchRetryStrategy{}
			retryStrategy.Attempts = int32(v)
			batchParameters.RetryStrategy = retryStrategy
		}
	}
	return batchParameters
}

func expandTargetKinesisParameters(config []any) *types.KinesisParameters {
	kinesisParameters := &types.KinesisParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		if v, ok := param["partition_key_path"].(string); ok && v != "" {
			kinesisParameters.PartitionKeyPath = aws.String(v)
		}
	}
	return kinesisParameters
}

func expandTargetSQSParameters(config []any) *types.SqsParameters {
	sqsParameters := &types.SqsParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		if v, ok := param["message_group_id"].(string); ok && v != "" {
			sqsParameters.MessageGroupId = aws.String(v)
		}
	}
	return sqsParameters
}

func expandTargetSageMakerPipelineParameters(config []any) *types.SageMakerPipelineParameters {
	sageMakerPipelineParameters := &types.SageMakerPipelineParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		if v, ok := param["pipeline_parameter_list"].(*schema.Set); ok && v.Len() > 0 {
			sageMakerPipelineParameters.PipelineParameterList = expandTargetSageMakerPipelineParameterList(v.List())
		}
	}
	return sageMakerPipelineParameters
}

func expandTargetSageMakerPipelineParameterList(tfList []any) []types.SageMakerPipelineParameter {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.SageMakerPipelineParameter
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		tfMap := tfMapRaw.(map[string]any)
		apiObject := types.SageMakerPipelineParameter{}
		if v, ok := tfMap[names.AttrName].(string); ok && v != "" {
			apiObject.Name = aws.String(v)
		}
		if v, ok := tfMap[names.AttrValue].(string); ok && v != "" {
			apiObject.Value = aws.String(v)
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTransformerParameters(config []any) *types.InputTransformer {
	transformerParameters := &types.InputTransformer{}
	inputPathsMaps := map[string]string{}
	for _, c := range config {
		param := c.(map[string]any)
		inputPaths := param["input_paths"].(map[string]any)
		for k, v := range inputPaths {
			inputPathsMaps[k] = v.(string)
		}
		transformerParameters.InputTemplate = aws.String(param["input_template"].(string))
	}
	transformerParameters.InputPathsMap = inputPathsMaps
	return transformerParameters
}

func expandRetryPolicyParameters(rp []any) *types.RetryPolicy {
	retryPolicy := &types.RetryPolicy{}
	for _, v := range rp {
		params := v.(map[string]any)
		if val, ok := params["maximum_event_age_in_seconds"].(int); ok {
			retryPolicy.MaximumEventAgeInSeconds = aws.Int32(int32(val))
		}
		if val, ok := params["maximum_retry_attempts"].(int); ok {
			retryPolicy.MaximumRetryAttempts = aws.Int32(int32(val))
		}
	}
	return retryPolicy
}

func expandDeadLetterParametersConfig(dlp []any) *types.DeadLetterConfig {
	deadLetterConfig := &types.DeadLetterConfig{}
	for _, v := range dlp {
		params := v.(map[string]any)
		if val, ok := params[names.AttrARN].(string); ok && val != "" {
			deadLetterConfig.Arn = aws.String(val)
		}
	}
	return deadLetterConfig
}

func expandAppSyncParameters(tfList []any) *types.AppSyncParameters {
	apiObject := &types.AppSyncParameters{}
	for _, tfMapRaw := range tfList {
		tfMap := tfMapRaw.(map[string]any)
		if v, ok := tfMap["graphql_operation"].(string); ok && v != "" {
			apiObject.GraphQLOperation = aws.String(v)
		}
	}
	return apiObject
}

func putTargetsError(apiObjects []types.PutTargetsResultEntry) error {
	var errs []error
	for _, apiObject := range apiObjects {
		errs = append(errs, fmt.Errorf("%s: %w", aws.ToString(apiObject.TargetId), putTargetError(apiObject)))
	}
	return errors.Join(errs...)
}

func putTargetError(apiObject types.PutTargetsResultEntry) error {
	return errs.APIError(aws.ToString(apiObject.ErrorCode), aws.ToString(apiObject.ErrorMessage))
}

func resourceTargetRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EventsClient(ctx)
	eventBusName := d.Get("event_bus_name").(string)
	target, err := findTargetByThreePartKey(ctx, conn, eventBusName, d.Get(names.AttrRule).(string), d.Get("target_id").(string))
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] EventBridge Target (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading EventBridge Target (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, target.Arn)
	d.Set("event_bus_name", eventBusName)
	d.Set(names.AttrForceDestroy, d.Get(names.AttrForceDestroy).(bool))
	d.Set("input", target.Input)
	d.Set("input_path", target.InputPath)
	d.Set(names.AttrRoleARN, target.RoleArn)
	d.Set("target_id", target.Id)
	if target.RunCommandParameters != nil {
		if err := d.Set("run_command_targets", flattenTargetRunParameters(target.RunCommandParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting run_command_targets: %s", err)
		}
	}
	if target.HttpParameters != nil {
		if err := d.Set("http_target", []any{flattenTargetHTTPParameters(target.HttpParameters)}); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting http_target: %s", err)
		}
	} else {
		d.Set("http_target", nil)
	}
	if target.RedshiftDataParameters != nil {
		if err := d.Set("redshift_target", flattenTargetRedshiftParameters(target.RedshiftDataParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting redshift_target: %s", err)
		}
	}
	if target.EcsParameters != nil {
		if err := d.Set("ecs_target", flattenTargetECSParameters(ctx, target.EcsParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting ecs_target: %s", err)
		}
	}
	if target.BatchParameters != nil {
		if err := d.Set("batch_target", flattenTargetBatchParameters(target.BatchParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting batch_target: %s", err)
		}
	}
	if target.KinesisParameters != nil {
		if err := d.Set("kinesis_target", flattenTargetKinesisParameters(target.KinesisParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting kinesis_target: %s", err)
		}
	}
	if target.SageMakerPipelineParameters != nil {
		if err := d.Set("sagemaker_pipeline_target", flattenTargetSageMakerPipelineParameters(target.SageMakerPipelineParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting sagemaker_pipeline_parameters: %s", err)
		}
	}
	if target.SqsParameters != nil {
		if err := d.Set("sqs_target", flattenTargetSQSParameters(target.SqsParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting sqs_target: %s", err)
		}
	}
	if target.InputTransformer != nil {
		if err := d.Set("input_transformer", flattenInputTransformer(target.InputTransformer)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting input_transformer: %s", err)
		}
	}
	if target.RetryPolicy != nil {
		if err := d.Set("retry_policy", flattenTargetRetryPolicy(target.RetryPolicy)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting retry_policy: %s", err)
		}
	}
	if target.DeadLetterConfig != nil {
		if err := d.Set("dead_letter_config", flattenTargetDeadLetterConfig(target.DeadLetterConfig)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting dead_letter_config: %s", err)
		}
	}
	if target.AppSyncParameters != nil {
		if err := d.Set("appsync_target", flattenAppSyncParameters(target.AppSyncParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting appsync_target: %s", err)
		}
	}
	return diags
}

func findTargetByThreePartKey(ctx context.Context, conn *eventbridge.Client, busName, ruleName, targetID string) (*types.Target, error) {
	input := &eventbridge.ListTargetsByRuleInput{Rule: aws.String(ruleName), Limit: aws.Int32(100)}
	if busName != "" {
		input.EventBusName = aws.String(busName)
	}
	return findTarget(ctx, conn, input, func(v *types.Target) bool {
		return targetID == aws.ToString(v.Id)
	})
}

func findTarget(ctx context.Context, conn *eventbridge.Client, input *eventbridge.ListTargetsByRuleInput, filter tfslices.Predicate[*types.Target]) (*types.Target, error) {
	output, err := findTargets(ctx, conn, input, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findTargets(ctx context.Context, conn *eventbridge.Client, input *eventbridge.ListTargetsByRuleInput, filter tfslices.Predicate[*types.Target]) ([]types.Target, error) {
	var output []types.Target
	err := listTargetsByRulePages(ctx, conn, input, func(page *eventbridge.ListTargetsByRuleOutput, lastPage bool) bool {
		if page == nil {
			return !lastPage
		}
		for _, v := range page.Targets {
			if filter(&v) {
				output = append(output, v)
			}
		}
		return !lastPage
	})
	if tfawserr.ErrCodeEquals(err, errCodeValidationException) || errs.IsA[*types.ResourceNotFoundException](err) || (err != nil && regexache.MustCompile(" not found$").MatchString(err.Error())) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	return output, nil
}

func listTargetsByRulePages(ctx context.Context, conn *eventbridge.Client, input *eventbridge.ListTargetsByRuleInput, fn func(*eventbridge.ListTargetsByRuleOutput, bool) bool, optFns ...func(*eventbridge.Options)) error {
	for {
		output, err := conn.ListTargetsByRule(ctx, input, optFns...)
		if err != nil {
			return smarterr.NewError(err)
		}
		lastPage := aws.ToString(output.NextToken) == ""
		if !fn(output, lastPage) || lastPage {
			break
		}
		input.NextToken = output.NextToken
	}
	return nil
}

func flattenTargetRunParameters(runCommand *types.RunCommandParameters) []map[string]any {
	result := make([]map[string]any, 0)
	for _, x := range runCommand.RunCommandTargets {
		config := make(map[string]any)
		config[names.AttrKey] = aws.ToString(x.Key)
		config[names.AttrValues] = x.Values
		result = append(result, config)
	}
	return result
}

func flattenTargetHTTPParameters(apiObject *types.HttpParameters) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.HeaderParameters; v != nil {
		tfMap["header_parameters"] = v
	}
	if v := apiObject.PathParameterValues; v != nil {
		tfMap["path_parameter_values"] = v
	}
	if v := apiObject.QueryStringParameters; v != nil {
		tfMap["query_string_parameters"] = v
	}
	return tfMap
}

func flattenTargetRedshiftParameters(redshiftParameters *types.RedshiftDataParameters) []map[string]any {
	config := make(map[string]any)
	if redshiftParameters == nil {
		return []map[string]any{config}
	}
	config[names.AttrDatabase] = aws.ToString(redshiftParameters.Database)
	config["db_user"] = aws.ToString(redshiftParameters.DbUser)
	config["secrets_manager_arn"] = aws.ToString(redshiftParameters.SecretManagerArn)
	config["sql"] = aws.ToString(redshiftParameters.Sql)
	config["statement_name"] = aws.ToString(redshiftParameters.StatementName)
	config["with_event"] = redshiftParameters.WithEvent
	result := []map[string]any{config}
	return result
}

func flattenTargetECSParameters(ctx context.Context, ecsParameters *types.EcsParameters) []map[string]any {
	config := make(map[string]any)
	if ecsParameters.Group != nil {
		config["group"] = aws.ToString(ecsParameters.Group)
	}
	config["launch_type"] = ecsParameters.LaunchType
	config[names.AttrNetworkConfiguration] = flattenTargetECSParametersNetworkConfiguration(ecsParameters.NetworkConfiguration)
	if ecsParameters.PlatformVersion != nil {
		config["platform_version"] = aws.ToString(ecsParameters.PlatformVersion)
	}
	config[names.AttrPropagateTags] = ecsParameters.PropagateTags
	if ecsParameters.PlacementConstraints != nil {
		config["placement_constraint"] = flattenTargetPlacementConstraints(ecsParameters.PlacementConstraints)
	}
	if ecsParameters.PlacementStrategy != nil {
		config["ordered_placement_strategy"] = flattenTargetPlacementStrategies(ecsParameters.PlacementStrategy)
	}
	if ecsParameters.CapacityProviderStrategy != nil {
		config[names.AttrCapacityProviderStrategy] = flattenTargetCapacityProviderStrategy(ecsParameters.CapacityProviderStrategy)
	}
	config[names.AttrTags] = keyValueTags(ctx, ecsParameters.Tags).IgnoreAWS().Map()
	config["enable_execute_command"] = ecsParameters.EnableExecuteCommand
	config["enable_ecs_managed_tags"] = ecsParameters.EnableECSManagedTags
	config["task_count"] = aws.ToInt32(ecsParameters.TaskCount)
	config["task_definition_arn"] = aws.ToString(ecsParameters.TaskDefinitionArn)
	result := []map[string]any{config}
	return result
}

func flattenTargetECSParametersNetworkConfiguration(nc *types.NetworkConfiguration) []any {
	if nc == nil {
		return nil
	}
	result := make(map[string]any)
	result[names.AttrSecurityGroups] = nc.AwsvpcConfiguration.SecurityGroups
	result[names.AttrSubnets] = nc.AwsvpcConfiguration.Subnets
	result["assign_public_ip"] = nc.AwsvpcConfiguration.AssignPublicIp == types.AssignPublicIpEnabled
	return []any{result}
}

func flattenTargetPlacementConstraints(pcs []types.PlacementConstraint) []map[string]any {
	if len(pcs) == 0 {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, pc := range pcs {
		c := make(map[string]any)
		c[names.AttrType] = pc.Type
		if pc.Expression != nil {
			c[names.AttrExpression] = aws.ToString(pc.Expression)
		}
		results = append(results, c)
	}
	return results
}

func flattenTargetPlacementStrategies(pcs []types.PlacementStrategy) []map[string]any {
	if len(pcs) == 0 {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, pc := range pcs {
		c := make(map[string]any)
		c[names.AttrType] = pc.Type
		if pc.Field != nil {
			c[names.AttrField] = aws.ToString(pc.Field)
		}
		results = append(results, c)
	}
	return results
}

func flattenTargetCapacityProviderStrategy(cps []types.CapacityProviderStrategyItem) []map[string]any {
	if cps == nil {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, cp := range cps {
		s := make(map[string]any)
		s["capacity_provider"] = aws.ToString(cp.CapacityProvider)
		s[names.AttrWeight] = cp.Weight
		s["base"] = cp.Base
		results = append(results, s)
	}
	return results
}

func flattenTargetBatchParameters(batchParameters *types.BatchParameters) []map[string]any {
	config := make(map[string]any)
	config["job_definition"] = aws.ToString(batchParameters.JobDefinition)
	config["job_name"] = aws.ToString(batchParameters.JobName)
	if batchParameters.ArrayProperties != nil {
		config["array_size"] = batchParameters.ArrayProperties.Size
	}
	if batchParameters.RetryStrategy != nil {
		config["job_attempts"] = batchParameters.RetryStrategy.Attempts
	}
	result := []map[string]any{config}
	return result
}

func flattenTargetKinesisParameters(kinesisParameters *types.KinesisParameters) []map[string]any {
	config := make(map[string]any)
	config["partition_key_path"] = aws.ToString(kinesisParameters.PartitionKeyPath)
	result := []map[string]any{config}
	return result
}

func flattenTargetSageMakerPipelineParameters(sageMakerParameters *types.SageMakerPipelineParameters) []map[string]any {
	config := make(map[string]any)
	config["pipeline_parameter_list"] = flattenTargetSageMakerPipelineParameter(sageMakerParameters.PipelineParameterList)
	result := []map[string]any{config}
	return result
}

func flattenTargetSageMakerPipelineParameter(pcs []types.SageMakerPipelineParameter) []map[string]any {
	if len(pcs) == 0 {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, pc := range pcs {
		c := make(map[string]any)
		c[names.AttrName] = aws.ToString(pc.Name)
		c[names.AttrValue] = aws.ToString(pc.Value)
		results = append(results, c)
	}
	return results
}

func flattenTargetSQSParameters(sqsParameters *types.SqsParameters) []map[string]any {
	config := make(map[string]any)
	config["message_group_id"] = aws.ToString(sqsParameters.MessageGroupId)
	result := []map[string]any{config}
	return result
}

func flattenInputTransformer(inputTransformer *types.InputTransformer) []map[string]any {
	config := make(map[string]any)
	config["input_template"] = aws.ToString(inputTransformer.InputTemplate)
	config["input_paths"] = inputTransformer.InputPathsMap
	result := []map[string]any{config}
	return result
}

func flattenTargetRetryPolicy(rp *types.RetryPolicy) []map[string]any {
	config := make(map[string]any)
	config["maximum_event_age_in_seconds"] = aws.ToInt32(rp.MaximumEventAgeInSeconds)
	config["maximum_retry_attempts"] = aws.ToInt32(rp.MaximumRetryAttempts)
	result := []map[string]any{config}
	return result
}

func flattenTargetDeadLetterConfig(dlc *types.DeadLetterConfig) []map[string]any {
	config := make(map[string]any)
	config[names.AttrARN] = aws.ToString(dlc.Arn)
	result := []map[string]any{config}
	return result
}

func flattenAppSyncParameters(apiObject *types.AppSyncParameters) []map[string]any {
	tfMap := make(map[string]any)
	tfMap["graphql_operation"] = aws.ToString(apiObject.GraphQLOperation)
	return []map[string]any{tfMap}
}

