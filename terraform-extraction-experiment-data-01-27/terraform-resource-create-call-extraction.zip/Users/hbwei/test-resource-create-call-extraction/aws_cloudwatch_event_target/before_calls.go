package events

import (
	"context"
	"errors"
	"fmt"
	"log"
	"math"
	"strings"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	inttypes "github.com/hashicorp/terraform-provider-aws/internal/types"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func targetCreateResourceID(eventBusName, ruleName, targetID string) string {
	var parts []string
	if eventBusName == "" || eventBusName == DefaultEventBusName {
		parts = []string{ruleName, targetID}
	} else {
		parts = []string{eventBusName, ruleName, targetID}
	}
	id := strings.Join(parts, targetResourceIDSeparator)
	return id
}

func expandPutTargetsInput(ctx context.Context, d *schema.ResourceData) *eventbridge.PutTargetsInput {
	target := types.Target{Arn: aws.String(d.Get(names.AttrARN).(string)), Id: aws.String(d.Get("target_id").(string))}
	if v, ok := d.GetOk("input"); ok {
		target.Input = aws.String(v.(string))
	}
	if v, ok := d.GetOk("input_path"); ok {
		target.InputPath = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrRoleARN); ok {
		target.RoleArn = aws.String(v.(string))
	}
	if v, ok := d.GetOk("run_command_targets"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.RunCommandParameters = expandTargetRunParameters(v.([]any))
	}
	if v, ok := d.GetOk("ecs_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.EcsParameters = expandTargetECSParameters(ctx, v.([]any))
	}
	if v, ok := d.GetOk("redshift_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.RedshiftDataParameters = expandTargetRedshiftParameters(v.([]any))
	}
	if v, ok := d.GetOk("http_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.HttpParameters = expandTargetHTTPParameters(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("batch_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.BatchParameters = expandTargetBatchParameters(v.([]any))
	}
	if v, ok := d.GetOk("kinesis_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.KinesisParameters = expandTargetKinesisParameters(v.([]any))
	}
	if v, ok := d.GetOk("sqs_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.SqsParameters = expandTargetSQSParameters(v.([]any))
	}
	if v, ok := d.GetOk("sagemaker_pipeline_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.SageMakerPipelineParameters = expandTargetSageMakerPipelineParameters(v.([]any))
	}
	if v, ok := d.GetOk("input_transformer"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.InputTransformer = expandTransformerParameters(v.([]any))
	}
	if v, ok := d.GetOk("retry_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.RetryPolicy = expandRetryPolicyParameters(v.([]any))
	}
	if v, ok := d.GetOk("dead_letter_config"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.DeadLetterConfig = expandDeadLetterParametersConfig(v.([]any))
	}
	if v, ok := d.GetOk("appsync_target"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		target.AppSyncParameters = expandAppSyncParameters(v.([]any))
	}
	input := &eventbridge.PutTargetsInput{Rule: aws.String(d.Get(names.AttrRule).(string)), Targets: []types.Target{target}}
	if v, ok := d.GetOk("event_bus_name"); ok {
		input.EventBusName = aws.String(v.(string))
	}
	return input
}

func expandTargetRunParameters(config []any) *types.RunCommandParameters {
	commands := make([]types.RunCommandTarget, 0)
	for _, c := range config {
		param := c.(map[string]any)
		command := types.RunCommandTarget{Key: aws.String(param[names.AttrKey].(string)), Values: flex.ExpandStringValueList(param[names.AttrValues].([]any))}
		commands = append(commands, command)
	}
	command := &types.RunCommandParameters{RunCommandTargets: commands}
	return command
}

func expandTargetECSParameters(ctx context.Context, tfList []any) *types.EcsParameters {
	ecsParameters := &types.EcsParameters{}
	for _, c := range tfList {
		tfMap := c.(map[string]any)
		tags := tftags.New(ctx, tfMap[names.AttrTags].(map[string]any))
		if v, ok := tfMap[names.AttrCapacityProviderStrategy].(*schema.Set); ok && v.Len() > 0 {
			ecsParameters.CapacityProviderStrategy = expandTargetCapacityProviderStrategy(v.List())
		}
		if v, ok := tfMap["group"].(string); ok && v != "" {
			ecsParameters.Group = aws.String(v)
		}
		if v, ok := tfMap["launch_type"].(string); ok && v != "" {
			ecsParameters.LaunchType = types.LaunchType(v)
		}
		if v, ok := tfMap[names.AttrNetworkConfiguration]; ok {
			ecsParameters.NetworkConfiguration = expandTargetECSParametersNetworkConfiguration(v.([]any))
		}
		if v, ok := tfMap["platform_version"].(string); ok && v != "" {
			ecsParameters.PlatformVersion = aws.String(v)
		}
		if v, ok := tfMap["placement_constraint"].(*schema.Set); ok && v.Len() > 0 {
			ecsParameters.PlacementConstraints = expandTargetPlacementConstraints(v.List())
		}
		if v, ok := tfMap["ordered_placement_strategy"]; ok {
			ecsParameters.PlacementStrategy = expandTargetPlacementStrategies(v.([]any))
		}
		if v, ok := tfMap[names.AttrPropagateTags].(string); ok && v != "" {
			ecsParameters.PropagateTags = types.PropagateTags(v)
		}
		if len(tags) > 0 {
			ecsParameters.Tags = svcTags(tags.IgnoreAWS())
		}
		ecsParameters.EnableExecuteCommand = tfMap["enable_execute_command"].(bool)
		ecsParameters.EnableECSManagedTags = tfMap["enable_ecs_managed_tags"].(bool)
		ecsParameters.TaskCount = aws.Int32(int32(tfMap["task_count"].(int)))
		ecsParameters.TaskDefinitionArn = aws.String(tfMap["task_definition_arn"].(string))
	}
	return ecsParameters
}

func expandTargetCapacityProviderStrategy(tfList []any) []types.CapacityProviderStrategyItem {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.CapacityProviderStrategyItem
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		cp := tfMapRaw.(map[string]any)
		apiObject := types.CapacityProviderStrategyItem{}
		if val, ok := cp["base"]; ok {
			apiObject.Base = int32(val.(int))
		}
		if val, ok := cp[names.AttrWeight]; ok {
			apiObject.Weight = int32(val.(int))
		}
		if val, ok := cp["capacity_provider"]; ok {
			apiObject.CapacityProvider = aws.String(val.(string))
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTargetECSParametersNetworkConfiguration(nc []any) *types.NetworkConfiguration {
	if len(nc) == 0 {
		return nil
	}
	awsVpcConfig := &types.AwsVpcConfiguration{}
	raw := nc[0].(map[string]any)
	if val, ok := raw[names.AttrSecurityGroups]; ok {
		awsVpcConfig.SecurityGroups = flex.ExpandStringValueSet(val.(*schema.Set))
	}
	awsVpcConfig.Subnets = flex.ExpandStringValueSet(raw[names.AttrSubnets].(*schema.Set))
	if val, ok := raw["assign_public_ip"].(bool); ok {
		awsVpcConfig.AssignPublicIp = types.AssignPublicIpDisabled
		if val {
			awsVpcConfig.AssignPublicIp = types.AssignPublicIpEnabled
		}
	}
	return &types.NetworkConfiguration{AwsvpcConfiguration: awsVpcConfig}
}

func expandTargetPlacementConstraints(tfList []any) []types.PlacementConstraint {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.PlacementConstraint
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		tfMap := tfMapRaw.(map[string]any)
		apiObject := types.PlacementConstraint{}
		if v, ok := tfMap[names.AttrExpression].(string); ok && v != "" {
			apiObject.Expression = aws.String(v)
		}
		if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
			apiObject.Type = types.PlacementConstraintType(v)
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTargetPlacementStrategies(tfList []any) []types.PlacementStrategy {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.PlacementStrategy
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		tfMap := tfMapRaw.(map[string]any)
		apiObject := types.PlacementStrategy{}
		if v, ok := tfMap[names.AttrField].(string); ok && v != "" {
			apiObject.Field = aws.String(v)
		}
		if v, ok := tfMap[names.AttrType].(string); ok && v != "" {
			apiObject.Type = types.PlacementStrategyType(v)
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTargetRedshiftParameters(config []any) *types.RedshiftDataParameters {
	redshiftParameters := &types.RedshiftDataParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		redshiftParameters.Database = aws.String(param[names.AttrDatabase].(string))
		redshiftParameters.Sql = aws.String(param["sql"].(string))
		if val, ok := param["with_event"].(bool); ok {
			redshiftParameters.WithEvent = val
		}
		if val, ok := param["statement_name"].(string); ok && val != "" {
			redshiftParameters.StatementName = aws.String(val)
		}
		if val, ok := param["secrets_manager_arn"].(string); ok && val != "" {
			redshiftParameters.SecretManagerArn = aws.String(val)
		}
		if val, ok := param["db_user"].(string); ok && val != "" {
			redshiftParameters.DbUser = aws.String(val)
		}
	}
	return redshiftParameters
}

func expandTargetHTTPParameters(tfMap map[string]any) *types.HttpParameters {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.HttpParameters{}
	if v, ok := tfMap["header_parameters"].(map[string]any); ok && len(v) > 0 {
		apiObject.HeaderParameters = flex.ExpandStringValueMap(v)
	}
	if v, ok := tfMap["path_parameter_values"].([]any); ok && len(v) > 0 {
		apiObject.PathParameterValues = flex.ExpandStringValueList(v)
	}
	if v, ok := tfMap["query_string_parameters"].(map[string]any); ok && len(v) > 0 {
		apiObject.QueryStringParameters = flex.ExpandStringValueMap(v)
	}
	return apiObject
}

func expandTargetBatchParameters(config []any) *types.BatchParameters {
	batchParameters := &types.BatchParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		batchParameters.JobDefinition = aws.String(param["job_definition"].(string))
		batchParameters.JobName = aws.String(param["job_name"].(string))
		if v, ok := param["array_size"].(int); ok && v > 1 && v <= 10000 {
			arrayProperties := &types.BatchArrayProperties{}
			arrayProperties.Size = int32(v)
			batchParameters.ArrayProperties = arrayProperties
		}
		if v, ok := param["job_attempts"].(int); ok && v > 0 && v <= 10 {
			retryStrategy := &types.BatchRetryStrategy{}
			retryStrategy.Attempts = int32(v)
			batchParameters.RetryStrategy = retryStrategy
		}
	}
	return batchParameters
}

func expandTargetKinesisParameters(config []any) *types.KinesisParameters {
	kinesisParameters := &types.KinesisParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		if v, ok := param["partition_key_path"].(string); ok && v != "" {
			kinesisParameters.PartitionKeyPath = aws.String(v)
		}
	}
	return kinesisParameters
}

func expandTargetSQSParameters(config []any) *types.SqsParameters {
	sqsParameters := &types.SqsParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		if v, ok := param["message_group_id"].(string); ok && v != "" {
			sqsParameters.MessageGroupId = aws.String(v)
		}
	}
	return sqsParameters
}

func expandTargetSageMakerPipelineParameters(config []any) *types.SageMakerPipelineParameters {
	sageMakerPipelineParameters := &types.SageMakerPipelineParameters{}
	for _, c := range config {
		param := c.(map[string]any)
		if v, ok := param["pipeline_parameter_list"].(*schema.Set); ok && v.Len() > 0 {
			sageMakerPipelineParameters.PipelineParameterList = expandTargetSageMakerPipelineParameterList(v.List())
		}
	}
	return sageMakerPipelineParameters
}

func expandTargetSageMakerPipelineParameterList(tfList []any) []types.SageMakerPipelineParameter {
	if len(tfList) == 0 {
		return nil
	}
	var result []types.SageMakerPipelineParameter
	for _, tfMapRaw := range tfList {
		if tfMapRaw == nil {
			continue
		}
		tfMap := tfMapRaw.(map[string]any)
		apiObject := types.SageMakerPipelineParameter{}
		if v, ok := tfMap[names.AttrName].(string); ok && v != "" {
			apiObject.Name = aws.String(v)
		}
		if v, ok := tfMap[names.AttrValue].(string); ok && v != "" {
			apiObject.Value = aws.String(v)
		}
		result = append(result, apiObject)
	}
	return result
}

func expandTransformerParameters(config []any) *types.InputTransformer {
	transformerParameters := &types.InputTransformer{}
	inputPathsMaps := map[string]string{}
	for _, c := range config {
		param := c.(map[string]any)
		inputPaths := param["input_paths"].(map[string]any)
		for k, v := range inputPaths {
			inputPathsMaps[k] = v.(string)
		}
		transformerParameters.InputTemplate = aws.String(param["input_template"].(string))
	}
	transformerParameters.InputPathsMap = inputPathsMaps
	return transformerParameters
}

func expandRetryPolicyParameters(rp []any) *types.RetryPolicy {
	retryPolicy := &types.RetryPolicy{}
	for _, v := range rp {
		params := v.(map[string]any)
		if val, ok := params["maximum_event_age_in_seconds"].(int); ok {
			retryPolicy.MaximumEventAgeInSeconds = aws.Int32(int32(val))
		}
		if val, ok := params["maximum_retry_attempts"].(int); ok {
			retryPolicy.MaximumRetryAttempts = aws.Int32(int32(val))
		}
	}
	return retryPolicy
}

func expandDeadLetterParametersConfig(dlp []any) *types.DeadLetterConfig {
	deadLetterConfig := &types.DeadLetterConfig{}
	for _, v := range dlp {
		params := v.(map[string]any)
		if val, ok := params[names.AttrARN].(string); ok && val != "" {
			deadLetterConfig.Arn = aws.String(val)
		}
	}
	return deadLetterConfig
}

func expandAppSyncParameters(tfList []any) *types.AppSyncParameters {
	apiObject := &types.AppSyncParameters{}
	for _, tfMapRaw := range tfList {
		tfMap := tfMapRaw.(map[string]any)
		if v, ok := tfMap["graphql_operation"].(string); ok && v != "" {
			apiObject.GraphQLOperation = aws.String(v)
		}
	}
	return apiObject
}

