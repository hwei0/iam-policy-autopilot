package events

import (
	"context"
	"errors"
	"fmt"
	"log"
	"math"
	"strings"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge"
	"github.com/aws/aws-sdk-go-v2/service/eventbridge/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	inttypes "github.com/hashicorp/terraform-provider-aws/internal/types"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func putTargetsError(apiObjects []types.PutTargetsResultEntry) error {
	var errs []error
	for _, apiObject := range apiObjects {
		errs = append(errs, fmt.Errorf("%s: %w", aws.ToString(apiObject.TargetId), putTargetError(apiObject)))
	}
	return errors.Join(errs...)
}

func putTargetError(apiObject types.PutTargetsResultEntry) error {
	return errs.APIError(aws.ToString(apiObject.ErrorCode), aws.ToString(apiObject.ErrorMessage))
}

func resourceTargetRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EventsClient(ctx)
	eventBusName := d.Get("event_bus_name").(string)
	target, err := findTargetByThreePartKey(ctx, conn, eventBusName, d.Get(names.AttrRule).(string), d.Get("target_id").(string))
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] EventBridge Target (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading EventBridge Target (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, target.Arn)
	d.Set("event_bus_name", eventBusName)
	d.Set(names.AttrForceDestroy, d.Get(names.AttrForceDestroy).(bool))
	d.Set("input", target.Input)
	d.Set("input_path", target.InputPath)
	d.Set(names.AttrRoleARN, target.RoleArn)
	d.Set("target_id", target.Id)
	if target.RunCommandParameters != nil {
		if err := d.Set("run_command_targets", flattenTargetRunParameters(target.RunCommandParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting run_command_targets: %s", err)
		}
	}
	if target.HttpParameters != nil {
		if err := d.Set("http_target", []any{flattenTargetHTTPParameters(target.HttpParameters)}); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting http_target: %s", err)
		}
	} else {
		d.Set("http_target", nil)
	}
	if target.RedshiftDataParameters != nil {
		if err := d.Set("redshift_target", flattenTargetRedshiftParameters(target.RedshiftDataParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting redshift_target: %s", err)
		}
	}
	if target.EcsParameters != nil {
		if err := d.Set("ecs_target", flattenTargetECSParameters(ctx, target.EcsParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting ecs_target: %s", err)
		}
	}
	if target.BatchParameters != nil {
		if err := d.Set("batch_target", flattenTargetBatchParameters(target.BatchParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting batch_target: %s", err)
		}
	}
	if target.KinesisParameters != nil {
		if err := d.Set("kinesis_target", flattenTargetKinesisParameters(target.KinesisParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting kinesis_target: %s", err)
		}
	}
	if target.SageMakerPipelineParameters != nil {
		if err := d.Set("sagemaker_pipeline_target", flattenTargetSageMakerPipelineParameters(target.SageMakerPipelineParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting sagemaker_pipeline_parameters: %s", err)
		}
	}
	if target.SqsParameters != nil {
		if err := d.Set("sqs_target", flattenTargetSQSParameters(target.SqsParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting sqs_target: %s", err)
		}
	}
	if target.InputTransformer != nil {
		if err := d.Set("input_transformer", flattenInputTransformer(target.InputTransformer)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting input_transformer: %s", err)
		}
	}
	if target.RetryPolicy != nil {
		if err := d.Set("retry_policy", flattenTargetRetryPolicy(target.RetryPolicy)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting retry_policy: %s", err)
		}
	}
	if target.DeadLetterConfig != nil {
		if err := d.Set("dead_letter_config", flattenTargetDeadLetterConfig(target.DeadLetterConfig)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting dead_letter_config: %s", err)
		}
	}
	if target.AppSyncParameters != nil {
		if err := d.Set("appsync_target", flattenAppSyncParameters(target.AppSyncParameters)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting appsync_target: %s", err)
		}
	}
	return diags
}

func findTargetByThreePartKey(ctx context.Context, conn *eventbridge.Client, busName, ruleName, targetID string) (*types.Target, error) {
	input := &eventbridge.ListTargetsByRuleInput{Rule: aws.String(ruleName), Limit: aws.Int32(100)}
	if busName != "" {
		input.EventBusName = aws.String(busName)
	}
	return findTarget(ctx, conn, input, func(v *types.Target) bool {
		return targetID == aws.ToString(v.Id)
	})
}

func findTarget(ctx context.Context, conn *eventbridge.Client, input *eventbridge.ListTargetsByRuleInput, filter tfslices.Predicate[*types.Target]) (*types.Target, error) {
	output, err := findTargets(ctx, conn, input, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findTargets(ctx context.Context, conn *eventbridge.Client, input *eventbridge.ListTargetsByRuleInput, filter tfslices.Predicate[*types.Target]) ([]types.Target, error) {
	var output []types.Target
	err := listTargetsByRulePages(ctx, conn, input, func(page *eventbridge.ListTargetsByRuleOutput, lastPage bool) bool {
		if page == nil {
			return !lastPage
		}
		for _, v := range page.Targets {
			if filter(&v) {
				output = append(output, v)
			}
		}
		return !lastPage
	})
	if tfawserr.ErrCodeEquals(err, errCodeValidationException) || errs.IsA[*types.ResourceNotFoundException](err) || (err != nil && regexache.MustCompile(" not found$").MatchString(err.Error())) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	return output, nil
}

func listTargetsByRulePages(ctx context.Context, conn *eventbridge.Client, input *eventbridge.ListTargetsByRuleInput, fn func(*eventbridge.ListTargetsByRuleOutput, bool) bool, optFns ...func(*eventbridge.Options)) error {
	for {
		output, err := conn.ListTargetsByRule(ctx, input, optFns...)
		if err != nil {
			return smarterr.NewError(err)
		}
		lastPage := aws.ToString(output.NextToken) == ""
		if !fn(output, lastPage) || lastPage {
			break
		}
		input.NextToken = output.NextToken
	}
	return nil
}

func flattenTargetRunParameters(runCommand *types.RunCommandParameters) []map[string]any {
	result := make([]map[string]any, 0)
	for _, x := range runCommand.RunCommandTargets {
		config := make(map[string]any)
		config[names.AttrKey] = aws.ToString(x.Key)
		config[names.AttrValues] = x.Values
		result = append(result, config)
	}
	return result
}

func flattenTargetHTTPParameters(apiObject *types.HttpParameters) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.HeaderParameters; v != nil {
		tfMap["header_parameters"] = v
	}
	if v := apiObject.PathParameterValues; v != nil {
		tfMap["path_parameter_values"] = v
	}
	if v := apiObject.QueryStringParameters; v != nil {
		tfMap["query_string_parameters"] = v
	}
	return tfMap
}

func flattenTargetRedshiftParameters(redshiftParameters *types.RedshiftDataParameters) []map[string]any {
	config := make(map[string]any)
	if redshiftParameters == nil {
		return []map[string]any{config}
	}
	config[names.AttrDatabase] = aws.ToString(redshiftParameters.Database)
	config["db_user"] = aws.ToString(redshiftParameters.DbUser)
	config["secrets_manager_arn"] = aws.ToString(redshiftParameters.SecretManagerArn)
	config["sql"] = aws.ToString(redshiftParameters.Sql)
	config["statement_name"] = aws.ToString(redshiftParameters.StatementName)
	config["with_event"] = redshiftParameters.WithEvent
	result := []map[string]any{config}
	return result
}

func flattenTargetECSParameters(ctx context.Context, ecsParameters *types.EcsParameters) []map[string]any {
	config := make(map[string]any)
	if ecsParameters.Group != nil {
		config["group"] = aws.ToString(ecsParameters.Group)
	}
	config["launch_type"] = ecsParameters.LaunchType
	config[names.AttrNetworkConfiguration] = flattenTargetECSParametersNetworkConfiguration(ecsParameters.NetworkConfiguration)
	if ecsParameters.PlatformVersion != nil {
		config["platform_version"] = aws.ToString(ecsParameters.PlatformVersion)
	}
	config[names.AttrPropagateTags] = ecsParameters.PropagateTags
	if ecsParameters.PlacementConstraints != nil {
		config["placement_constraint"] = flattenTargetPlacementConstraints(ecsParameters.PlacementConstraints)
	}
	if ecsParameters.PlacementStrategy != nil {
		config["ordered_placement_strategy"] = flattenTargetPlacementStrategies(ecsParameters.PlacementStrategy)
	}
	if ecsParameters.CapacityProviderStrategy != nil {
		config[names.AttrCapacityProviderStrategy] = flattenTargetCapacityProviderStrategy(ecsParameters.CapacityProviderStrategy)
	}
	config[names.AttrTags] = keyValueTags(ctx, ecsParameters.Tags).IgnoreAWS().Map()
	config["enable_execute_command"] = ecsParameters.EnableExecuteCommand
	config["enable_ecs_managed_tags"] = ecsParameters.EnableECSManagedTags
	config["task_count"] = aws.ToInt32(ecsParameters.TaskCount)
	config["task_definition_arn"] = aws.ToString(ecsParameters.TaskDefinitionArn)
	result := []map[string]any{config}
	return result
}

func flattenTargetECSParametersNetworkConfiguration(nc *types.NetworkConfiguration) []any {
	if nc == nil {
		return nil
	}
	result := make(map[string]any)
	result[names.AttrSecurityGroups] = nc.AwsvpcConfiguration.SecurityGroups
	result[names.AttrSubnets] = nc.AwsvpcConfiguration.Subnets
	result["assign_public_ip"] = nc.AwsvpcConfiguration.AssignPublicIp == types.AssignPublicIpEnabled
	return []any{result}
}

func flattenTargetPlacementConstraints(pcs []types.PlacementConstraint) []map[string]any {
	if len(pcs) == 0 {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, pc := range pcs {
		c := make(map[string]any)
		c[names.AttrType] = pc.Type
		if pc.Expression != nil {
			c[names.AttrExpression] = aws.ToString(pc.Expression)
		}
		results = append(results, c)
	}
	return results
}

func flattenTargetPlacementStrategies(pcs []types.PlacementStrategy) []map[string]any {
	if len(pcs) == 0 {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, pc := range pcs {
		c := make(map[string]any)
		c[names.AttrType] = pc.Type
		if pc.Field != nil {
			c[names.AttrField] = aws.ToString(pc.Field)
		}
		results = append(results, c)
	}
	return results
}

func flattenTargetCapacityProviderStrategy(cps []types.CapacityProviderStrategyItem) []map[string]any {
	if cps == nil {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, cp := range cps {
		s := make(map[string]any)
		s["capacity_provider"] = aws.ToString(cp.CapacityProvider)
		s[names.AttrWeight] = cp.Weight
		s["base"] = cp.Base
		results = append(results, s)
	}
	return results
}

func flattenTargetBatchParameters(batchParameters *types.BatchParameters) []map[string]any {
	config := make(map[string]any)
	config["job_definition"] = aws.ToString(batchParameters.JobDefinition)
	config["job_name"] = aws.ToString(batchParameters.JobName)
	if batchParameters.ArrayProperties != nil {
		config["array_size"] = batchParameters.ArrayProperties.Size
	}
	if batchParameters.RetryStrategy != nil {
		config["job_attempts"] = batchParameters.RetryStrategy.Attempts
	}
	result := []map[string]any{config}
	return result
}

func flattenTargetKinesisParameters(kinesisParameters *types.KinesisParameters) []map[string]any {
	config := make(map[string]any)
	config["partition_key_path"] = aws.ToString(kinesisParameters.PartitionKeyPath)
	result := []map[string]any{config}
	return result
}

func flattenTargetSageMakerPipelineParameters(sageMakerParameters *types.SageMakerPipelineParameters) []map[string]any {
	config := make(map[string]any)
	config["pipeline_parameter_list"] = flattenTargetSageMakerPipelineParameter(sageMakerParameters.PipelineParameterList)
	result := []map[string]any{config}
	return result
}

func flattenTargetSageMakerPipelineParameter(pcs []types.SageMakerPipelineParameter) []map[string]any {
	if len(pcs) == 0 {
		return nil
	}
	results := make([]map[string]any, 0)
	for _, pc := range pcs {
		c := make(map[string]any)
		c[names.AttrName] = aws.ToString(pc.Name)
		c[names.AttrValue] = aws.ToString(pc.Value)
		results = append(results, c)
	}
	return results
}

func flattenTargetSQSParameters(sqsParameters *types.SqsParameters) []map[string]any {
	config := make(map[string]any)
	config["message_group_id"] = aws.ToString(sqsParameters.MessageGroupId)
	result := []map[string]any{config}
	return result
}

func flattenInputTransformer(inputTransformer *types.InputTransformer) []map[string]any {
	config := make(map[string]any)
	config["input_template"] = aws.ToString(inputTransformer.InputTemplate)
	config["input_paths"] = inputTransformer.InputPathsMap
	result := []map[string]any{config}
	return result
}

func flattenTargetRetryPolicy(rp *types.RetryPolicy) []map[string]any {
	config := make(map[string]any)
	config["maximum_event_age_in_seconds"] = aws.ToInt32(rp.MaximumEventAgeInSeconds)
	config["maximum_retry_attempts"] = aws.ToInt32(rp.MaximumRetryAttempts)
	result := []map[string]any{config}
	return result
}

func flattenTargetDeadLetterConfig(dlc *types.DeadLetterConfig) []map[string]any {
	config := make(map[string]any)
	config[names.AttrARN] = aws.ToString(dlc.Arn)
	result := []map[string]any{config}
	return result
}

func flattenAppSyncParameters(apiObject *types.AppSyncParameters) []map[string]any {
	tfMap := make(map[string]any)
	tfMap["graphql_operation"] = aws.ToString(apiObject.GraphQLOperation)
	return []map[string]any{tfMap}
}

