package ec2

import (
	"context"
	"log"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	awstypes "github.com/aws/aws-sdk-go-v2/service/ec2/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceEgressOnlyInternetGatewayCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EC2Client(ctx)
	input := &ec2.CreateEgressOnlyInternetGatewayInput{ClientToken: aws.String(id.UniqueId()), TagSpecifications: getTagSpecificationsIn(ctx, awstypes.ResourceTypeEgressOnlyInternetGateway), VpcId: aws.String(d.Get(names.AttrVPCID).(string))}
	output, err := conn.CreateEgressOnlyInternetGateway(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating EC2 Egress-only Internet Gateway: %s", err)
	}
	d.SetId(aws.ToString(output.EgressOnlyInternetGateway.EgressOnlyInternetGatewayId))
	return append(diags, resourceEgressOnlyInternetGatewayRead(ctx, d, meta)...)
}

func (ipProtocolType) String() string {
	return "IPProtocolType"
}

func resourceEgressOnlyInternetGatewayRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EC2Client(ctx)
	ig, err := tfresource.RetryWhenNewResourceNotFound(ctx, ec2PropagationTimeout, func(ctx context.Context) (*awstypes.EgressOnlyInternetGateway, error) {
		return findEgressOnlyInternetGatewayByID(ctx, conn, d.Id())
	}, d.IsNewResource())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] EC2 Egress-only Internet Gateway %s not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading EC2 Egress-only Internet Gateway (%s): %s", d.Id(), err)
	}
	if len(ig.Attachments) == 1 && ig.Attachments[0].State == awstypes.AttachmentStatusAttached {
		d.Set(names.AttrVPCID, ig.Attachments[0].VpcId)
	} else {
		d.Set(names.AttrVPCID, nil)
	}
	setTagsOut(ctx, ig.Tags)
	return diags
}

func findEgressOnlyInternetGatewayByID(ctx context.Context, conn *ec2.Client, id string) (*awstypes.EgressOnlyInternetGateway, error) {
	input := ec2.DescribeEgressOnlyInternetGatewaysInput{EgressOnlyInternetGatewayIds: []string{id}}
	output, err := findEgressOnlyInternetGateway(ctx, conn, &input)
	if err != nil {
		return nil, err
	}
	if aws.ToString(output.EgressOnlyInternetGatewayId) != id {
		return nil, &retry.NotFoundError{LastRequest: &input}
	}
	return output, nil
}

func findEgressOnlyInternetGateway(ctx context.Context, conn *ec2.Client, input *ec2.DescribeEgressOnlyInternetGatewaysInput) (*awstypes.EgressOnlyInternetGateway, error) {
	output, err := findEgressOnlyInternetGateways(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findEgressOnlyInternetGateways(ctx context.Context, conn *ec2.Client, input *ec2.DescribeEgressOnlyInternetGatewaysInput) ([]awstypes.EgressOnlyInternetGateway, error) {
	var output []awstypes.EgressOnlyInternetGateway
	pages := ec2.NewDescribeEgressOnlyInternetGatewaysPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		output = append(output, page.EgressOnlyInternetGateways...)
	}
	return output, nil
}

func (p *describeVpcEncryptionControlsPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *describeVpcEncryptionControlsPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.DescribeVpcEncryptionControlsOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.DescribeVpcEncryptionControls(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next DescribeVpcEncryptionControls page.


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.GetVpcResourcesBlockingEncryptionEnforcementOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.GetVpcResourcesBlockingEncryptionEnforcement(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next GetVpcResourcesBlockingEncryptionEnforcement page.


