package iam

import (
	"context"
	"fmt"
	"log"
	"strings"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/iam"
	awstypes "github.com/aws/aws-sdk-go-v2/service/iam/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
)

func resourceUserGroupMembershipCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IAMClient(ctx)
	user := d.Get("user").(string)
	groupList := flex.ExpandStringValueSet(d.Get("groups").(*schema.Set))
	if err := addUserToGroups(ctx, conn, user, groupList); err != nil {
		return sdkdiag.AppendErrorf(diags, "assigning IAM User Group Membership (%s): %s", user, err)
	}
	d.SetId(id.UniqueId())
	return append(diags, resourceUserGroupMembershipRead(ctx, d, meta)...)
}

func addUserToGroups(ctx context.Context, conn *iam.Client, user string, groups []string) error {
	for _, group := range groups {
		if err := addUserToGroup(ctx, conn, user, group); err != nil {
			return err
		}
	}
	return nil
}

func addUserToGroup(ctx context.Context, conn *iam.Client, user, group string) error {
	_, err := conn.AddUserToGroup(ctx, &iam.AddUserToGroupInput{UserName: aws.String(user), GroupName: aws.String(group)})
	if err != nil {
		return fmt.Errorf("adding User (%s) to Group (%s): %w", user, group, err)
	}
	return nil
}

func resourceUserGroupMembershipRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IAMClient(ctx)
	user := d.Get("user").(string)
	groups := d.Get("groups").(*schema.Set)
	input := &iam.ListGroupsForUserInput{UserName: aws.String(user)}
	var gl []string
	err := tfresource.Retry(ctx, propagationTimeout, func(ctx context.Context) *tfresource.RetryError {
		err := listGroupsForUserPages(ctx, conn, input, func(page *iam.ListGroupsForUserOutput, lastPage bool) bool {
			if page == nil {
				return !lastPage
			}
			for _, group := range page.Groups {
				if groups.Contains(aws.ToString(group.GroupName)) {
					gl = append(gl, aws.ToString(group.GroupName))
				}
			}
			return !lastPage
		})
		if d.IsNewResource() && errs.IsA[*awstypes.NoSuchEntityException](err) {
			return tfresource.RetryableError(err)
		}
		if err != nil {
			return tfresource.NonRetryableError(err)
		}
		return nil
	})
	var nse *awstypes.NoSuchEntityException
	if !d.IsNewResource() && tfawserr.ErrCodeEquals(err, nse.ErrorCode()) {
		log.Printf("[WARN] IAM User Group Membership (%s) not found, removing from state", user)
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading IAM User Group Membership (%s): %s", user, err)
	}
	if err := d.Set("groups", gl); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting group list from IAM (%s), error: %s", user, err)
	}
	return diags
}

func listGroupsForUserPages(ctx context.Context, conn *iam.Client, input *iam.ListGroupsForUserInput, fn func(*iam.ListGroupsForUserOutput, bool) bool, optFns ...func(*iam.Options)) error {
	for {
		output, err := conn.ListGroupsForUser(ctx, input, optFns...)
		if err != nil {
			return smarterr.NewError(err)
		}
		lastPage := aws.ToString(output.Marker) == ""
		if !fn(output, lastPage) || lastPage {
			break
		}
		input.Marker = output.Marker
	}
	return nil
}

