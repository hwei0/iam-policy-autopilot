package lexmodels

import (
	"context"
	"fmt"
	"log"
	"slices"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/lexmodelbuildingservice"
	awstypes "github.com/aws/aws-sdk-go-v2/service/lexmodelbuildingservice/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/sdkv2"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func waitBotVersionCreated(ctx context.Context, conn *lexmodelbuildingservice.Client, name, version string, timeout time.Duration) (*lexmodelbuildingservice.GetBotOutput, error) {
	stateChangeConf := &retry.StateChangeConf{Pending: enum.Slice(awstypes.StatusBuilding), Target: enum.Slice(awstypes.StatusNotBuilt, awstypes.StatusReady, awstypes.StatusReadyBasicTesting), Refresh: statusBotVersion(ctx, conn, name, version), Timeout: timeout}
	outputRaw, err := stateChangeConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*lexmodelbuildingservice.GetBotOutput); ok {
		if output.Status == awstypes.StatusFailed {
			tfresource.SetLastError(err, errors.New(aws.ToString(output.FailureReason)))
		}
		return output, err
	}
	return nil, err
}

func statusBotVersion(ctx context.Context, conn *lexmodelbuildingservice.Client, name, version string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findBotVersionByName(ctx, conn, name, version)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return nil, "", err
		}
		return output, string(output.Status), nil
	}
}

func findBotVersionByName(ctx context.Context, conn *lexmodelbuildingservice.Client, name, version string) (*lexmodelbuildingservice.GetBotOutput, error) {
	input := &lexmodelbuildingservice.GetBotInput{Name: aws.String(name), VersionOrAlias: aws.String(version)}
	output, err := conn.GetBot(ctx, input)
	if errs.IsA[*awstypes.NotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func resourceBotRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).LexModelsClient(ctx)
	output, err := findBotVersionByName(ctx, conn, d.Id(), BotVersionLatest)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Lex Bot (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Lex Bot (%s): %s", d.Id(), err)
	}
	arn := arn.ARN{Partition: meta.(*conns.AWSClient).Partition(ctx), Region: meta.(*conns.AWSClient).Region(ctx), Service: "lex", AccountID: meta.(*conns.AWSClient).AccountID(ctx), Resource: fmt.Sprintf("bot:%s", d.Id())}
	d.Set(names.AttrARN, arn.String())
	processBehavior := awstypes.ProcessBehaviorSave
	if v, ok := d.GetOk("process_behavior"); ok {
		processBehavior = awstypes.ProcessBehavior(v.(string))
	}
	d.Set("checksum", output.Checksum)
	d.Set("child_directed", output.ChildDirected)
	d.Set(names.AttrCreatedDate, output.CreatedDate.Format(time.RFC3339))
	d.Set(names.AttrDescription, output.Description)
	d.Set("detect_sentiment", output.DetectSentiment)
	d.Set("enable_model_improvements", output.EnableModelImprovements)
	d.Set("failure_reason", output.FailureReason)
	d.Set("idle_session_ttl_in_seconds", output.IdleSessionTTLInSeconds)
	d.Set("intent", flattenIntents(output.Intents))
	d.Set(names.AttrLastUpdatedDate, output.LastUpdatedDate.Format(time.RFC3339))
	d.Set("locale", output.Locale)
	d.Set(names.AttrName, output.Name)
	d.Set("nlu_intent_confidence_threshold", output.NluIntentConfidenceThreshold)
	d.Set("process_behavior", processBehavior)
	d.Set(names.AttrStatus, output.Status)
	if output.AbortStatement != nil {
		d.Set("abort_statement", flattenStatement(output.AbortStatement))
	}
	if output.ClarificationPrompt != nil {
		d.Set("clarification_prompt", flattenPrompt(output.ClarificationPrompt))
	}
	version, err := findLatestBotVersionByName(ctx, conn, d.Id())
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Lex Bot (%s) latest version: %s", d.Id(), err)
	}
	d.Set(names.AttrVersion, version)
	d.Set("voice_id", output.VoiceId)
	return diags
}

func flattenIntents(intents []awstypes.Intent) (flattenedIntents []map[string]any) {
	for _, intent := range intents {
		flattenedIntents = append(flattenedIntents, map[string]any{"intent_name": aws.ToString(intent.IntentName), "intent_version": aws.ToString(intent.IntentVersion)})
	}
	return
}

func flattenStatement(statement *awstypes.Statement) (flattened []map[string]any) {
	flattened = []map[string]any{{names.AttrMessage: flattenMessages(statement.Messages)}}
	if statement.ResponseCard != nil {
		flattened[0]["response_card"] = aws.ToString(statement.ResponseCard)
	}
	return
}

func flattenMessages(messages []awstypes.Message) (flattenedMessages []map[string]any) {
	for _, message := range messages {
		flattenedMessages = append(flattenedMessages, map[string]any{names.AttrContent: aws.ToString(message.Content), names.AttrContentType: string(message.ContentType), "group_number": aws.ToInt32(message.GroupNumber)})
	}
	return
}

func flattenPrompt(prompt *awstypes.Prompt) (flattened []map[string]any) {
	flattened = []map[string]any{{"max_attempts": aws.ToInt32(prompt.MaxAttempts), names.AttrMessage: flattenMessages(prompt.Messages)}}
	if prompt.ResponseCard != nil {
		flattened[0]["response_card"] = aws.ToString(prompt.ResponseCard)
	}
	return
}

func findLatestBotVersionByName(ctx context.Context, conn *lexmodelbuildingservice.Client, name string) (string, error) {
	input := &lexmodelbuildingservice.GetBotVersionsInput{Name: aws.String(name)}
	var latestVersion int
	pages := lexmodelbuildingservice.NewGetBotVersionsPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if err != nil {
			return "", err
		}
		for _, bot := // findLatestBotVersionByName returns the latest published version of a bot or $LATEST if the bot has never been published.
		// See https://docs.aws.amazon.com/lex/latest/dg/versioning-aliases.html.
		range page.Bots {
			version := aws.ToString(bot.Version)
			if version == BotVersionLatest {
				continue
			}
			if version, err := strconv.Atoi(version); err != nil {
				continue
			} else if version > latestVersion {
				latestVersion = version
			}
		}
	}
	if latestVersion == 0 {
		return BotVersionLatest, nil
	}
	return strconv.Itoa(latestVersion), nil
}

