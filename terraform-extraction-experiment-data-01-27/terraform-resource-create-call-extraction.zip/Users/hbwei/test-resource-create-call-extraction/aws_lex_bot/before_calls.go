package lexmodels

import (
	"context"
	"fmt"
	"log"
	"slices"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/lexmodelbuildingservice"
	awstypes "github.com/aws/aws-sdk-go-v2/service/lexmodelbuildingservice/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/sdkv2"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandStatement(rawObject any) (statement *awstypes.Statement) {
	m := rawObject.([]any)[0].(map[string]any)
	statement = &awstypes.Statement{}
	statement.Messages = expandMessages(m[names.AttrMessage].(*schema.Set).List())
	if v, ok := m["response_card"]; ok && v != "" {
		statement.ResponseCard = aws.String(v.(string))
	}
	return
}

func expandMessages(rawValues [ // Expects a slice of maps representing the Lex objects.
// The value passed into this function should have been run through the expandLexSet function.
// Example: []map[content: test content_type: PlainText group_number: 1]
]any) []awstypes.Message {
	messages := make([]awstypes.Message, 0, len(rawValues))
	for _, rawValue := range rawValues {
		value, ok := rawValue.(map[string]any)
		if !ok {
			continue
		}
		message := awstypes.Message{Content: aws.String(value[names.AttrContent].(string)), ContentType: awstypes.ContentType(value[names.AttrContentType].(string))}
		if v, ok := value["group_number"]; ok && v != 0 {
			message.GroupNumber = aws.Int32(int32(v.(int)))
		}
		messages = append(messages, message)
	}
	return messages
}

func expandIntents(rawValues [ // Expects a slice of maps representing the Lex objects.
// The value passed into this function should have been run through the expandLexSet function.
// Example: []map[intent_name: OrderFlowers intent_version: $LATEST]
]any) []awstypes.Intent {
	intents := make([]awstypes.Intent, 0, len(rawValues))
	for _, rawValue := range rawValues {
		value, ok := rawValue.(map[string]any)
		if !ok {
			continue
		}
		intents = append(intents, awstypes.Intent{IntentName: aws.String(value["intent_name"].(string)), IntentVersion: aws.String(value["intent_version"].(string))})
	}
	return intents
}

func expandPrompt(rawObject any) (prompt *awstypes.Prompt) {
	m := rawObject.([]any)[0].(map[string]any)
	prompt = &awstypes.Prompt{}
	prompt.MaxAttempts = aws.Int32(int32(m["max_attempts"].(int)))
	prompt.Messages = expandMessages(m[names.AttrMessage].(*schema.Set).List())
	if v, ok := m["response_card"]; ok && v != "" {
		prompt.ResponseCard = aws.String(v.(string))
	}
	return
}

