package lexmodels

import (
	"context"
	"fmt"
	"log"
	"slices"
	"time"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/arn"
	"github.com/aws/aws-sdk-go-v2/service/lexmodelbuildingservice"
	awstypes "github.com/aws/aws-sdk-go-v2/service/lexmodelbuildingservice/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/sdkv2"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceBotCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).LexModelsClient(ctx)
	name := d.Get(names.AttrName).(string)
	input := &lexmodelbuildingservice.PutBotInput{AbortStatement: expandStatement(d.Get("abort_statement")), ChildDirected: aws.Bool(d.Get("child_directed").(bool)), CreateVersion: aws.Bool(d.Get("create_version").(bool)), Description: aws.String(d.Get(names.AttrDescription).(string)), EnableModelImprovements: aws.Bool(d.Get("enable_model_improvements").(bool)), IdleSessionTTLInSeconds: aws.Int32(int32(d.Get("idle_session_ttl_in_seconds").(int))), Intents: expandIntents(d.Get("intent").(*schema.Set).List()), Name: aws.String(name)}
	if v, ok := d.GetOk("clarification_prompt"); ok {
		input.ClarificationPrompt = expandPrompt(v)
	}
	if v, ok := d.GetOk("locale"); ok {
		input.Locale = awstypes.Locale(v.(string))
	}
	if v, ok := d.GetOk("process_behavior"); ok {
		input.ProcessBehavior = awstypes.ProcessBehavior(v.(string))
	}
	if v, ok := d.GetOk("voice_id"); ok {
		input.VoiceId = aws.String(v.(string))
	}
	var output *lexmodelbuildingservice.PutBotOutput
	_, err := tfresource.RetryWhenIsA[any, *awstypes.ConflictException](ctx, d.Timeout(schema.TimeoutCreate), func(ctx context.Context) (any, error) {
		var err error
		if output != nil {
			input.Checksum = output.Checksum
		}
		output, err = conn.PutBot(ctx, input)
		return output, err
	})
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Lex Bot (%s): %s", name, err)
	}
	d.SetId(aws.ToString(output.Name))
	if _, err := waitBotVersionCreated(ctx, conn, name, BotVersionLatest, d.Timeout(schema.TimeoutCreate)); err != nil {
		return sdkdiag.AppendErrorf(diags, "waiting for Lex Bot (%s) create: %s", d.Id(), err)
	}
	return append(diags, resourceBotRead(ctx, d, meta)...)
}

