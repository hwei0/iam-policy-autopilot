package iot

import (
	"context"
	"log"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/iot"
	awstypes "github.com/aws/aws-sdk-go-v2/service/iot/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceThingTypeCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IoTClient(ctx)
	name := d.Get(names.AttrName).(string)
	input := &iot.CreateThingTypeInput{Tags: getTagsIn(ctx), ThingTypeName: aws.String(name)}
	if v, ok := d.GetOk(names.AttrProperties); ok {
		configs := v.([]any)
		if config, ok := configs[0].(map[string]any); ok && config != nil {
			input.ThingTypeProperties = expandThingTypeProperties(config)
		}
	}
	out, err := conn.CreateThingType(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating IoT Thing Type (%s): %s", name, err)
	}
	d.SetId(aws.ToString(out.ThingTypeName))
	if v := d.Get("deprecated").(bool); v {
		input := &iot.DeprecateThingTypeInput{ThingTypeName: aws.String(d.Id()), UndoDeprecate: false}
		_, err := conn.DeprecateThingType(ctx, input)
		if err != nil {
			return sdkdiag.AppendErrorf(diags, "deprecating IoT Thing Type (%s): %s", d.Id(), err)
		}
	}
	return append(diags, resourceThingTypeRead(ctx, d, meta)...)
}

func expandThingTypeProperties(config map[string]any) *awstypes.ThingTypeProperties {
	properties := &awstypes.ThingTypeProperties{SearchableAttributes: flex.ExpandStringValueSet(config["searchable_attributes"].(*schema.Set))}
	if v, ok := config[names.AttrDescription]; ok && v.(string) != "" {
		properties.ThingTypeDescription = aws.String(v.(string))
	}
	return properties
}

func resourceThingTypeRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).IoTClient(ctx)
	output, err := findThingTypeByName(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] IoT Thing Type (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading IoT Thing Type (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, output.ThingTypeArn)
	if output.ThingTypeMetadata != nil {
		d.Set("deprecated", output.ThingTypeMetadata.Deprecated)
	}
	if err := d.Set(names.AttrProperties, flattenThingTypeProperties(output.ThingTypeProperties)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting properties: %s", err)
	}
	return diags
}

func findThingTypeByName(ctx context.Context, conn *iot.Client, name string) (*iot.DescribeThingTypeOutput, error) {
	input := &iot.DescribeThingTypeInput{ThingTypeName: aws.String(name)}
	output, err := conn.DescribeThingType(ctx, input)
	if errs.IsA[*awstypes.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func flattenThingTypeProperties(s *awstypes.ThingTypeProperties) []map[string]any {
	m := map[string]any{names.AttrDescription: "", "searchable_attributes": flex.FlattenStringSet(nil)}
	if s == nil {
		return []map[string]any{m}
	}
	m[names.AttrDescription] = aws.ToString(s.ThingTypeDescription)
	m["searchable_attributes"] = s.SearchableAttributes
	return []map[string]any{m}
}

