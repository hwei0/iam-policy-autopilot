package lambda

import (
	"context"
	"crypto/md5"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strings"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/lambda"
	awstypes "github.com/aws/aws-sdk-go-v2/service/lambda/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/customdiff"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceInvocationCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).LambdaClient(ctx)
	return append(diags, invoke(ctx, conn, d, invocationActionCreate)...)
}

func invoke(ctx context.Context, conn *lambda.Client, d *schema.ResourceData, action invocationAction) diag.Diagnostics {
	var diags diag.Diagnostics
	functionName := d.Get("function_name").(string)
	qualifier := d.Get("qualifier").(string)
	payload, err := buildInput(d, action)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "Lambda Invocation (%s) input transformation failed for input (%s): %s", d.Id(), d.Get("input").(string), err)
	}
	input := &lambda.InvokeInput{FunctionName: aws.String(functionName), InvocationType: awstypes.InvocationTypeRequestResponse, Payload: payload, Qualifier: aws.String(qualifier)}
	if v, ok := d.GetOk("tenant_id"); ok {
		input.TenantId = aws.String(v.(string))
	}
	output, err := conn.Invoke(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "invoking Lambda Function (%s): %s", functionName, err)
	}
	if output.FunctionError != nil {
		return sdkdiag.AppendErrorf(diags, "invoking Lambda Function (%s): %s", functionName, string(output.Payload))
	}
	resultHash := fmt.Sprintf("%x", md5.Sum(payload))
	id, err := flex.FlattenResourceId([]string{functionName, qualifier, resultHash}, invocationResourceIDPartCount, false)
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	d.SetId(id)
	d.Set("result", string(output.Payload))
	return diags
}

func buildInput(d *schema.ResourceData, action invocationAction) ([ // buildInput makes sure that the user provided input is enriched for handling lifecycle events
//
// In order to make this a non-breaking change this function only manipulates input if
// the invocation is not only for creation of resources. In order for the lambda
// to understand the action it has to take we pass on the action that terraform wants to do
// on the invocation resource.
//
// Because Lambda functions by default are stateless we must pass the input from the previous
// invocation to allow implementation of delete/update at Lambda side.
]byte, error) {
	if isCreateOnlyScope(d) {
		jsonBytes := []byte(d.Get("input").(string))
		return jsonBytes, nil
	}
	oldInputMap, newInputMap, err := getInputChange(d)
	if err != nil {
		log.Printf("[DEBUG] input serialization %s", err)
		return nil, err
	}
	newInputMap[d.Get("terraform_key").(string)] = map[string]any{names.AttrAction: action, "prev_input": oldInputMap}
	return json.Marshal(&newInputMap)
}

func isCreateOnlyScope(d *schema.ResourceData) bool {
	return lifecycleScope(d.Get("lifecycle_scope").(string)) == lifecycleScopeCreateOnly
}// isCreateOnlyScope returns True if Lambda is only invoked when the resource is
// created or replaced.
//
// The original invocation logic only triggers on create.


func getInputChange(d *schema.ResourceData) (map // getInputChange gets old an new input as maps
[string]any, map[string]any, error) {
	old, new := d.GetChange("input")
	oldMap, err := getObjectFromJSONString(old.(string))
	if err != nil {
		log.Printf("[ERROR] old input serialization '%s'", old.(string))
		return nil, nil, err
	}
	newMap, err := getObjectFromJSONString(new.(string))
	if err != nil {
		log.Printf("[ERROR] new input serialization '%s'", new.(string))
		return nil, nil, err
	}
	return oldMap, newMap, nil
}

func getObjectFromJSONString(s string) (map[string]any, error) {
	if len(s) == 0 {
		return nil, nil
	}
	var mapObject map[string]any
	if err := json.Unmarshal([]byte(s), &mapObject); err != nil {
		log.Printf("[ERROR] input JSON deserialization '%s'", s)
		return nil, err
	}
	return mapObject, nil
}

func (a *invokeAction) Invoke(ctx context.Context, req action.InvokeRequest, resp *action.InvokeResponse) {
	var config invokeActionModel
	resp.Diagnostics.Append(req.Config.Get(ctx, &config)...)
	if resp.Diagnostics.HasError() {
		return
	}
	conn := a.Meta().LambdaClient(ctx)
	functionName := config.FunctionName.ValueString()
	payload := config.Payload.ValueString()
	invocationType := awstypes.InvocationTypeRequestResponse
	if !config.InvocationType.IsNull() && !config.InvocationType.IsUnknown() {
		invocationType = config.InvocationType.ValueEnum()
	}
	logType := awstypes.LogTypeNone
	if !config.LogType.IsNull() && !config.LogType.IsUnknown() {
		logType = config.LogType.ValueEnum()
	}
	tflog.Info(ctx, "Starting Lambda function invocation action", map[string]any{"function_name": functionName, "invocation_type": string(invocationType), "log_type": string(logType), "payload_length": len(payload), "has_qualifier": !config.Qualifier.IsNull(), "has_client_context": !config.ClientContext.IsNull()})
	resp.SendProgress(action.InvokeProgressEvent{Message: fmt.Sprintf("Invoking Lambda function %s...", functionName)})
	input := &lambda.InvokeInput{FunctionName: aws.String(functionName), Payload: []byte(payload), InvocationType: invocationType, LogType: logType}
	if !config.Qualifier.IsNull() {
		input.Qualifier = config.Qualifier.ValueStringPointer()
	}
	if !config.TenantId.IsNull() {
		input.TenantId = config.TenantId.ValueStringPointer()
	}
	if !config.ClientContext.IsNull() {
		clientContext := config.ClientContext.ValueString()
		if _, err := base64.StdEncoding.DecodeString(clientContext); err != nil {
			resp.Diagnostics.AddError("Invalid Client Context", fmt.Sprintf("Client context must be base64 encoded: %s", err))
			return
		}
		input.ClientContext = aws.String(clientContext)
	}
	output, err := conn.Invoke(ctx, input)
	if err != nil {
		resp.Diagnostics.AddError("Failed to Invoke Lambda Function", fmt.Sprintf("Could not invoke Lambda function %s: %s", functionName, err))
		return
	}
	if output.FunctionError != nil {
		functionError := aws.ToString(output.FunctionError)
		payloadStr := string(output.Payload)
		resp.Diagnostics.AddError("Lambda Function Execution Error", fmt.Sprintf("Lambda function %s returned an error (%s): %s", functionName, functionError, payloadStr))
		return
	}
	switch invocationType {
	case awstypes.InvocationTypeRequestResponse:
		a.handleSyncInvocation(resp, functionName, output, logType)
	case awstypes.InvocationTypeEvent:
		statusCode := output.StatusCode
		resp.SendProgress(action.InvokeProgressEvent{Message: fmt.Sprintf("Lambda function %s invoked asynchronously (status: %d)", functionName, statusCode)})
	case awstypes.InvocationTypeDryRun:
		statusCode := output.StatusCode
		resp.SendProgress(action.InvokeProgressEvent{Message: fmt.Sprintf("Lambda function %s dry run completed successfully (status: %d)", functionName, statusCode)})
	}
	tflog.Info(ctx, "Lambda function invocation action completed successfully", map[string]any{"function_name": functionName, "invocation_type": string(invocationType), names.AttrStatusCode: output.StatusCode, "executed_version": aws.ToString(output.ExecutedVersion), "has_logs": output.LogResult != nil, "payload_length": len(output.Payload)})
}

func (a *invokeAction) handleSyncInvocation(resp *action.InvokeResponse, functionName string, output *lambda.InvokeOutput, logType awstypes.LogType) {
	statusCode := output.StatusCode
	payloadLength := len(output.Payload)
	resp.SendProgress(action.InvokeProgressEvent{Message: fmt.Sprintf("Lambda function %s invoked successfully (status: %d, payload: %d bytes)", functionName, statusCode, payloadLength)})
	if logType != awstypes.LogTypeTail || output.LogResult == nil {
		return
	}
	logData, err := base64.StdEncoding.DecodeString(aws.ToString(output.LogResult))
	if err != nil {
		resp.SendProgress(action.InvokeProgressEvent{Message: fmt.Sprintf("Failed to decode Lambda logs: %s", err)})
		return
	}
	resp.SendProgress(action.InvokeProgressEvent{Message: fmt.Sprintf("Lambda function logs:\n%s", string(logData))})
}

