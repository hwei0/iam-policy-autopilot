package apigateway

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/apigateway"
	"github.com/aws/aws-sdk-go-v2/service/apigateway/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/structure"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceDomainNameCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).APIGatewayClient(ctx)
	domainName := d.Get(names.AttrDomainName).(string)
	input := apigateway.CreateDomainNameInput{DomainName: aws.String(domainName), MutualTlsAuthentication: expandMutualTLSAuthentication(d.Get("mutual_tls_authentication").([]any)), Tags: getTagsIn(ctx)}
	if v, ok := d.GetOk(names.AttrCertificateARN); ok {
		input.CertificateArn = aws.String(v.(string))
	}
	if v, ok := d.GetOk("certificate_body"); ok {
		input.CertificateBody = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrCertificateChain); ok {
		input.CertificateChain = aws.String(v.(string))
	}
	if v, ok := d.GetOk("certificate_name"); ok {
		input.CertificateName = aws.String(v.(string))
	}
	if v, ok := d.GetOk("certificate_private_key"); ok {
		input.CertificatePrivateKey = aws.String(v.(string))
	}
	if v, ok := d.GetOk("endpoint_configuration"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input.EndpointConfiguration = expandEndpointConfiguration(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("ownership_verification_certificate_arn"); ok {
		input.OwnershipVerificationCertificateArn = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrPolicy); ok {
		input.Policy = aws.String(v.(string))
	}
	if v, ok := d.GetOk("regional_certificate_arn"); ok {
		input.RegionalCertificateArn = aws.String(v.(string))
	}
	if v, ok := d.GetOk("regional_certificate_name"); ok {
		input.RegionalCertificateName = aws.String(v.(string))
	}
	if v, ok := d.GetOk("security_policy"); ok {
		input.SecurityPolicy = types.SecurityPolicy(v.(string))
	}
	output, err := conn.CreateDomainName(ctx, &input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating API Gateway Domain Name (%s): %s", domainName, err)
	}
	d.SetId(domainNameCreateResourceID(aws.ToString(output.DomainName), aws.ToString(output.DomainNameId)))
	return append(diags, resourceDomainNameRead(ctx, d, meta)...)
}

func expandMutualTLSAuthentication(tfList []any) *types.MutualTlsAuthenticationInput {
	if len(tfList) == 0 || tfList[0] == nil {
		return nil
	}
	tfMap := tfList[0].(map[string]any)
	apiObject := &types.MutualTlsAuthenticationInput{}
	if v, ok := tfMap["truststore_uri"].(string); ok && v != "" {
		apiObject.TruststoreUri = aws.String(v)
	}
	if v, ok := tfMap["truststore_version"].(string); ok && v != "" {
		apiObject.TruststoreVersion = aws.String(v)
	}
	return apiObject
}

func expandEndpointConfiguration(tfMap map[string]any) *types.EndpointConfiguration {
	if tfMap == nil {
		return nil
	}
	apiObject := &types.EndpointConfiguration{Types: flex.ExpandStringyValueList[types.EndpointType](tfMap["types"].([]any))}
	if v, ok := tfMap[names.AttrIPAddressType].(string); ok && v != "" {
		apiObject.IpAddressType = types.IpAddressType(v)
	}
	if v, ok := tfMap["vpc_endpoint_ids"].(*schema.Set); ok && v.Len() > 0 {
		apiObject.VpcEndpointIds = flex.ExpandStringValueSet(v)
	}
	return apiObject
}

func domainNameCreateResourceID(domainName, domainNameID string) string {
	var id string
	if domainNameID == "" {
		id = domainName
	} else {
		parts := []string{domainName, domainNameID}
		id = strings.Join(parts, domainNameResourceIDSeparator)
	}
	return id
}

func resourceDomainNameRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	c := meta.(*conns.AWSClient)
	conn := c.APIGatewayClient(ctx)
	domainName, domainNameID, err := domainNameParseResourceID(d.Id())
	if err != nil {
		return sdkdiag.AppendFromErr(diags, err)
	}
	output, err := findDomainNameByTwoPartKey(ctx, conn, domainName, domainNameID)
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] API Gateway Domain Name (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading API Gateway Domain Name (%s): %s", d.Id(), err)
	}
	if output.DomainNameArn != nil {
		d.Set(names.AttrARN, output.DomainNameArn)
	} else {
		d.Set(names.AttrARN, domainNameARN(ctx, c, d.Id()))
	}
	d.Set(names.AttrCertificateARN, output.CertificateArn)
	d.Set("certificate_name", output.CertificateName)
	if output.CertificateUploadDate != nil {
		d.Set("certificate_upload_date", output.CertificateUploadDate.Format(time.RFC3339))
	} else {
		d.Set("certificate_upload_date", nil)
	}
	d.Set("cloudfront_domain_name", output.DistributionDomainName)
	d.Set("cloudfront_zone_id", c.CloudFrontDistributionHostedZoneID(ctx))
	d.Set(names.AttrDomainName, output.DomainName)
	d.Set("domain_name_id", output.DomainNameId)
	if err := d.Set("endpoint_configuration", flattenEndpointConfiguration(output.EndpointConfiguration)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting endpoint_configuration: %s", err)
	}
	if err = d.Set("mutual_tls_authentication", flattenMutualTLSAuthentication(output.MutualTlsAuthentication)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting mutual_tls_authentication: %s", err)
	}
	d.Set("ownership_verification_certificate_arn", output.OwnershipVerificationCertificateArn)
	d.Set(names.AttrPolicy, output.Policy)
	d.Set("regional_certificate_arn", output.RegionalCertificateArn)
	d.Set("regional_certificate_name", output.RegionalCertificateName)
	d.Set("regional_domain_name", output.RegionalDomainName)
	d.Set("regional_zone_id", output.RegionalHostedZoneId)
	d.Set("security_policy", output.SecurityPolicy)
	setTagsOut(ctx, output.Tags)
	return diags
}

func domainNameParseResourceID(id string) (string, string, error) {
	switch parts := strings.SplitN(id, domainNameResourceIDSeparator, 2); len(parts) {
	case 1:
		if domainName := parts[0]; domainName != "" {
			return domainName, "", nil
		}
	case 2:
		if domainName, domainNameID := parts[0], parts[1]; domainName != "" && domainNameID != "" {
			return domainName, domainNameID, nil
		}
	}
	return "", "", fmt.Errorf("unexpected format for ID (%[1]s), expected DOMAIN-NAME or DOMAIN-NAME%[2]sDOMAIN-NAME-ID", id, domainNameResourceIDSeparator)
}

func findDomainNameByTwoPartKey(ctx context.Context, conn *apigateway.Client, domainName, domainNameID string) (*apigateway.GetDomainNameOutput, error) {
	input := apigateway.GetDomainNameInput{DomainName: aws.String(domainName)}
	if domainNameID != "" {
		input.DomainNameId = aws.String(domainNameID)
	}
	output, err := conn.GetDomainName(ctx, &input)
	if errs.IsA[*types.NotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func domainNameARN(ctx context.Context, c *conns.AWSClient, domainName string) string {
	return c.RegionalARNNoAccount(ctx, "apigateway", fmt.Sprintf("/domainnames/%s", domainName))
}

func flattenEndpointConfiguration(apiObject *types.EndpointConfiguration) []any {
	if apiObject == nil {
		return []any{}
	}
	tfMap := map[string]any{names.AttrIPAddressType: apiObject.IpAddressType, "types": apiObject.Types}
	if len(apiObject.VpcEndpointIds) > 0 {
		tfMap["vpc_endpoint_ids"] = apiObject.VpcEndpointIds
	}
	return []any{tfMap}
}

func flattenMutualTLSAuthentication(apiObject *types.MutualTlsAuthentication) []any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.TruststoreUri; v != nil {
		tfMap["truststore_uri"] = aws.ToString(v)
	}
	if v := apiObject.TruststoreVersion; v != nil {
		tfMap["truststore_version"] = aws.ToString(v)
	}
	return []any{tfMap}
}

