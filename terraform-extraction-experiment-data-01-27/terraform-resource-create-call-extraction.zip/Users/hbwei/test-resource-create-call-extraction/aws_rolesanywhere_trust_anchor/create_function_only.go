package rolesanywhere

import (
	"context"
	"fmt"
	"log"
	"reflect"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rolesanywhere"
	awstypes "github.com/aws/aws-sdk-go-v2/service/rolesanywhere/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceTrustAnchorCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).RolesAnywhereClient(ctx)
	name := d.Get(names.AttrName).(string)
	input := &rolesanywhere.CreateTrustAnchorInput{Enabled: aws.Bool(d.Get(names.AttrEnabled).(bool)), Name: aws.String(name), Source: expandSource(d.Get(names.AttrSource).([]any)), Tags: getTagsIn(ctx)}
	if v, ok := d.GetOk("notification_settings"); ok && v.(*schema.Set).Len() > 0 {
		input.NotificationSettings = expandNotificationSettings(v.(*schema.Set).List())
	}
	log.Printf("[DEBUG] Creating RolesAnywhere Trust Anchor (%s): %#v", d.Id(), input)
	output, err := conn.CreateTrustAnchor(ctx, input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating RolesAnywhere Trust Anchor (%s): %s", name, err)
	}
	d.SetId(aws.ToString(output.TrustAnchor.TrustAnchorId))
	return append(diags, resourceTrustAnchorRead(ctx, d, meta)...)
}

