package rolesanywhere

import (
	"context"
	"fmt"
	"log"
	"reflect"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rolesanywhere"
	awstypes "github.com/aws/aws-sdk-go-v2/service/rolesanywhere/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceTrustAnchorRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).RolesAnywhereClient(ctx)
	trustAnchor, err := findTrustAnchorByID(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] RolesAnywhere Trust Anchor (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading RolesAnywhere Trust Anchor (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrARN, trustAnchor.TrustAnchorArn)
	d.Set(names.AttrEnabled, trustAnchor.Enabled)
	d.Set(names.AttrName, trustAnchor.Name)
	if err := d.Set("notification_settings", flattenNotificationSettings(trustAnchor.NotificationSettings)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting source: %s", err)
	}
	if err := d.Set(names.AttrSource, flattenSource(trustAnchor.Source)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting source: %s", err)
	}
	return diags
}

func findTrustAnchorByID(ctx context.Context, conn *rolesanywhere.Client, id string) (*awstypes.TrustAnchorDetail, error) {
	in := &rolesanywhere.GetTrustAnchorInput{TrustAnchorId: aws.String(id)}
	out, err := conn.GetTrustAnchor(ctx, in)
	if errs.IsA[*awstypes.ResourceNotFoundException](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: in}
	}
	if err != nil {
		return nil, err
	}
	if out == nil || out.TrustAnchor == nil {
		return nil, tfresource.NewEmptyResultError(in)
	}
	return out.TrustAnchor, nil
}

func flattenNotificationSettings(apiObjects []awstypes.NotificationSettingDetail) []map[string]any {
	if len(apiObjects) == 0 {
		return nil
	}
	var tfList []map[string]any
	for _, apiObject := range apiObjects {
		tfList = append(tfList, flattenNotificationSetting(&apiObject))
	}
	return tfList
}

func flattenNotificationSetting(apiObject *awstypes.NotificationSettingDetail) map[string]any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{"channel": apiObject.Channel, "event": apiObject.Event}
	if v := apiObject.ConfiguredBy; v != nil {
		tfMap["configured_by"] = aws.ToString(v)
	}
	if v := apiObject.Enabled; v != nil {
		tfMap[names.AttrEnabled] = aws.ToBool(v)
	}
	if v := apiObject.Threshold; v != nil {
		tfMap["threshold"] = aws.ToInt32(v)
	}
	return tfMap
}

func flattenSource(apiObject *awstypes.Source) []any {
	if apiObject == nil {
		return nil
	}
	m := map[string]any{}
	m[names.AttrSourceType] = apiObject.SourceType
	m["source_data"] = flattenSourceData(apiObject.SourceData)
	return []any{m}
}

func flattenSourceData(apiObject awstypes.SourceData) []any {
	if apiObject == nil {
		return []any{}
	}
	m := map[string]any{}
	switch v := apiObject.(type) {
	case *awstypes.SourceDataMemberAcmPcaArn:
		m["acm_pca_arn"] = v.Value
	case *awstypes.SourceDataMemberX509CertificateData:
		m["x509_certificate_data"] = v.Value
	case *awstypes.UnknownUnionMember:
		log.Println("unknown tag:", v.Tag)
	default:
		log.Println("union is nil or unknown type")
	}
	return []any{m}
}

