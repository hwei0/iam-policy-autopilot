package rolesanywhere

import (
	"context"
	"fmt"
	"log"
	"reflect"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rolesanywhere"
	awstypes "github.com/aws/aws-sdk-go-v2/service/rolesanywhere/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandSource(tfList []any) *awstypes.Source {
	if len(tfList) == 0 || tfList[0] == nil {
		return nil
	}
	tfMap, ok := tfList[0].(map[string]any)
	if !ok {
		return nil
	}
	result := &awstypes.Source{}
	if v, ok := tfMap[names.AttrSourceType].(string); ok && v != "" {
		result.SourceType = awstypes.TrustAnchorType(v)
	}
	if v, ok := tfMap["source_data"].([]any); ok && len(v) > 0 && v[0] != nil {
		switch result.SourceType {
		case awstypes.TrustAnchorTypeAwsAcmPca:
			result.SourceData = expandSourceDataACMPCA(v[0].(map[string]any))
		case awstypes.TrustAnchorTypeCertificateBundle:
			result.SourceData = expandSourceDataCertificateBundle(v[0].(map[string]any))
		}
	}
	return result
}

func expandSourceDataACMPCA(tfMap map[string]any) *awstypes.SourceDataMemberAcmPcaArn {
	result := &awstypes.SourceDataMemberAcmPcaArn{}
	if v, ok := tfMap["acm_pca_arn"].(string); ok && v != "" {
		result.Value = v
	}
	return result
}

func expandSourceDataCertificateBundle(tfMap map[string]any) *awstypes.SourceDataMemberX509CertificateData {
	result := &awstypes.SourceDataMemberX509CertificateData{}
	if v, ok := tfMap["x509_certificate_data"].(string); ok && v != "" {
		result.Value = v
	}
	return result
}

func expandNotificationSettings(tfList []any) []awstypes.NotificationSetting {
	if len(tfList) == 0 {
		return nil
	}
	apiObjects := make([]awstypes.NotificationSetting, 0)
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObjects = append(apiObjects, expandNotificationSetting(tfMap))
	}
	return apiObjects
}

func expandNotificationSetting(tfMap map[string]any) awstypes.NotificationSetting {
	apiObject := awstypes.NotificationSetting{}
	if v, ok := tfMap["channel"].(string); ok {
		apiObject.Channel = awstypes.NotificationChannel(v)
	}
	if v, ok := tfMap[names.AttrEnabled].(bool); ok {
		apiObject.Enabled = aws.Bool(v)
	}
	if v, ok := tfMap["event"].(string); ok {
		apiObject.Event = awstypes.NotificationEvent(v)
	}
	if v, ok := tfMap["threshold"].(int); ok {
		apiObject.Threshold = aws.Int32(int32(v))
	}
	return apiObject
}

