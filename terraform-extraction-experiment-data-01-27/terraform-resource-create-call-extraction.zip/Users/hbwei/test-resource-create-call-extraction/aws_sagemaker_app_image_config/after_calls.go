package sagemaker

import (
	"context"
	"errors"
	"log"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sagemaker"
	awstypes "github.com/aws/aws-sdk-go-v2/service/sagemaker/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceAppImageConfigRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).SageMakerClient(ctx)
	image, err := findAppImageConfigByName(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		d.SetId("")
		log.Printf("[WARN] Unable to find SageMaker AI App Image Config (%s); removing from state", d.Id())
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading SageMaker AI App Image Config (%s): %s", d.Id(), err)
	}
	d.Set("app_image_config_name", image.AppImageConfigName)
	d.Set(names.AttrARN, image.AppImageConfigArn)
	if err := d.Set("code_editor_app_image_config", flattenCodeEditorAppImageConfig(image.CodeEditorAppImageConfig)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting code_editor_app_image_config: %s", err)
	}
	if err := d.Set("jupyter_lab_image_config", flattenJupyterLabAppImageConfig(image.JupyterLabAppImageConfig)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting kernel_gateway_image_config: %s", err)
	}
	if err := d.Set("kernel_gateway_image_config", flattenKernelGatewayImageConfig(image.KernelGatewayImageConfig)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting kernel_gateway_image_config: %s", err)
	}
	return diags
}

func findAppImageConfigByName(ctx context.Context, conn *sagemaker.Client, name string) (*sagemaker.DescribeAppImageConfigOutput, error) {
	input := &sagemaker.DescribeAppImageConfigInput{AppImageConfigName: aws.String(name)}
	output, err := conn.DescribeAppImageConfig(ctx, input)
	if errs.IsA[*awstypes.ResourceNotFound](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func flattenCodeEditorAppImageConfig(config *awstypes.CodeEditorAppImageConfig) []map[string]any {
	if config == nil {
		return []map[string]any{}
	}
	m := map[string]any{}
	if config.ContainerConfig != nil {
		m["container_config"] = flattenContainerConfig(config.ContainerConfig)
	}
	if config.FileSystemConfig != nil {
		m["file_system_config"] = flattenFileSystemConfig(config.FileSystemConfig)
	}
	return []map[string]any{m}
}

func flattenContainerConfig(config *awstypes.ContainerConfig) []map[string]any {
	if config == nil {
		return []map[string]any{}
	}
	m := map[string]any{"container_arguments": config.ContainerArguments, "container_entrypoint": config.ContainerEntrypoint, "container_environment_variables": config.ContainerEnvironmentVariables}
	return []map[string]any{m}
}

func flattenFileSystemConfig(config *awstypes.FileSystemConfig) []map[string]any {
	if config == nil {
		return []map[string]any{}
	}
	m := map[string]any{"mount_path": aws.ToString(config.MountPath), "default_gid": aws.ToInt32(config.DefaultGid), "default_uid": aws.ToInt32(config.DefaultUid)}
	return []map[string]any{m}
}

func flattenJupyterLabAppImageConfig(config *awstypes.JupyterLabAppImageConfig) []map[string]any {
	if config == nil {
		return []map[string]any{}
	}
	m := map[string]any{}
	if config.ContainerConfig != nil {
		m["container_config"] = flattenContainerConfig(config.ContainerConfig)
	}
	if config.FileSystemConfig != nil {
		m["file_system_config"] = flattenFileSystemConfig(config.FileSystemConfig)
	}
	return []map[string]any{m}
}

func flattenKernelGatewayImageConfig(config *awstypes.KernelGatewayImageConfig) []map[string]any {
	if config == nil {
		return []map[string]any{}
	}
	m := map[string]any{}
	if config.FileSystemConfig != nil {
		m["file_system_config"] = flattenFileSystemConfig(config.FileSystemConfig)
	}
	if config.KernelSpecs != nil {
		m["kernel_spec"] = flattenKernelGatewayImageConfigKernelSpecs(config.KernelSpecs)
	}
	return []map[string]any{m}
}

func flattenKernelGatewayImageConfigKernelSpecs(kernelSpecs []awstypes.KernelSpec) []map[string]any {
	res := make([]map[string]any, 0, len(kernelSpecs))
	for _, raw := range kernelSpecs {
		kernelSpec := make(map[string]any)
		kernelSpec[names.AttrName] = aws.ToString(raw.Name)
		if raw.DisplayName != nil {
			kernelSpec[names.AttrDisplayName] = aws.ToString(raw.DisplayName)
		}
		res = append(res, kernelSpec)
	}
	return res
}

