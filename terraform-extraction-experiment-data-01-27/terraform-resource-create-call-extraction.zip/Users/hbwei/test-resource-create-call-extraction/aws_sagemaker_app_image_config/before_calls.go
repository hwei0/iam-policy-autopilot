package sagemaker

import (
	"context"
	"errors"
	"log"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sagemaker"
	awstypes "github.com/aws/aws-sdk-go-v2/service/sagemaker/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func expandCodeEditorAppImageConfig(l []any) *awstypes.CodeEditorAppImageConfig {
	if len(l) == 0 {
		return nil
	}
	config := &awstypes.CodeEditorAppImageConfig{}
	if l[0] == nil {
		return config
	}
	m := l[0].(map[string]any)
	if v, ok := m["container_config"].([]any); ok && len(v) > 0 {
		config.ContainerConfig = expandContainerConfig(v)
	}
	if v, ok := m["file_system_config"].([]any); ok && len(v) > 0 {
		config.FileSystemConfig = expandFileSystemConfig(v)
	}
	return config
}

func expandContainerConfig(l []any) *awstypes.ContainerConfig {
	if len(l) == 0 {
		return nil
	}
	config := &awstypes.ContainerConfig{}
	if l[0] == nil {
		return config
	}
	m := l[0].(map[string]any)
	if v, ok := m["container_arguments"].([]any); ok && len(v) > 0 {
		config.ContainerArguments = flex.ExpandStringValueList(v)
	}
	if v, ok := m["container_entrypoint"].([]any); ok && len(v) > 0 {
		config.ContainerEntrypoint = flex.ExpandStringValueList(v)
	}
	if v, ok := m["container_environment_variables"].(map[string]any); ok && len(v) > 0 {
		config.ContainerEnvironmentVariables = flex.ExpandStringValueMap(v)
	}
	return config
}

func expandFileSystemConfig(l []any) *awstypes.FileSystemConfig {
	if len(l) == 0 {
		return nil
	}
	config := &awstypes.FileSystemConfig{DefaultGid: aws.Int32(100), DefaultUid: aws.Int32(1000), MountPath: aws.String("/home/sagemaker-user")}
	if l[0] == nil {
		return config
	}
	m := l[0].(map[string]any)
	config.DefaultGid = aws.Int32(int32(m["default_gid"].(int)))
	config.DefaultUid = aws.Int32(int32(m["default_uid"].(int)))
	config.MountPath = aws.String(m["mount_path"].(string))
	return config
}

func expandJupyterLabAppImageConfig(l []any) *awstypes.JupyterLabAppImageConfig {
	if len(l) == 0 {
		return nil
	}
	config := &awstypes.JupyterLabAppImageConfig{}
	if l[0] == nil {
		return config
	}
	m := l[0].(map[string]any)
	if v, ok := m["container_config"].([]any); ok && len(v) > 0 {
		config.ContainerConfig = expandContainerConfig(v)
	}
	if v, ok := m["file_system_config"].([]any); ok && len(v) > 0 {
		config.FileSystemConfig = expandFileSystemConfig(v)
	}
	return config
}

func expandKernelGatewayImageConfig(l []any) *awstypes.KernelGatewayImageConfig {
	if len(l) == 0 {
		return nil
	}
	config := &awstypes.KernelGatewayImageConfig{}
	if l[0] == nil {
		return config
	}
	m := l[0].(map[string]any)
	if v, ok := m["file_system_config"].([]any); ok && len(v) > 0 {
		config.FileSystemConfig = expandFileSystemConfig(v)
	}
	if v, ok := m["kernel_spec"].([]any); ok && len(v) > 0 {
		config.KernelSpecs = expandKernelGatewayImageConfigKernelSpecs(v)
	}
	return config
}

func expandKernelGatewayImageConfigKernelSpecs(tfList []any) []awstypes.KernelSpec {
	if len(tfList) == 0 {
		return nil
	}
	var kernelSpecs []awstypes.KernelSpec
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		kernelSpec := awstypes.KernelSpec{Name: aws.String(tfMap[names.AttrName].(string))}
		if v, ok := tfMap[names.AttrDisplayName].(string); ok && v != "" {
			kernelSpec.DisplayName = aws.String(v)
		}
		kernelSpecs = append(kernelSpecs, kernelSpec)
	}
	return kernelSpecs
}

