package sagemaker

import (
	"context"
	"errors"
	"log"
	"github.com/YakDriver/regexache"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sagemaker"
	awstypes "github.com/aws/aws-sdk-go-v2/service/sagemaker/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceAppImageConfigCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).SageMakerClient(ctx)
	name := d.Get("app_image_config_name").(string)
	input := sagemaker.CreateAppImageConfigInput{AppImageConfigName: aws.String(name), Tags: getTagsIn(ctx)}
	if v, ok := d.GetOk("code_editor_app_image_config"); ok {
		input.CodeEditorAppImageConfig = expandCodeEditorAppImageConfig(v.([]any))
	}
	if v, ok := d.GetOk("jupyter_lab_image_config"); ok {
		input.JupyterLabAppImageConfig = expandJupyterLabAppImageConfig(v.([]any))
	}
	if v, ok := d.GetOk("kernel_gateway_image_config"); ok {
		input.KernelGatewayImageConfig = expandKernelGatewayImageConfig(v.([]any))
	}
	_, err := conn.CreateAppImageConfig(ctx, &input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating SageMaker AI App Image Config (%s): %s", name, err)
	}
	d.SetId(name)
	return append(diags, resourceAppImageConfigRead(ctx, d, meta)...)
}

