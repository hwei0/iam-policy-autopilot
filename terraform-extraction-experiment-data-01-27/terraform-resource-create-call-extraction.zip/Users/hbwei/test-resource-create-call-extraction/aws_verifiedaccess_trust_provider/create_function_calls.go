package ec2

import (
	"context"
	"log"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	awstypes "github.com/aws/aws-sdk-go-v2/service/ec2/types"
	"github.com/hashicorp/aws-sdk-go-base/v2/tfawserr"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	sdkid "github.com/hashicorp/terraform-plugin-sdk/v2/helper/id"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceVerifiedAccessTrustProviderCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EC2Client(ctx)
	input := ec2.CreateVerifiedAccessTrustProviderInput{ClientToken: aws.String(sdkid.UniqueId()), PolicyReferenceName: aws.String(d.Get("policy_reference_name").(string)), TagSpecifications: getTagSpecificationsIn(ctx, awstypes.ResourceTypeVerifiedAccessTrustProvider), TrustProviderType: awstypes.TrustProviderType(d.Get("trust_provider_type").(string))}
	if v, ok := d.GetOk(names.AttrDescription); ok {
		input.Description = aws.String(v.(string))
	}
	if v, ok := d.GetOk("device_options"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input.DeviceOptions = expandCreateVerifiedAccessTrustProviderDeviceOptions(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("device_trust_provider_type"); ok {
		input.DeviceTrustProviderType = awstypes.DeviceTrustProviderType(v.(string))
	}
	if v, ok := d.GetOk("native_application_oidc_options"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input.NativeApplicationOidcOptions = expandCreateVerifiedAccessTrustProviderNativeApplicationOIDCOptions(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("oidc_options"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input.OidcOptions = expandCreateVerifiedAccessTrustProviderOIDCOptions(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("sse_specification"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		input.SseSpecification = expandVerifiedAccessSSESpecificationRequest(v.([]any)[0].(map[string]any))
	}
	if v, ok := d.GetOk("user_trust_provider_type"); ok {
		input.UserTrustProviderType = awstypes.UserTrustProviderType(v.(string))
	}
	output, err := conn.CreateVerifiedAccessTrustProvider(ctx, &input)
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Verified Access Trust Provider: %s", err)
	}
	d.SetId(aws.ToString(output.VerifiedAccessTrustProvider.VerifiedAccessTrustProviderId))
	return append(diags, resourceVerifiedAccessTrustProviderRead(ctx, d, meta)...)
}

func (ipProtocolType) String() string {
	return "IPProtocolType"
}

func expandCreateVerifiedAccessTrustProviderDeviceOptions(tfMap map[string]any) *awstypes.CreateVerifiedAccessTrustProviderDeviceOptions {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.CreateVerifiedAccessTrustProviderDeviceOptions{}
	if v, ok := tfMap["tenant_id"].(string); ok && v != "" {
		apiObject.TenantId = aws.String(v)
	}
	return apiObject
}

func expandCreateVerifiedAccessTrustProviderNativeApplicationOIDCOptions(tfMap map[string]any) *awstypes.CreateVerifiedAccessNativeApplicationOidcOptions {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.CreateVerifiedAccessNativeApplicationOidcOptions{}
	if v, ok := tfMap["authorization_endpoint"].(string); ok && v != "" {
		apiObject.AuthorizationEndpoint = aws.String(v)
	}
	if v, ok := tfMap[names.AttrClientID].(string); ok && v != "" {
		apiObject.ClientId = aws.String(v)
	}
	if v, ok := tfMap[names.AttrClientSecret].(string); ok && v != "" {
		apiObject.ClientSecret = aws.String(v)
	}
	if v, ok := tfMap["public_signing_key_endpoint"].(string); ok && v != "" {
		apiObject.PublicSigningKeyEndpoint = aws.String(v)
	}
	if v, ok := tfMap[names.AttrIssuer].(string); ok && v != "" {
		apiObject.Issuer = aws.String(v)
	}
	if v, ok := tfMap[names.AttrScope].(string); ok && v != "" {
		apiObject.Scope = aws.String(v)
	}
	if v, ok := tfMap["token_endpoint"].(string); ok && v != "" {
		apiObject.TokenEndpoint = aws.String(v)
	}
	if v, ok := tfMap["user_info_endpoint"].(string); ok && v != "" {
		apiObject.UserInfoEndpoint = aws.String(v)
	}
	return apiObject
}

func expandCreateVerifiedAccessTrustProviderOIDCOptions(tfMap map[string]any) *awstypes.CreateVerifiedAccessTrustProviderOidcOptions {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.CreateVerifiedAccessTrustProviderOidcOptions{}
	if v, ok := tfMap["authorization_endpoint"].(string); ok && v != "" {
		apiObject.AuthorizationEndpoint = aws.String(v)
	}
	if v, ok := tfMap[names.AttrClientID].(string); ok && v != "" {
		apiObject.ClientId = aws.String(v)
	}
	if v, ok := tfMap[names.AttrClientSecret].(string); ok && v != "" {
		apiObject.ClientSecret = aws.String(v)
	}
	if v, ok := tfMap[names.AttrIssuer].(string); ok && v != "" {
		apiObject.Issuer = aws.String(v)
	}
	if v, ok := tfMap[names.AttrScope].(string); ok && v != "" {
		apiObject.Scope = aws.String(v)
	}
	if v, ok := tfMap["token_endpoint"].(string); ok && v != "" {
		apiObject.TokenEndpoint = aws.String(v)
	}
	if v, ok := tfMap["user_info_endpoint"].(string); ok && v != "" {
		apiObject.UserInfoEndpoint = aws.String(v)
	}
	return apiObject
}

func expandVerifiedAccessSSESpecificationRequest(tfMap map[string]any) *awstypes.VerifiedAccessSseSpecificationRequest {
	if tfMap == nil {
		return nil
	}
	apiObject := &awstypes.VerifiedAccessSseSpecificationRequest{}
	if v, ok := tfMap["customer_managed_key_enabled"].(bool); ok {
		apiObject.CustomerManagedKeyEnabled = aws.Bool(v)
	}
	if v, ok := tfMap[names.AttrKMSKeyARN].(string); ok && v != "" {
		apiObject.KmsKeyArn = aws.String(v)
	}
	return apiObject
}

func resourceVerifiedAccessTrustProviderRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).EC2Client(ctx)
	output, err := findVerifiedAccessTrustProviderByID(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] EC2 Verified Access Trust Provider (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Verified Access Trust Provider (%s): %s", d.Id(), err)
	}
	d.Set(names.AttrDescription, output.Description)
	if v := output.DeviceOptions; v != nil {
		if err := d.Set("device_options", flattenDeviceOptions(v)); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting device_options: %s", err)
		}
	} else {
		d.Set("device_options", nil)
	}
	d.Set("device_trust_provider_type", output.DeviceTrustProviderType)
	if v := output.OidcOptions; v != nil {
		if err := d.Set("oidc_options", flattenOIDCOptions(v, d.Get("oidc_options.0.client_secret").(string))); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting oidc_options: %s", err)
		}
	} else {
		d.Set("oidc_options", nil)
	}
	if v := output.NativeApplicationOidcOptions; v != nil {
		if err := d.Set("native_application_oidc_options", flattenNativeApplicationOIDCOptions(v, d.Get("native_application_oidc_options.0.client_secret").(string))); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting native_application_oidc_options: %s", err)
		}
	} else {
		d.Set("native_application_oidc_options", nil)
	}
	d.Set("policy_reference_name", output.PolicyReferenceName)
	d.Set("trust_provider_type", output.TrustProviderType)
	if err := d.Set("sse_specification", flattenVerifiedAccessSSESpecificationResponse(output.SseSpecification)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting sse_specification: %s", err)
	}
	d.Set("user_trust_provider_type", output.UserTrustProviderType)
	setTagsOut(ctx, output.Tags)
	return diags
}

func findVerifiedAccessTrustProviderByID(ctx context.Context, conn *ec2.Client, id string) (*awstypes.VerifiedAccessTrustProvider, error) {
	input := ec2.DescribeVerifiedAccessTrustProvidersInput{VerifiedAccessTrustProviderIds: []string{id}}
	output, err := findVerifiedAccessTrustProvider(ctx, conn, &input)
	if err != nil {
		return nil, err
	}
	if aws.ToString(output.VerifiedAccessTrustProviderId) != id {
		return nil, &retry.NotFoundError{LastRequest: &input}
	}
	return output, nil
}

func findVerifiedAccessTrustProvider(ctx context.Context, conn *ec2.Client, input *ec2.DescribeVerifiedAccessTrustProvidersInput) (*awstypes.VerifiedAccessTrustProvider, error) {
	output, err := findVerifiedAccessTrustProviders(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findVerifiedAccessTrustProviders(ctx context.Context, conn *ec2.Client, input *ec2.DescribeVerifiedAccessTrustProvidersInput) ([]awstypes.VerifiedAccessTrustProvider, error) {
	var output []awstypes.VerifiedAccessTrustProvider
	pages := ec2.NewDescribeVerifiedAccessTrustProvidersPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if tfawserr.ErrCodeEquals(err, errCodeInvalidVerifiedAccessTrustProviderIdNotFound) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: &input}
		}
		if err != nil {
			return nil, err
		}
		output = append(output, page.VerifiedAccessTrustProviders...)
	}
	return output, nil
}

func (p *describeVpcEncryptionControlsPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) HasMorePages() bool {
	return p.firstPage || (p.nextToken != nil && len(*p.nextToken) != 0)
}// HasMorePages returns a boolean indicating whether more pages are available


func (p *describeVpcEncryptionControlsPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.DescribeVpcEncryptionControlsOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.DescribeVpcEncryptionControls(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next DescribeVpcEncryptionControls page.


func (p *getVpcResourcesBlockingEncryptionEnforcementPaginator) NextPage(ctx context.Context, optFns ...func(*ec2.Options)) (*ec2.GetVpcResourcesBlockingEncryptionEnforcementOutput, error) {
	if !p.HasMorePages() {
		return nil, fmt.Errorf("no more pages available")
	}
	params := *p.params
	params.NextToken = p.nextToken
	var limit *int32
	if p.options.Limit > 0 {
		limit = &p.options.Limit
	}
	params.MaxResults = limit
	result, err := p.client.GetVpcResourcesBlockingEncryptionEnforcement(ctx, &params, optFns...)
	if err != nil {
		return nil, err
	}
	p.firstPage = false
	prevToken := p.nextToken
	p.nextToken = result.NextToken
	if p.options.StopOnDuplicateToken && prevToken != nil && p.nextToken != nil && *prevToken == *p.nextToken {
		p.nextToken = nil
	}
	return result, nil
}// NextPage retrieves the next GetVpcResourcesBlockingEncryptionEnforcement page.


func flattenDeviceOptions(apiObject *awstypes.DeviceOptions) []any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.TenantId; v != nil {
		tfMap["tenant_id"] = aws.ToString(v)
	}
	return []any{tfMap}
}

func flattenOIDCOptions(apiObject *awstypes.OidcOptions, clientSecret string) []any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{names.AttrClientSecret: clientSecret}
	if v := apiObject.AuthorizationEndpoint; v != nil {
		tfMap["authorization_endpoint"] = aws.ToString(v)
	}
	if v := apiObject.ClientId; v != nil {
		tfMap[names.AttrClientID] = aws.ToString(v)
	}
	if v := apiObject.Issuer; v != nil {
		tfMap[names.AttrIssuer] = aws.ToString(v)
	}
	if v := apiObject.Scope; v != nil {
		tfMap[names.AttrScope] = aws.ToString(v)
	}
	if v := apiObject.TokenEndpoint; v != nil {
		tfMap["token_endpoint"] = aws.ToString(v)
	}
	if v := apiObject.UserInfoEndpoint; v != nil {
		tfMap["user_info_endpoint"] = aws.ToString(v)
	}
	return []any{tfMap}
}

func flattenNativeApplicationOIDCOptions(apiObject *awstypes.NativeApplicationOidcOptions, clientSecret string) []any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{names.AttrClientSecret: clientSecret}
	if v := apiObject.AuthorizationEndpoint; v != nil {
		tfMap["authorization_endpoint"] = aws.ToString(v)
	}
	if v := apiObject.ClientId; v != nil {
		tfMap[names.AttrClientID] = aws.ToString(v)
	}
	if v := apiObject.Issuer; v != nil {
		tfMap[names.AttrIssuer] = aws.ToString(v)
	}
	if v := apiObject.PublicSigningKeyEndpoint; v != nil {
		tfMap["public_signing_key_endpoint"] = aws.ToString(v)
	}
	if v := apiObject.Scope; v != nil {
		tfMap[names.AttrScope] = aws.ToString(v)
	}
	if v := apiObject.TokenEndpoint; v != nil {
		tfMap["token_endpoint"] = aws.ToString(v)
	}
	if v := apiObject.UserInfoEndpoint; v != nil {
		tfMap["user_info_endpoint"] = aws.ToString(v)
	}
	return []any{tfMap}
}

func flattenVerifiedAccessSSESpecificationResponse(apiObject *awstypes.VerifiedAccessSseSpecificationResponse) []any {
	if apiObject == nil {
		return nil
	}
	tfMap := map[string]any{}
	if v := apiObject.CustomerManagedKeyEnabled; v != nil {
		tfMap["customer_managed_key_enabled"] = aws.ToBool(v)
	}
	if v := apiObject.KmsKeyArn; v != nil {
		tfMap[names.AttrKMSKeyARN] = aws.ToString(v)
	}
	return []any{tfMap}
}

