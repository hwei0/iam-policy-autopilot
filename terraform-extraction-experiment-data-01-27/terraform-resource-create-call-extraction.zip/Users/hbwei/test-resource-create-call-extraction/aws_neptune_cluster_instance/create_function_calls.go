package neptune

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/neptune"
	awstypes "github.com/aws/aws-sdk-go-v2/service/neptune/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/create"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	tftags "github.com/hashicorp/terraform-provider-aws/internal/tags"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/internal/verify"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func resourceClusterInstanceCreate(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).NeptuneClient(ctx)
	instanceID := create.NewNameGenerator(create.WithConfiguredName(d.Get(names.AttrIdentifier).(string)), create.WithConfiguredPrefix(d.Get("identifier_prefix").(string)), create.WithDefaultPrefix("tf-")).Generate()
	input := &neptune.CreateDBInstanceInput{AutoMinorVersionUpgrade: aws.Bool(d.Get(names.AttrAutoMinorVersionUpgrade).(bool)), DBClusterIdentifier: aws.String(d.Get(names.AttrClusterIdentifier).(string)), DBInstanceClass: aws.String(d.Get("instance_class").(string)), DBInstanceIdentifier: aws.String(instanceID), Engine: aws.String(d.Get(names.AttrEngine).(string)), PromotionTier: aws.Int32(int32(d.Get("promotion_tier").(int))), PubliclyAccessible: aws.Bool(d.Get(names.AttrPubliclyAccessible).(bool)), Tags: getTagsIn(ctx)}
	if v, ok := d.GetOk(names.AttrAvailabilityZone); ok {
		input.AvailabilityZone = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrEngineVersion); ok {
		input.EngineVersion = aws.String(v.(string))
	}
	if v, ok := d.GetOk("neptune_parameter_group_name"); ok {
		input.DBParameterGroupName = aws.String(v.(string))
	}
	if v, ok := d.GetOk("neptune_subnet_group_name"); ok {
		input.DBSubnetGroupName = aws.String(v.(string))
	}
	if v, ok := d.GetOk("preferred_backup_window"); ok {
		input.PreferredBackupWindow = aws.String(v.(string))
	}
	if v, ok := d.GetOk(names.AttrPreferredMaintenanceWindow); ok {
		input.PreferredMaintenanceWindow = aws.String(v.(string))
	}
	outputRaw, err := tfresource.RetryWhenAWSErrMessageContains(ctx, propagationTimeout, func(ctx context.Context) (any, error) {
		return conn.CreateDBInstance(ctx, input)
	}, errCodeInvalidParameterValue, "IAM role ARN value is invalid or does not include the required permissions")
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "creating Neptune Cluster Instance (%s): %s", instanceID, err)
	}
	d.SetId(aws.ToString(outputRaw.(*neptune.CreateDBInstanceOutput).DBInstance.DBInstanceIdentifier))
	if _, err := waitDBInstanceAvailable(ctx, conn, d.Id(), d.Timeout(schema.TimeoutCreate)); err != nil {
		return sdkdiag.AppendErrorf(diags, "waiting for Neptune Cluster Instance (%s) create: %s", d.Id(), err)
	}
	return append(diags, resourceClusterInstanceRead(ctx, d, meta)...)
}

func waitDBInstanceAvailable(ctx context.Context, conn *neptune.Client, id string, timeout time.Duration) (*awstypes.DBInstance, error) {
	stateConf := &retry.StateChangeConf{Pending: []string{dbInstanceStatusBackingUp, dbInstanceStatusConfiguringEnhancedMonitoring, dbInstanceStatusConfiguringIAMDatabaseAuth, dbInstanceStatusConfiguringLogExports, dbInstanceStatusCreating, dbInstanceStatusMaintenance, dbInstanceStatusModifying, dbInstanceStatusRebooting, dbInstanceStatusRenaming, dbInstanceStatusResettingMasterCredentials, dbInstanceStatusStarting, dbInstanceStatusStorageOptimization, dbInstanceStatusUpgrading}, Target: []string{dbInstanceStatusAvailable}, Refresh: statusDBInstance(ctx, conn, id), Timeout: timeout, MinTimeout: 10 * time.Second, Delay: 30 * time.Second}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*awstypes.DBInstance); ok {
		return output, err
	}
	return nil, err
}

func statusDBInstance(ctx context.Context, conn *neptune.Client, id string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findDBInstanceByID(ctx, conn, id)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return nil, "", err
		}
		return output, aws.ToString(output.DBInstanceStatus), nil
	}
}

func findDBInstanceByID(ctx context.Context, conn *neptune.Client, id string) (*awstypes.DBInstance, error) {
	input := &neptune.DescribeDBInstancesInput{DBInstanceIdentifier: aws.String(id)}
	output, err := findDBInstance(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	if aws.ToString(output.DBInstanceIdentifier) != id {
		return nil, &retry.NotFoundError{LastRequest: input}
	}
	return output, nil
}

func findDBInstance(ctx context.Context, conn *neptune.Client, input *neptune.DescribeDBInstancesInput) (*awstypes.DBInstance, error) {
	output, err := findDBInstances(ctx, conn, input)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findDBInstances(ctx context.Context, conn *neptune.Client, input *neptune.DescribeDBInstancesInput) ([]awstypes.DBInstance, error) {
	var output []awstypes.DBInstance
	pages := neptune.NewDescribeDBInstancesPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if errs.IsA[*awstypes.DBInstanceNotFoundFault](err) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
		}
		if err != nil {
			return nil, err
		}
		output = append(output, page.DBInstances...)
	}
	return output, nil
}

func resourceClusterInstanceRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).NeptuneClient(ctx)
	db, err := findDBInstanceByID(ctx, conn, d.Id())
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Neptune Cluster Instance (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Neptune Cluster Instance (%s): %s", d.Id(), err)
	}
	clusterID := aws.ToString(db.DBClusterIdentifier)
	d.Set(names.AttrARN, db.DBInstanceArn)
	d.Set(names.AttrAutoMinorVersionUpgrade, db.AutoMinorVersionUpgrade)
	d.Set(names.AttrAvailabilityZone, db.AvailabilityZone)
	d.Set(names.AttrClusterIdentifier, clusterID)
	d.Set("dbi_resource_id", db.DbiResourceId)
	d.Set(names.AttrEngineVersion, db.EngineVersion)
	d.Set(names.AttrEngine, db.Engine)
	d.Set(names.AttrIdentifier, db.DBInstanceIdentifier)
	d.Set("identifier_prefix", create.NamePrefixFromName(aws.ToString(db.DBInstanceIdentifier)))
	d.Set("instance_class", db.DBInstanceClass)
	d.Set(names.AttrKMSKeyARN, db.KmsKeyId)
	if len(db.DBParameterGroups) > 0 {
		d.Set("neptune_parameter_group_name", db.DBParameterGroups[0].DBParameterGroupName)
	}
	if db.DBSubnetGroup != nil {
		d.Set("neptune_subnet_group_name", db.DBSubnetGroup.DBSubnetGroupName)
	}
	d.Set("preferred_backup_window", db.PreferredBackupWindow)
	d.Set(names.AttrPreferredMaintenanceWindow, db.PreferredMaintenanceWindow)
	d.Set("promotion_tier", db.PromotionTier)
	d.Set(names.AttrPubliclyAccessible, db.PubliclyAccessible)
	d.Set(names.AttrStorageEncrypted, db.StorageEncrypted)
	d.Set(names.AttrStorageType, db.StorageType)
	if db.Endpoint != nil {
		address := aws.ToString(db.Endpoint.Address)
		port := int(aws.ToInt32(db.Endpoint.Port))
		d.Set(names.AttrAddress, address)
		d.Set(names.AttrEndpoint, fmt.Sprintf("%s:%d", address, port))
		d.Set(names.AttrPort, port)
	}
	m, err := findClusterMemberByInstanceByTwoPartKey(ctx, conn, clusterID, d.Id())
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Neptune Cluster (%s) member (%s): %s", clusterID, d.Id(), err)
	}
	d.Set("writer", m.IsClusterWriter)
	return diags
}

func findClusterMemberByInstanceByTwoPartKey(ctx context.Context, conn *neptune.Client, clusterID, instanceID string) (*awstypes.DBClusterMember, error) {
	output, err := findDBClusterByID(ctx, conn, clusterID)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(tfslices.Filter(output.DBClusterMembers, func(v awstypes.DBClusterMember) bool {
		return aws.ToString(v.DBInstanceIdentifier) == instanceID
	}))
}

func findDBClusterByID(ctx context.Context, conn *neptune.Client, id string, optFns ...func(*neptune.Options)) (*awstypes.DBCluster, error) {
	input := &neptune.DescribeDBClustersInput{DBClusterIdentifier: aws.String(id)}
	output, err := findDBCluster(ctx, conn, input, tfslices.PredicateTrue[awstypes.DBCluster](), optFns...)
	if err != nil {
		return nil, err
	}
	if arn.IsARN(id) {
		if aws.ToString(output.DBClusterArn) != id {
			return nil, &retry.NotFoundError{LastRequest: input}
		}
	} else if aws.ToString(output.DBClusterIdentifier) != id {
		return nil, &retry.NotFoundError{LastRequest: input}
	}
	return output, nil
}

func findDBCluster(ctx context.Context, conn *neptune.Client, input *neptune.DescribeDBClustersInput, filter tfslices.Predicate[awstypes.DBCluster], optFns ...func(*neptune.Options)) (*awstypes.DBCluster, error) {
	output, err := findDBClusters(ctx, conn, input, filter, optFns...)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findDBClusters(ctx context.Context, conn *neptune.Client, input *neptune.DescribeDBClustersInput, filter tfslices.Predicate[awstypes.DBCluster], optFns ...func(*neptune.Options)) ([]awstypes.DBCluster, error) {
	var output []awstypes.DBCluster
	pages := neptune.NewDescribeDBClustersPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx, optFns...)
		if errs.IsA[*awstypes.DBClusterNotFoundFault](err) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
		}
		if err != nil {
			return nil, err
		}
		for _, v := range page.DBClusters {
			if filter(v) {
				output = append(output, v)
			}
		}
	}
	return output, nil
}

