package route53

import (
	"context"
	"errors"
	"fmt"
	"log"
	"slices"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/route53"
	awstypes "github.com/aws/aws-sdk-go-v2/service/route53/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/sdkv2"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func cleanZoneID(id string) string {
	return strings.TrimPrefix(id, "/hostedzone/")
}// cleanZoneID is used to remove the leading "/hostedzone/" from a hosted zone ID


func findHostedZoneByID(ctx context.Context, conn *route53.Client, id string) (*route53.GetHostedZoneOutput, error) {
	input := &route53.GetHostedZoneInput{Id: aws.String(id)}
	output, err := conn.GetHostedZone(ctx, input)
	if errs.IsA[*awstypes.NoSuchHostedZone](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.HostedZone == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func expandResourceRecordSet(d *schema.ResourceData, zoneName string) *awstypes.ResourceRecordSet {
	en := expandRecordName(d.Get(names.AttrName).(string), zoneName)
	rrType := awstypes.RRType(d.Get(names.AttrType).(string))
	apiObject := &awstypes.ResourceRecordSet{Name: aws.String(en), Type: rrType}
	if v, ok := d.GetOk("records"); ok {
		apiObject.ResourceRecords = expandResourceRecords(flex.ExpandStringValueSet(v.(*schema.Set)), rrType)
		if v := d.GetRawPlan().GetAttr("ttl"); v.IsKnown() && !v.IsNull() {
			v, _ := v.AsBigFloat().Int64()
			apiObject.TTL = aws.Int64(v)
		}
	}
	if v, ok := d.GetOk(names.AttrAlias); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		apiObject.AliasTarget = &awstypes.AliasTarget{DNSName: aws.String(tfMap[names.AttrName].(string)), EvaluateTargetHealth: tfMap["evaluate_target_health"].(bool), HostedZoneId: aws.String(tfMap["zone_id"].(string))}
	}
	if v, ok := d.GetOk("cidr_routing_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		apiObject.CidrRoutingConfig = &awstypes.CidrRoutingConfig{CollectionId: aws.String(tfMap["collection_id"].(string)), LocationName: aws.String(tfMap["location_name"].(string))}
	}
	if v, ok := d.GetOk("failover_routing_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		apiObject.Failover = awstypes.ResourceRecordSetFailover(tfMap[names.AttrType].(string))
	}
	if v, ok := d.GetOk("geolocation_routing_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		apiObject.GeoLocation = &awstypes.GeoLocation{ContinentCode: nilString(tfMap["continent"].(string)), CountryCode: nilString(tfMap["country"].(string)), SubdivisionCode: nilString(tfMap["subdivision"].(string))}
	}
	if v, ok := d.GetOk("geoproximity_routing_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		apiObject.GeoProximityLocation = &awstypes.GeoProximityLocation{AWSRegion: nilString(tfMap["aws_region"].(string)), Bias: aws.Int32(int32(tfMap["bias"].(int))), Coordinates: expandCoordinates(tfMap["coordinates"].(*schema.Set).List()), LocalZoneGroup: nilString(tfMap["local_zone_group"].(string))}
	}
	if v, ok := d.GetOk("health_check_id"); ok {
		apiObject.HealthCheckId = aws.String(v.(string))
	}
	if v, ok := d.GetOk("latency_routing_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		apiObject.Region = awstypes.ResourceRecordSetRegion(tfMap[names.AttrRegion].(string))
	}
	if v, ok := d.GetOk("multivalue_answer_routing_policy"); ok {
		apiObject.MultiValueAnswer = aws.Bool(v.(bool))
	}
	if v, ok := d.GetOk("set_identifier"); ok {
		apiObject.SetIdentifier = aws.String(v.(string))
	}
	if v, ok := d.GetOk("weighted_routing_policy"); ok && len(v.([]any)) > 0 && v.([]any)[0] != nil {
		tfMap := v.([]any)[0].(map[string]any)
		apiObject.Weight = aws.Int64(int64(tfMap[names.AttrWeight].(int)))
	}
	return apiObject
}

func expandRecordName(name, zone string) string {
	rn := normalizeDomainName(name)
	zone = strings.TrimSuffix(zone, ".")
	if !strings.HasSuffix(rn, zone) {
		if len(name) == 0 {
			rn = zone
		} else {
			rn = strings.Join([ // Check if the current record name contains the zone suffix.
			// If it does not, add the zone name to form a fully qualified name
			// and keep AWS happy.
			]string{rn, zone}, ".")
		}
	}
	return rn
}

func normalizeDomainName(v any) string {
	var s string
	switch v := v.( // normalizeDomainName is a wrapper around the shared dns package normalization
	// function which handles interface values from Plugin SDK V2 based resources
	type) {
	case *string:
		s = aws.ToString(v)
	case string:
		s = v
	default:
		return ""
	}
	return dns.Normalize(s)
}

func expandResourceRecords(rrs []string, rrType awstypes.RRType) []awstypes.ResourceRecord {
	apiObjects := make([]awstypes.ResourceRecord, 0, len(rrs))
	for _, rr := range rrs {
		if rrType == awstypes.RRTypeTxt || rrType == awstypes.RRTypeSpf {
			rr = flattenTxtEntry(rr)
		}
		apiObjects = append(apiObjects, awstypes.ResourceRecord{Value: aws.String(rr)})
	}
	return apiObjects
}

func flattenTxtEntry(s string) string {
	return fmt.Sprintf(`"%s"`, s)
}

func nilString(s string) *string {
	if s == "" {
		return nil
	}
	return aws.String(s)
}// nilString takes a string as an argument and returns a string
// pointer. The returned pointer is nil if the string argument is
// empty. Otherwise, it is a pointer to a copy of the string.


func expandCoordinates(tfList []any) *awstypes.Coordinates {
	if len(tfList) == 0 {
		return nil
	}
	apiObject := &awstypes.Coordinates{}
	for _, tfMapRaw := range tfList {
		tfMap, ok := tfMapRaw.(map[string]any)
		if !ok {
			continue
		}
		apiObject.Latitude = aws.String(tfMap["latitude"].(string))
		apiObject.Longitude = aws.String(tfMap["longitude"].(string))
	}
	return apiObject
}

