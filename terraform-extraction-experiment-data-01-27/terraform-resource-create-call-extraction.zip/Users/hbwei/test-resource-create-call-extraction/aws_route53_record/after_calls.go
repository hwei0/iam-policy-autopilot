package route53

import (
	"context"
	"errors"
	"fmt"
	"log"
	"slices"
	"strings"
	"time"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/route53"
	awstypes "github.com/aws/aws-sdk-go-v2/service/route53/types"
	"github.com/hashicorp/terraform-plugin-sdk/v2/diag"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/retry"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/validation"
	"github.com/hashicorp/terraform-provider-aws/internal/conns"
	"github.com/hashicorp/terraform-provider-aws/internal/enum"
	"github.com/hashicorp/terraform-provider-aws/internal/errs"
	"github.com/hashicorp/terraform-provider-aws/internal/errs/sdkdiag"
	"github.com/hashicorp/terraform-provider-aws/internal/flex"
	"github.com/hashicorp/terraform-provider-aws/internal/sdkv2"
	tfslices "github.com/hashicorp/terraform-provider-aws/internal/slices"
	"github.com/hashicorp/terraform-provider-aws/internal/tfresource"
	"github.com/hashicorp/terraform-provider-aws/names"
)

func createRecordImportID(d *schema.ResourceData) string {
	parts := []string{d.Get("zone_id").(string), strings.ToLower(d.Get(names.AttrName).(string)), d.Get(names.AttrType).(string)}
	if v, ok := d.GetOk("set_identifier"); ok {
		parts = append(parts, v.(string))
	}
	return strings.Join(parts, "_")
}

func waitChangeInsync(ctx context.Context, conn *route53.Client, id string, timeout time.Duration) (*awstypes.ChangeInfo, error) {
	const (
		delay		= 15 * time.Second
		minTimeout	= 5 * time.Second
		pollInterval	= 15 * time.Second
	)
	stateConf := &retry.StateChangeConf{Pending: enum.Slice(awstypes.ChangeStatusPending), Target: enum.Slice(awstypes.ChangeStatusInsync), Refresh: statusChange(ctx, conn, id), Delay: delay, MinTimeout: minTimeout, PollInterval: pollInterval, Timeout: timeout}
	outputRaw, err := stateConf.WaitForStateContext(ctx)
	if output, ok := outputRaw.(*awstypes.ChangeInfo); ok {
		return output, err
	}
	return nil, err
}// Route53 is vulnerable to throttling so a longer delay and poll interval helps to avoid it.


func statusChange(ctx context.Context, conn *route53.Client, id string) retry.StateRefreshFunc {
	return func() (any, string, error) {
		output, err := findChangeByID(ctx, conn, id)
		if tfresource.NotFound(err) {
			return nil, "", nil
		}
		if err != nil {
			return nil, "", err
		}
		return output, string(output.Status), nil
	}
}

func findChangeByID(ctx context.Context, conn *route53.Client, id string) (*awstypes.ChangeInfo, error) {
	input := &route53.GetChangeInput{Id: aws.String(id)}
	output, err := conn.GetChange(ctx, input)
	if errs.IsA[*awstypes.NoSuchChange](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.ChangeInfo == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output.ChangeInfo, nil
}

func resourceRecordRead(ctx context.Context, d *schema.ResourceData, meta any) diag.Diagnostics {
	var diags diag.Diagnostics
	conn := meta.(*conns.AWSClient).Route53Client(ctx)
	record, fqdn, err := findResourceRecordSetByFourPartKey(ctx, conn, cleanZoneID(d.Get("zone_id").(string)), d.Get(names.AttrName).(string), d.Get(names.AttrType).(string), d.Get("set_identifier").(string))
	if !d.IsNewResource() && tfresource.NotFound(err) {
		log.Printf("[WARN] Route 53 Record (%s) not found, removing from state", d.Id())
		d.SetId("")
		return diags
	}
	if err != nil {
		return sdkdiag.AppendErrorf(diags, "reading Route 53 Record (%s): %s", d.Id(), err)
	}
	if alias := record.AliasTarget; alias != nil {
		tfList := []any{map[string]any{"evaluate_target_health": alias.EvaluateTargetHealth, names.AttrName: normalizeAliasDomainName(aws.ToString(alias.DNSName)), "zone_id": aws.ToString(alias.HostedZoneId)}}
		if err := d.Set(names.AttrAlias, tfList); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting alias: %s", err)
		}
	}
	if cidrRoutingConfig := record.CidrRoutingConfig; cidrRoutingConfig != nil {
		tfList := []any{map[string]any{"collection_id": aws.ToString(cidrRoutingConfig.CollectionId), "location_name": aws.ToString(cidrRoutingConfig.LocationName)}}
		if err := d.Set("cidr_routing_policy", tfList); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting cidr_routing_policy: %s", err)
		}
	}
	if failover := record.Failover; failover != "" {
		tfList := []any{map[string]any{names.AttrType: failover}}
		if err := d.Set("failover_routing_policy", tfList); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting failover_routing_policy: %s", err)
		}
	}
	if v := aws.ToString(fqdn); strings.HasPrefix(v, `\052.`) {
		fqdn = aws.String(`*.` + strings.TrimPrefix(v, `\052.`))
	}
	d.Set("fqdn", fqdn)
	if geoLocation := record.GeoLocation; geoLocation != nil {
		tfList := []any{map[string]any{"continent": aws.ToString(geoLocation.ContinentCode), "country": aws.ToString(geoLocation.CountryCode), "subdivision": aws.ToString(geoLocation.SubdivisionCode)}}
		if err := d.Set("geolocation_routing_policy", tfList); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting geolocation_routing_policy: %s", err)
		}
	}
	if geoProximityLocation := record.GeoProximityLocation; geoProximityLocation != nil {
		tfList := []any{map[string]any{"aws_region": aws.ToString(record.GeoProximityLocation.AWSRegion), "bias": aws.ToInt32((record.GeoProximityLocation.Bias)), "coordinates": flattenCoordinate(record.GeoProximityLocation.Coordinates), "local_zone_group": aws.ToString(record.GeoProximityLocation.LocalZoneGroup)}}
		if err := d.Set("geoproximity_routing_policy", tfList); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting geoproximity_routing_policy: %s", err)
		}
	}
	d.Set("health_check_id", record.HealthCheckId)
	if region := record.Region; region != "" {
		tfList := []any{map[string]any{names.AttrRegion: region}}
		if err := d.Set("latency_routing_policy", tfList); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting latency_routing_policy: %s", err)
		}
	}
	d.Set("multivalue_answer_routing_policy", record.MultiValueAnswer)
	if err := d.Set("records", flattenResourceRecords(record.ResourceRecords, record.Type)); err != nil {
		return sdkdiag.AppendErrorf(diags, "setting records: %s", err)
	}
	d.Set("set_identifier", record.SetIdentifier)
	d.Set("ttl", record.TTL)
	if weight := record.Weight; weight != nil {
		tfList := []any{map[string]any{names.AttrWeight: aws.ToInt64((record.Weight))}}
		if err := d.Set("weighted_routing_policy", tfList); err != nil {
			return sdkdiag.AppendErrorf(diags, "setting weighted_routing_policy: %s", err)
		}
	}
	return diags
}

func findResourceRecordSetByFourPartKey(ctx context.Context, conn *route53.Client, zoneID, recordName, recordType, recordSetID string) (*awstypes.ResourceRecordSet, *string, error) {
	zone, err := findHostedZoneByID(ctx, conn, zoneID)
	if err != nil {
		return nil, nil, err
	}
	name := expandRecordName(recordName, aws.ToString(zone.HostedZone.Name))
	recordName = fqdn(name)
	rrType := awstypes.RRType(strings.ToUpper(recordType))
	input := &route53.ListResourceRecordSetsInput{HostedZoneId: aws.String(zoneID), StartRecordName: aws.String(recordName), StartRecordType: rrType}
	if recordSetID == "" {
		input.MaxItems = aws.Int32(1)
	} else {
		input.MaxItems = aws.Int32(100)
	}
	output, err := findResourceRecordSet(ctx, conn, input, resourceRecordsFor(recordName, rrType), func(v *awstypes.ResourceRecordSet) bool {
		if recordName != strings.ToLower(aws.ToString(v.Name)) {
			return false
		}
		if recordType != strings.ToUpper(string(v.Type)) {
			return false
		}
		if recordSetID != aws.ToString(v.SetIdentifier) {
			return false
		}
		return true
	})
	if err != nil {
		return nil, nil, err
	}
	return output, &name, nil
}

func findHostedZoneByID(ctx context.Context, conn *route53.Client, id string) (*route53.GetHostedZoneOutput, error) {
	input := &route53.GetHostedZoneInput{Id: aws.String(id)}
	output, err := conn.GetHostedZone(ctx, input)
	if errs.IsA[*awstypes.NoSuchHostedZone](err) {
		return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
	}
	if err != nil {
		return nil, err
	}
	if output == nil || output.HostedZone == nil {
		return nil, tfresource.NewEmptyResultError(input)
	}
	return output, nil
}

func expandRecordName(name, zone string) string {
	rn := normalizeDomainName(name)
	zone = strings.TrimSuffix(zone, ".")
	if !strings.HasSuffix(rn, zone) {
		if len(name) == 0 {
			rn = zone
		} else {
			rn = strings.Join([ // Check if the current record name contains the zone suffix.
			// If it does not, add the zone name to form a fully qualified name
			// and keep AWS happy.
			]string{rn, zone}, ".")
		}
	}
	return rn
}

func normalizeDomainName(v any) string {
	var s string
	switch v := v.( // normalizeDomainName is a wrapper around the shared dns package normalization
	// function which handles interface values from Plugin SDK V2 based resources
	type) {
	case *string:
		s = aws.ToString(v)
	case string:
		s = v
	default:
		return ""
	}
	return dns.Normalize(s)
}

func fqdn(name string) string {
	if n := len(name); n == 0 || name[n-1] == '.' {
		return name
	} else {
		return name + "."
	}
}// fqdn appends a single dot (".") to the input string if necessary


func findResourceRecordSet(ctx context.Context, conn *route53.Client, input *route53.ListResourceRecordSetsInput, morePages tfslices.Predicate[*route53.ListResourceRecordSetsOutput], filter tfslices.Predicate[*awstypes.ResourceRecordSet]) (*awstypes.ResourceRecordSet, error) {
	output, err := findResourceRecordSets(ctx, conn, input, morePages, filter)
	if err != nil {
		return nil, err
	}
	return tfresource.AssertSingleValueResult(output)
}

func findResourceRecordSets(ctx context.Context, conn *route53.Client, input *route53.ListResourceRecordSetsInput, morePages tfslices.Predicate[*route53.ListResourceRecordSetsOutput], filter tfslices.Predicate[*awstypes.ResourceRecordSet]) ([]awstypes.ResourceRecordSet, error) {
	var output []awstypes.ResourceRecordSet
	pages := route53.NewListResourceRecordSetsPaginator(conn, input)
	for pages.HasMorePages() {
		page, err := pages.NextPage(ctx)
		if errs.IsA[*awstypes.NoSuchHostedZone](err) {
			return nil, &retry.NotFoundError{LastError: err, LastRequest: input}
		}
		if err != nil {
			return nil, err
		}
		for _, v := range page.ResourceRecordSets {
			if filter(&v) {
				output = append(output, v)
			}
		}
		if !morePages(page) {
			break
		}
	}
	return output, nil
}

func resourceRecordsFor(recordName string, recordType awstypes.RRType) tfslices.Predicate[*route53.ListResourceRecordSetsOutput] {
	return func(page *route53.ListResourceRecordSetsOutput) bool {
		if page.IsTruncated {
			if strings.ToLower(aws.ToString(page.NextRecordName)) != recordName {
				return false
			}
			if page.NextRecordType != recordType {
				return false
			}
		}
		return true
	}
}

func cleanZoneID(id string) string {
	return strings.TrimPrefix(id, "/hostedzone/")
}// cleanZoneID is used to remove the leading "/hostedzone/" from a hosted zone ID


func normalizeAliasDomainName(v any) string {
	var s string
	switch v := v.( // normalizeAliasDomainName is a wrapper around the shared dns package normalization
	// function which handles interface types for Plugin SDK V2 based resources
	//
	// The only difference between this helper and normalizeDomainName is that the single
	// dot (".") domain name is not passed through as-is.
	type) {
	case *string:
		s = aws.ToString(v)
	case string:
		s = v
	default:
		return ""
	}
	return dns.Normalize(strings.TrimSuffix(s, "."))
}

func flattenCoordinate(apiObject *awstypes.Coordinates) []any {
	if apiObject == nil {
		return nil
	}
	var tfList []any
	tfMap := map[string]any{}
	if v := apiObject.Latitude; v != nil {
		tfMap["latitude"] = aws.ToString(v)
	}
	if v := apiObject.Longitude; v != nil {
		tfMap["longitude"] = aws.ToString(v)
	}
	tfList = append(tfList, tfMap)
	return tfList
}

func flattenResourceRecords(apiObjects []awstypes.ResourceRecord, rrType awstypes.RRType) []string {
	rrs := []string{}
	for _, apiObject := range apiObjects {
		if apiObject.Value != nil {
			rr := aws.ToString(apiObject.Value)
			if rrType == awstypes.RRTypeTxt || rrType == awstypes.RRTypeSpf {
				rr = expandTxtEntry(rr)
			}
			rrs = append(rrs, rr)
		}
	}
	return rrs
}

func expandTxtEntry(s string) string {
	last := len(s) - 1
	if last != 0 && s[0] == '"' && s[last] == '"' {
		s = s[1:last]
	}
	return s
}// How 'flattenTxtEntry' and 'expandTxtEntry' work.
//
// In the Route 53, TXT entries are written using quoted strings, one per line.
// Example:
//
//	"x=foo"
//	"bar=12"
//
// In Terraform, there are two differences:
// - We use a list of strings instead of separating strings with newlines.
// - Within each string, we dont' include the surrounding quotes.
// Example:
//
//	records = ["x=foo", "bar=12"]    # Instead of ["\"x=foo\", \"bar=12\""]
//
// When we pull from Route 53, `expandTxtEntry` removes the surrounding quotes;
// when we push to Route 53, `flattenTxtEntry` adds them back.
//
// One complication is that a single TXT entry can have multiple quoted strings.
// For example, here are two TXT entries, one with two quoted strings and the
// other with three.
//
//	"x=" "foo"
//	"ba" "r" "=12"
//
// DNS clients are expected to merge the quoted strings before interpreting the
// value.  Since `expandTxtEntry` only removes the quotes at the end we can still
// (hackily) represent the above configuration in Terraform:
//
//	records = ["x=\" \"foo", "ba\" \"r\" \"=12"]
//
// The primary reason to use multiple strings for an entry is that DNS (and Route
// 53) doesn't allow a quoted string to be more than 255 characters long.  If you
// want a longer TXT entry, you must use multiple quoted strings.
//
// It would be nice if this Terraform automatically split strings longer than 255
// characters.  For example, imagine "xxx..xxx" has 256 "x" characters.
//
//	records = ["xxx..xxx"]
//
// When pushing to Route 53, this could be converted to:
//
//	"xxx..xx" "x"
//
// This could also work when the user is already using multiple quoted strings:
//
//	records = ["xxx.xxx\" \"yyy..yyy"]
//
// When pushing to Route 53, this could be converted to:
//
//	"xxx..xx" "xyyy...y" "yy"
//
// If you want to add this feature, make sure to follow all the quoting rules in
// <https://tools.ietf.org/html/rfc1464#section-2>.  If you make a mistake, people
// might end up relying on that mistake so fixing it would be a breaking change.


